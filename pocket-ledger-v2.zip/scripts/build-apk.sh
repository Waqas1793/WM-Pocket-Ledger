#!/usr/bin/env bash
# Builds a debug APK locally. Needs: Node 20+, JDK 21, Android SDK (ANDROID_HOME set).
set -euo pipefail
cd "$(dirname "$0")/.."
npm install
[ -d android ] || npx cap add android
npx vite build
npx cap sync android
(cd android && ./gradlew assembleDebug)
mkdir -p release && cp android/app/build/outputs/apk/debug/app-debug.apk release/PocketLedger.apk
echo "APK ready: release/PocketLedger.apk"
