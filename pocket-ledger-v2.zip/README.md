# Pocket Ledger
> **Made by MW Solutions**  
> Daily Income, Expense & Financial Ledger Mobile Application

Pocket Ledger is a fast, responsive, and privacy-focused financial tracking application built with React, TypeScript, Tailwind CSS, and Vite. It works 100% offline and can be installed directly on Android and iOS devices as a PWA, or compiled into a native Android APK using Capacitor.

---

## Features
- **Daily Tracker**: Add daily income and expenses with fast bottom-sheet drawer.
- **Custom Currency**: Support for any custom currency symbol or code (e.g. $, €, ₹, Rs, SAR, AED, USD).
- **Custom Payment Methods**: Flexible toggle for payment methods (Cash, Card, Bank, Online, etc.).
- **Category Management**: Create custom income & expense categories with colors.
- **PDF Financial Reports**: Generate professional PDF statements with:
  - Date filtering (This Month, Custom Dates, etc.)
  - Red-themed Expenses table
  - Daily totals breakdown
  - Category summaries
  - Personalized account & company name (MW Solutions)
- **Offline First**: All data is stored securely in local browser storage (`localStorage`).
- **PWA & Mobile Install Ready**: Installable to Android and iOS home screens with native standalone experience.
- **Android APK Compatible**: Pre-configured with `capacitor.config.json` for Android Studio APK generation.

---

## Getting Started

### Prerequisites
- Node.js (version 18 or higher recommended)
- npm or yarn

### Installation
```bash
# 1. Install dependencies
npm install

# 2. Start development server
npm run dev
```

Open your browser at `http://localhost:3000`.

### Production Build
```bash
npm run build
```
The compiled production assets will be generated in the `dist/` directory.

---

## Building a Native Android APK (`.apk`)

This repository is pre-configured with `capacitor.config.json`. To build an installable Android APK:

1. **Install Capacitor CLI and Android platform:**
   ```bash
   npm install @capacitor/core @capacitor/cli @capacitor/android
   ```

2. **Build the web application:**
   ```bash
   npm run build
   ```

3. **Initialize and add Android:**
   ```bash
   npx cap add android
   npx cap open android
   ```

4. **Generate the APK file in Android Studio:**
   - Go to `Build` > `Build Bundle(s) / APK(s)` > `Build APK(s)`.
   - Your installable `.apk` will be output at:
     `android/app/build/outputs/apk/debug/app-debug.apk`
   - Sideload this file onto any Android phone and install!

---

## License & Credits
Developed by **MW Solutions**. All rights reserved.
