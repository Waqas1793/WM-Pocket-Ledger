# Build the Pocket Ledger Android APK

The app works fully offline: all code, fonts and icons are bundled in the APK and data is stored on the phone.
Exports (PDF / CSV / JSON backup) open the Android share sheet so you can save to Files, Drive, WhatsApp, etc.

## Option A: GitHub (no Android tools needed, ~5 min)
1. Create a free GitHub repo and upload this whole folder.
2. Open the repo > Actions > "Build Android APK" > Run workflow.
3. When it finishes, download the `PocketLedger-apk` artifact, unzip it, and copy `app-debug.apk` to your phone.
4. Open it on the phone and allow "Install unknown apps" when asked.

## Option B: On your computer
Install Node 20+, JDK 21 and Android Studio (for the SDK), then run:
    npm run android:apk
The APK appears at release/PocketLedger.apk.

## Option C: Android Studio
    npm install && npx cap add android && npm run android:sync && npx cap open android
Then Build > Build APK(s).
