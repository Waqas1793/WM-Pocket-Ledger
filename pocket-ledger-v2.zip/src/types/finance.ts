export type TransactionType = 'income' | 'expense';

export type PaymentMethod = string;

export interface Transaction {
  id: string;
  type: TransactionType;
  amount: number;
  category: string;
  date: string; // YYYY-MM-DD
  time?: string; // HH:MM
  description: string;
  paymentMethod: PaymentMethod;
  tags?: string[];
  status: 'cleared' | 'pending';
  recurring?: 'none' | 'daily' | 'weekly' | 'monthly' | 'yearly';
  notes?: string;
  createdAt: string;
}

export interface Category {
  id: string;
  name: string;
  type: TransactionType | 'both';
  color: string;
  budget?: number; // Monthly budget limit (for expense categories)
  iconName?: string;
}

export interface Currency {
  code: string;
  symbol: string;
  name: string;
  position: 'prefix' | 'suffix';
}

export type DateRangePreset =
  | 'today'
  | 'yesterday'
  | 'this_week'
  | 'last_week'
  | 'this_month'
  | 'last_month'
  | 'this_year'
  | 'last_30_days'
  | 'last_90_days'
  | 'all'
  | 'custom';

export interface FilterState {
  search: string;
  type: 'all' | 'income' | 'expense';
  category: string;
  dateRange: DateRangePreset;
  customStartDate?: string;
  customEndDate?: string;
  paymentMethod: string;
  status: 'all' | 'cleared' | 'pending';
  sortBy: 'date-desc' | 'date-asc' | 'amount-desc' | 'amount-asc';
}

export interface CategorySummary {
  category: string;
  total: number;
  count: number;
  percentage: number;
  color: string;
  budget?: number;
}

export interface DailySummary {
  date: string;
  income: number;
  expense: number;
  net: number;
}
