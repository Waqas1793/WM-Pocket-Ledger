import React, { createContext, useContext, useEffect, useState } from 'react';
import { DEFAULT_CATEGORIES, generateSeedTransactions, SUPPORTED_CURRENCIES } from '../data/defaultData';
import { Category, Currency, Transaction } from '../types/finance';

interface FinanceContextType {
  transactions: Transaction[];
  categories: Category[];
  currency: Currency;
  setCurrency: (c: Currency) => void;
  userName: string;
  setUserName: (name: string) => void;
  companyName: string;
  setCompanyName: (name: string) => void;
  securityPin: string;
  setSecurityPin: (pin: string) => void;
  enablePaymentMethods: boolean;
  setEnablePaymentMethods: (enabled: boolean) => void;
  paymentMethods: string[];
  addPaymentMethod: (name: string) => void;
  deletePaymentMethod: (name: string) => void;
  addTransaction: (t: Omit<Transaction, 'id' | 'createdAt'>) => Transaction;
  updateTransaction: (id: string, t: Partial<Transaction>) => void;
  deleteTransaction: (id: string) => void;
  deleteMultipleTransactions: (ids: string[]) => void;
  addCategory: (c: Omit<Category, 'id'>) => void;
  updateCategory: (id: string, c: Partial<Category>) => void;
  deleteCategory: (id: string) => void;
  updateCategoryBudget: (id: string, budget: number | undefined) => void;
  resetToDemo: () => void;
  clearAll: () => void;
  importData: (imported: {
    transactions?: Transaction[];
    categories?: Category[];
    currency?: Currency;
    enablePaymentMethods?: boolean;
    paymentMethods?: string[];
    securityPin?: string;
  }) => boolean;
  
  // Modal controls
  isAddModalOpen: boolean;
  setIsAddModalOpen: (open: boolean) => void;
  editingTransaction: Transaction | null;
  setEditingTransaction: (t: Transaction | null) => void;
  defaultModalType: 'income' | 'expense';
  openAddModal: (type?: 'income' | 'expense', txToEdit?: Transaction) => void;
  closeModal: () => void;
}

const FinanceContext = createContext<FinanceContextType | undefined>(undefined);

const STORAGE_KEY_TX = 'pocketledger_transactions_v2';
const STORAGE_KEY_CAT = 'pocketledger_categories_v4';
const STORAGE_KEY_CUR = 'pocketledger_currency_v2';
const STORAGE_KEY_USER = 'pocketledger_username_v2';
const STORAGE_KEY_COMPANY = 'pocketledger_company_name_v1';
const STORAGE_KEY_PIN = 'pocketledger_security_pin_v1';
const STORAGE_KEY_PM_ENABLED = 'pocketledger_payment_methods_enabled_v3';
const STORAGE_KEY_PM_LIST = 'pocketledger_payment_methods_list_v3';

export const FinanceProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [userName, setUserName] = useState<string>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_USER);
      if (saved && saved.trim()) return saved;
    } catch {
      // ignore
    }
    return 'Alex Morgan';
  });

  const [companyName, setCompanyNameState] = useState<string>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_COMPANY);
      if (saved && saved.trim()) return saved;
    } catch {
      // ignore
    }
    return 'MW Solutions';
  });

  const setCompanyName = (name: string) => {
    setCompanyNameState(name);
    try {
      localStorage.setItem(STORAGE_KEY_COMPANY, name);
    } catch {
      // ignore
    }
  };

  const [securityPin, setSecurityPinState] = useState<string>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_PIN);
      if (saved && saved.trim()) return saved.trim();
    } catch {
      // ignore
    }
    return '1234';
  });

  const setSecurityPin = (pin: string) => {
    setSecurityPinState(pin);
    try {
      localStorage.setItem(STORAGE_KEY_PIN, pin);
    } catch {
      // ignore
    }
  };

  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_TX);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          return parsed.filter((t: Transaction) => !t.id?.startsWith('tx-seed-'));
        }
      }
    } catch {
      // ignore
    }
    return [];
  });

  const [categories, setCategories] = useState<Category[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_CAT);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch {
      // ignore
    }
    return [];
  });

  const [currency, setCurrency] = useState<Currency>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_CUR);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && parsed.code) return parsed;
      }
    } catch {
      // ignore
    }
    return SUPPORTED_CURRENCIES[0]; // USD
  });

  const [enablePaymentMethods, setEnablePaymentMethods] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_PM_ENABLED);
      if (saved !== null) {
        return JSON.parse(saved);
      }
    } catch {
      // ignore
    }
    return true;
  });

  const [paymentMethods, setPaymentMethods] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_PM_LIST);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // ignore
    }
    return ['Cash'];
  });

  // Modal State
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingTransaction, setEditingTransaction] = useState<Transaction | null>(null);
  const [defaultModalType, setDefaultModalType] = useState<'income' | 'expense'>('expense');

  // Persistence
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_TX, JSON.stringify(transactions));
    } catch (e) {
      console.error('Failed to save transactions to localStorage', e);
    }
  }, [transactions]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_CAT, JSON.stringify(categories));
    } catch (e) {
      console.error('Failed to save categories to localStorage', e);
    }
  }, [categories]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_CUR, JSON.stringify(currency));
    } catch (e) {
      console.error('Failed to save currency to localStorage', e);
    }
  }, [currency]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_USER, userName);
    } catch (e) {
      console.error('Failed to save username to localStorage', e);
    }
  }, [userName]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_PM_ENABLED, JSON.stringify(enablePaymentMethods));
    } catch (e) {
      console.error('Failed to save enablePaymentMethods to localStorage', e);
    }
  }, [enablePaymentMethods]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_PM_LIST, JSON.stringify(paymentMethods));
    } catch (e) {
      console.error('Failed to save paymentMethods to localStorage', e);
    }
  }, [paymentMethods]);

  const addPaymentMethod = (name: string) => {
    const clean = name.trim();
    if (!clean) return;
    setPaymentMethods((prev) => {
      if (prev.some((p) => p.toLowerCase() === clean.toLowerCase())) {
        return prev;
      }
      return [...prev, clean];
    });
  };

  const deletePaymentMethod = (name: string) => {
    setPaymentMethods((prev) => {
      const filtered = prev.filter((p) => p.toLowerCase() !== name.toLowerCase());
      return filtered.length > 0 ? filtered : ['Cash'];
    });
  };

  const addTransaction = (data: Omit<Transaction, 'id' | 'createdAt'>): Transaction => {
    const newTx: Transaction = {
      ...data,
      id: `tx-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
      createdAt: new Date().toISOString(),
    };
    setTransactions((prev) => [newTx, ...prev]);
    return newTx;
  };

  const updateTransaction = (id: string, updates: Partial<Transaction>) => {
    setTransactions((prev) =>
      prev.map((t) => (t.id === id ? { ...t, ...updates } : t))
    );
  };

  const deleteTransaction = (id: string) => {
    setTransactions((prev) => prev.filter((t) => t.id !== id));
  };

  const deleteMultipleTransactions = (ids: string[]) => {
    const idSet = new Set(ids);
    setTransactions((prev) => prev.filter((t) => !idSet.has(t.id)));
  };

  const addCategory = (cat: Omit<Category, 'id'>) => {
    const newCat: Category = {
      ...cat,
      id: `cat-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
    };
    setCategories((prev) => [...prev, newCat]);
  };

  const updateCategory = (id: string, updates: Partial<Category>) => {
    setCategories((prev) =>
      prev.map((c) => (c.id === id ? { ...c, ...updates } : c))
    );
  };

  const deleteCategory = (id: string) => {
    setCategories((prev) => prev.filter((c) => c.id !== id));
  };

  const updateCategoryBudget = (id: string, budget: number | undefined) => {
    setCategories((prev) =>
      prev.map((c) => (c.id === id ? { ...c, budget } : c))
    );
  };

  const resetToDemo = () => {
    // Demo option removed per user request
  };

  const clearAll = () => {
    setTransactions([]);
  };

  const importData = (imported: {
    transactions?: Transaction[];
    categories?: Category[];
    currency?: Currency;
    enablePaymentMethods?: boolean;
    paymentMethods?: string[];
  }): boolean => {
    try {
      if (Array.isArray(imported.transactions)) {
        setTransactions(imported.transactions);
      }
      if (Array.isArray(imported.categories) && imported.categories.length > 0) {
        setCategories(imported.categories);
      }
      if (imported.currency && imported.currency.code) {
        setCurrency(imported.currency);
      }
      if (typeof imported.enablePaymentMethods === 'boolean') {
        setEnablePaymentMethods(imported.enablePaymentMethods);
      }
      if (Array.isArray(imported.paymentMethods) && imported.paymentMethods.length > 0) {
        setPaymentMethods(imported.paymentMethods);
      }
      return true;
    } catch {
      return false;
    }
  };

  const openAddModal = (type: 'income' | 'expense' = 'expense', txToEdit?: Transaction) => {
    if (txToEdit) {
      setEditingTransaction(txToEdit);
      setDefaultModalType(txToEdit.type);
    } else {
      setEditingTransaction(null);
      setDefaultModalType(type);
    }
    setIsAddModalOpen(true);
  };

  const closeModal = () => {
    setIsAddModalOpen(false);
    setEditingTransaction(null);
  };

  return (
    <FinanceContext.Provider
      value={{
        transactions,
        categories,
        currency,
        setCurrency,
        userName,
        setUserName,
        companyName,
        setCompanyName,
        securityPin,
        setSecurityPin,
        enablePaymentMethods,
        setEnablePaymentMethods,
        paymentMethods,
        addPaymentMethod,
        deletePaymentMethod,
        addTransaction,
        updateTransaction,
        deleteTransaction,
        deleteMultipleTransactions,
        addCategory,
        updateCategory,
        deleteCategory,
        updateCategoryBudget,
        resetToDemo,
        clearAll,
        importData,
        isAddModalOpen,
        setIsAddModalOpen,
        editingTransaction,
        setEditingTransaction,
        defaultModalType,
        openAddModal,
        closeModal,
      }}
    >
      {children}
    </FinanceContext.Provider>
  );
};

export const useFinance = () => {
  const context = useContext(FinanceContext);
  if (!context) {
    throw new Error('useFinance must be used within a FinanceProvider');
  }
  return context;
};
