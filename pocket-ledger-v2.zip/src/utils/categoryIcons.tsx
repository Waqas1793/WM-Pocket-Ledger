import React from 'react';
import {
  Utensils,
  ShoppingCart,
  Home,
  Zap,
  Car,
  HeartPulse,
  ShoppingBag,
  Film,
  Tv,
  GraduationCap,
  Plane,
  Briefcase,
  DollarSign,
  TrendingUp,
  Building,
  Gift,
  HelpCircle,
  CreditCard,
  Coffee,
  Wallet,
} from 'lucide-react';

export function getCategoryIcon(categoryName: string, className: string = 'w-4 h-4'): React.ReactNode {
  const name = categoryName.toLowerCase();

  if (name.includes('grocer')) return <ShoppingCart className={className} />;
  if (name.includes('dining') || name.includes('restaurant') || name.includes('food') || name.includes('coffee'))
    return <Utensils className={className} />;
  if (name.includes('house') || name.includes('rent')) return <Home className={className} />;
  if (name.includes('util') || name.includes('bill') || name.includes('electric')) return <Zap className={className} />;
  if (name.includes('transport') || name.includes('fuel') || name.includes('car') || name.includes('transit'))
    return <Car className={className} />;
  if (name.includes('health') || name.includes('medical') || name.includes('fitness') || name.includes('gym'))
    return <HeartPulse className={className} />;
  if (name.includes('shopping') || name.includes('retail') || name.includes('clothes'))
    return <ShoppingBag className={className} />;
  if (name.includes('entertainment') || name.includes('cinema') || name.includes('movie'))
    return <Film className={className} />;
  if (name.includes('subscription') || name.includes('software') || name.includes('app') || name.includes('netflix'))
    return <Tv className={className} />;
  if (name.includes('education') || name.includes('course') || name.includes('book'))
    return <GraduationCap className={className} />;
  if (name.includes('travel') || name.includes('flight') || name.includes('vacation'))
    return <Plane className={className} />;
  if (name.includes('salary') || name.includes('payroll') || name.includes('job'))
    return <Briefcase className={className} />;
  if (name.includes('freelance') || name.includes('consulting') || name.includes('client'))
    return <Briefcase className={className} />;
  if (name.includes('invest') || name.includes('dividend') || name.includes('stock'))
    return <TrendingUp className={className} />;
  if (name.includes('rental')) return <Building className={className} />;
  if (name.includes('gift') || name.includes('grant') || name.includes('reward'))
    return <Gift className={className} />;

  return <DollarSign className={className} />;
}
