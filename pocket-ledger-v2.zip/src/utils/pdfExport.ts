import { saveBlob } from './nativeSave';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import { CategorySummary, Currency, Transaction } from '../types/finance';
import { formatCurrency } from './formatters';

interface GeneratePdfReportParams {
  userName: string;
  startDateStr: string;
  endDateStr: string;
  currency: Currency;
  income: number;
  expense: number;
  net: number;
  savingsRate: number;
  transactions: Transaction[];
  expenseBreakdown?: CategorySummary[];
}

function formatDocDate(dateStr: string): string {
  if (!dateStr) return '';
  const [year, month, day] = dateStr.split('-').map(Number);
  const d = new Date(year, month - 1, day);
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  return `${day} ${months[d.getMonth()]} ${year}`;
}

function formatDayHeader(dateStr: string): string {
  if (!dateStr) return '';
  const [year, month, day] = dateStr.split('-').map(Number);
  const d = new Date(year, month - 1, day);
  const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  return `${days[d.getDay()]}, ${day} ${months[d.getMonth()]} ${year}`;
}

export async function generatePdfReport({
  userName,
  startDateStr,
  endDateStr,
  currency,
  income,
  expense,
  net,
  transactions,
}: GeneratePdfReportParams) {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'pt',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 36;
  const contentWidth = pageWidth - margin * 2;

  const tealHeaderColor: [number, number, number] = [10, 93, 113]; // #0a5d71 deep teal
  const tealTotalBgColor: [number, number, number] = [227, 242, 245]; // #e3f2f5 soft teal
  const textDarkColor: [number, number, number] = [15, 23, 42]; // #0f172a
  const textMutedColor: [number, number, number] = [100, 116, 139]; // #64748b

  // Red theme for Expense table & expense indicators
  const redExpenseHeaderColor: [number, number, number] = [185, 28, 28]; // #b91c1c crimson red header
  const redExpenseTotalBgColor: [number, number, number] = [254, 226, 226]; // #fee2e2 soft red
  const redExpenseTextColor: [number, number, number] = [185, 28, 28]; // #b91c1c red text

  // 1. BRAND ICON & HEADER
  let currentY = 36;

  // Icon: Dark squircle with golden letter W and teal underline matching logo
  const iconSize = 40;
  doc.setFillColor(26, 38, 44); // dark slate matching logo #1a262c
  doc.roundedRect(margin, currentY, iconSize, iconSize, 7, 7, 'F');

  // Draw Letter "W" in gold inside icon
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(21);
  doc.setTextColor(245, 158, 11); // golden/amber
  doc.text('W', margin + iconSize / 2, currentY + iconSize / 2 + 5, { align: 'center' });

  // Teal underline matching the logo
  doc.setFillColor(13, 148, 136); // teal #0d9488
  doc.rect(margin + 8, currentY + iconSize - 7, iconSize - 16, 2.5, 'F');

  // Text next to icon
  const textStartX = margin + iconSize + 14;

  // Kicker (e.g. "POCKET LEDGER • MADE BY MW SOLUTIONS")
  const brandName = userName && userName.trim() ? `${userName.trim().toUpperCase()} • POCKET LEDGER` : 'POCKET LEDGER • MW SOLUTIONS';
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(217, 119, 6); // amber-600
  doc.text(brandName, textStartX, currentY + 9);

  // Main Title: "Income & Expense Report"
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(16);
  doc.setTextColor(...textDarkColor);
  doc.text('Income & Expense Report', textStartX, currentY + 24);

  // Date Range Subtitle: "1 Oct 2026 to 31 Oct 2026"
  const startFormatted = formatDocDate(startDateStr);
  const endFormatted = formatDocDate(endDateStr);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(71, 85, 105);
  doc.text(`${startFormatted} to ${endFormatted}`, textStartX, currentY + 36);

  // Generated info: "Generated 29 Oct 2026 - 5 entries - amounts in SAR"
  const todayStr = formatDocDate(new Date().toISOString().split('T')[0]);
  const currencyCode = currency.code || currency.symbol || 'USD';
  doc.setFontSize(8);
  doc.setTextColor(...textMutedColor);
  doc.text(`Generated ${todayStr} - ${transactions.length} entries - amounts in ${currencyCode}`, textStartX, currentY + 47);

  currentY += 60;

  // 2. TOP 3 METRIC SUMMARY CARDS
  const cardGap = 10;
  const cardWidth = (contentWidth - cardGap * 2) / 3;
  const cardHeight = 44;

  const renderCard = (x: number, label: string, amountStr: string, color: [number, number, number]) => {
    doc.setFillColor(248, 250, 252); // slate-50
    doc.setDrawColor(226, 232, 240); // slate-200
    doc.roundedRect(x, currentY, cardWidth, cardHeight, 5, 5, 'FD');

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(...textMutedColor);
    doc.text(label, x + 10, currentY + 14);

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.setTextColor(...color);
    doc.text(amountStr, x + 10, currentY + 32);
  };

  // Card 1: Income (Green)
  renderCard(margin, 'INCOME', formatCurrency(income, currency), [5, 150, 105]);
  // Card 2: Expenses (Rose/Red)
  renderCard(margin + cardWidth + cardGap, 'EXPENSES', formatCurrency(expense, currency), [225, 29, 72]);
  // Card 3: Net Balance (Dark Teal)
  renderCard(margin + (cardWidth + cardGap) * 2, 'NET BALANCE', formatCurrency(net, currency), [10, 93, 113]);

  currentY += cardHeight + 20;

  // 3. TOTALS BY DAY TABLE
  // Group by day
  const dayMap = new Map<string, { income: number; expense: number }>();
  transactions.forEach((t) => {
    const cur = dayMap.get(t.date) || { income: 0, expense: 0 };
    if (t.type === 'income') cur.income += t.amount;
    else cur.expense += t.amount;
    dayMap.set(t.date, cur);
  });

  const sortedDays = Array.from(dayMap.keys()).sort((a, b) => b.localeCompare(a));
  const dayRows: (string | number)[][] = sortedDays.map((d) => {
    const entry = dayMap.get(d)!;
    const dayNet = entry.income - entry.expense;
    return [
      formatDayHeader(d),
      formatCurrency(entry.income, currency),
      formatCurrency(entry.expense, currency),
      formatCurrency(dayNet, currency),
    ];
  });

  // Total footer row
  dayRows.push([
    'Total',
    formatCurrency(income, currency),
    formatCurrency(expense, currency),
    formatCurrency(net, currency),
  ]);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(...textDarkColor);
  doc.text('Totals by day', margin, currentY);

  autoTable(doc, {
    startY: currentY + 6,
    margin: { left: margin, right: margin },
    theme: 'plain',
    head: [['Day', 'Income', 'Expenses', 'Net']],
    body: dayRows,
    headStyles: {
      fillColor: tealHeaderColor,
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 8.5,
      cellPadding: 5,
    },
    bodyStyles: {
      fontSize: 8,
      cellPadding: 4,
      textColor: textDarkColor,
    },
    columnStyles: {
      0: { cellWidth: 180 },
      1: { halign: 'right' },
      2: { halign: 'right' },
      3: { halign: 'right' },
    },
    didParseCell: (data) => {
      // Style the last total row
      if (data.row.index === dayRows.length - 1) {
        data.cell.styles.fillColor = tealTotalBgColor;
        data.cell.styles.fontStyle = 'bold';
        data.cell.styles.textColor = textDarkColor;
        // Total expense column in red
        if (data.column.index === 2) {
          data.cell.styles.textColor = redExpenseTextColor;
        }
      } else if (data.column.index === 2 && data.section === 'body') {
        // Daily expense column in red
        data.cell.styles.textColor = redExpenseTextColor;
      }
    },
  });

  currentY = (doc as any).lastAutoTable.finalY + 18;

  // 4. EXPENSES BY NAME TABLE (RED COLOR AS REQUESTED)
  const expenseMap = new Map<string, number>();
  transactions
    .filter((t) => t.type === 'expense')
    .forEach((t) => {
      const name = t.description?.trim() || t.category || 'Expense';
      expenseMap.set(name, (expenseMap.get(name) || 0) + t.amount);
    });

  const sortedExpenses = Array.from(expenseMap.entries()).sort((a, b) => b[1] - a[1]);
  const expenseRows = sortedExpenses.map(([name, amt]) => [
    name,
    formatCurrency(amt, currency),
  ]);

  expenseRows.push([
    'Total',
    formatCurrency(expense, currency),
  ]);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(...redExpenseTextColor);
  doc.text('Expenses by name', margin, currentY);

  autoTable(doc, {
    startY: currentY + 6,
    margin: { left: margin, right: margin },
    theme: 'plain',
    head: [['Expense', 'Amount']],
    body: expenseRows.length > 1 ? expenseRows : [['No expenses recorded', formatCurrency(0, currency)]],
    headStyles: {
      fillColor: redExpenseHeaderColor,
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 8.5,
      cellPadding: 5,
    },
    bodyStyles: {
      fontSize: 8,
      cellPadding: 4,
      textColor: textDarkColor,
    },
    columnStyles: {
      0: { cellWidth: 340 },
      1: { halign: 'right', textColor: redExpenseTextColor, fontStyle: 'bold' },
    },
    didParseCell: (data) => {
      if (data.row.index === expenseRows.length - 1 && expenseRows.length > 1) {
        data.cell.styles.fillColor = redExpenseTotalBgColor;
        data.cell.styles.fontStyle = 'bold';
        data.cell.styles.textColor = redExpenseTextColor;
      }
    },
  });

  currentY = (doc as any).lastAutoTable.finalY + 18;

  // 5. INCOME BY CUSTOMER TABLE (NO SHARE COLUMN AS REQUESTED)
  const incomeMap = new Map<string, number>();
  transactions
    .filter((t) => t.type === 'income')
    .forEach((t) => {
      const name = t.description?.trim() || t.category || 'Income';
      incomeMap.set(name, (incomeMap.get(name) || 0) + t.amount);
    });

  const sortedIncome = Array.from(incomeMap.entries()).sort((a, b) => b[1] - a[1]);
  const incomeRows = sortedIncome.map(([name, amt]) => [
    name,
    formatCurrency(amt, currency),
  ]);

  incomeRows.push([
    'Total',
    formatCurrency(income, currency),
  ]);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(...textDarkColor);
  doc.text('Income by customer', margin, currentY);

  autoTable(doc, {
    startY: currentY + 6,
    margin: { left: margin, right: margin },
    theme: 'plain',
    head: [['Customer', 'Amount']],
    body: incomeRows.length > 1 ? incomeRows : [['No income recorded', formatCurrency(0, currency)]],
    headStyles: {
      fillColor: tealHeaderColor,
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 8.5,
      cellPadding: 5,
    },
    bodyStyles: {
      fontSize: 8,
      cellPadding: 4,
      textColor: textDarkColor,
    },
    columnStyles: {
      0: { cellWidth: 340 },
      1: { halign: 'right' },
    },
    didParseCell: (data) => {
      if (data.row.index === incomeRows.length - 1 && incomeRows.length > 1) {
        data.cell.styles.fillColor = tealTotalBgColor;
        data.cell.styles.fontStyle = 'bold';
        data.cell.styles.textColor = textDarkColor;
      }
    },
  });

  currentY = (doc as any).lastAutoTable.finalY + 18;

  // Check if we need to add a page or continue for Transactions
  if (currentY > pageHeight - 160) {
    doc.addPage();
    currentY = 40;
  }

  // 6. TRANSACTIONS TABLE
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(...textDarkColor);
  doc.text('Transactions', margin, currentY);

  const sortedTransactions = [...transactions].sort((a, b) => b.date.localeCompare(a.date));
  const txRows = sortedTransactions.map((t) => [
    formatDocDate(t.date),
    t.type === 'income' ? 'Income' : 'Expense',
    t.description || t.category || '',
    `${t.type === 'income' ? '' : '-'}${formatCurrency(t.amount, currency)}`,
  ]);

  autoTable(doc, {
    startY: currentY + 6,
    margin: { left: margin, right: margin },
    theme: 'plain',
    head: [['Date', 'Type', 'Name', 'Amount']],
    body: txRows.length > 0 ? txRows : [['-', '-', 'No transactions', '-']],
    headStyles: {
      fillColor: tealHeaderColor,
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 8.5,
      cellPadding: 5,
    },
    bodyStyles: {
      fontSize: 8,
      cellPadding: 4,
      textColor: textDarkColor,
    },
    columnStyles: {
      0: { cellWidth: 90 },
      1: { cellWidth: 70 },
      2: { cellWidth: 230 },
      3: { halign: 'right' },
    },
    didParseCell: (data) => {
      // Color negative expense amounts in red
      if (data.column.index === 3 && data.section === 'body') {
        const text = String(data.cell.raw);
        if (text.startsWith('-')) {
          data.cell.styles.textColor = redExpenseTextColor;
          data.cell.styles.fontStyle = 'bold';
        }
      }
      // Color 'Expense' type label in red
      if (data.column.index === 1 && data.section === 'body') {
        const text = String(data.cell.raw);
        if (text === 'Expense') {
          data.cell.styles.textColor = redExpenseTextColor;
          data.cell.styles.fontStyle = 'bold';
        }
      }
    },
  });

  // 7. FOOTER ON ALL PAGES
  const totalPages = doc.getNumberOfPages();
  const footerBrand = userName && userName.trim()
    ? `${userName.trim()} Pocket Ledger • MW Solutions`
    : 'Pocket Ledger • Made by MW Solutions';

  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(148, 163, 184); // slate-400

    // Left: MW Pocket Ledger
    doc.text(footerBrand, margin, pageHeight - 20);

    // Right: Page X of Y
    doc.text(`Page ${i} of ${totalPages}`, pageWidth - margin, pageHeight - 20, { align: 'right' });
  }

  // Save the PDF
  const cleanName = (userName || 'ledger').replace(/[^a-zA-Z0-9]/g, '_');
  await saveBlob(doc.output('blob'), `ledger_${startDateStr}_to_${endDateStr}.pdf`);
}
