import { saveBlob } from './nativeSave';
import { Category, CategorySummary, Currency, DateRangePreset, Transaction } from '../types/finance';

export function formatCurrency(amount: number, currency: Currency): string {
  const formattedNumber = Math.abs(amount).toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });

  const sign = amount < 0 ? '-' : '';
  if (currency.position === 'prefix') {
    return `${sign}${currency.symbol}${formattedNumber}`;
  } else {
    return `${sign}${formattedNumber} ${currency.symbol}`;
  }
}

export function formatDateLabel(dateString: string): string {
  if (!dateString) return '';
  const [year, month, day] = dateString.split('-').map(Number);
  const targetDate = new Date(year, month - 1, day);
  
  const today = new Date();
  const todayMidnight = new Date(today.getFullYear(), today.getMonth(), today.getDate());
  
  const diffTime = todayMidnight.getTime() - targetDate.getTime();
  const diffDays = Math.round(diffTime / (1000 * 60 * 60 * 24));

  if (diffDays === 0) return 'Today';
  if (diffDays === 1) return 'Yesterday';
  if (diffDays === -1) return 'Tomorrow';

  return targetDate.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: targetDate.getFullYear() !== today.getFullYear() ? 'numeric' : undefined,
  });
}

export function formatFullDate(dateString: string): string {
  if (!dateString) return '';
  const [year, month, day] = dateString.split('-').map(Number);
  const d = new Date(year, month - 1, day);
  return d.toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
}

export function getTodayDateString(): string {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function getCurrentTimeString(): string {
  const now = new Date();
  const hours = String(now.getHours()).padStart(2, '0');
  const minutes = String(now.getMinutes()).padStart(2, '0');
  return `${hours}:${minutes}`;
}

/**
 * Returns [startDateStr, endDateStr] based on preset
 */
export function getDateRangeBounds(
  preset: DateRangePreset,
  customStart?: string,
  customEnd?: string
): [string, string] {
  const now = new Date();
  const todayStr = getTodayDateString();

  const toStr = (d: Date): string => {
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  switch (preset) {
    case 'today':
      return [todayStr, todayStr];

    case 'yesterday': {
      const y = new Date(now);
      y.setDate(y.getDate() - 1);
      const str = toStr(y);
      return [str, str];
    }

    case 'this_week': {
      // Monday of current week
      const d = new Date(now);
      const day = d.getDay();
      const diffToMonday = d.getDate() - day + (day === 0 ? -6 : 1);
      const monday = new Date(d.setDate(diffToMonday));
      return [toStr(monday), todayStr];
    }

    case 'last_week': {
      const d = new Date(now);
      const day = d.getDay();
      const diffToMonday = d.getDate() - day + (day === 0 ? -6 : 1);
      const lastMonday = new Date(d.setDate(diffToMonday - 7));
      const lastSunday = new Date(lastMonday);
      lastSunday.setDate(lastSunday.getDate() + 6);
      return [toStr(lastMonday), toStr(lastSunday)];
    }

    case 'this_month': {
      const start = new Date(now.getFullYear(), now.getMonth(), 1);
      return [toStr(start), todayStr];
    }

    case 'last_month': {
      const start = new Date(now.getFullYear(), now.getMonth() - 1, 1);
      const end = new Date(now.getFullYear(), now.getMonth(), 0);
      return [toStr(start), toStr(end)];
    }

    case 'last_30_days': {
      const past = new Date(now);
      past.setDate(past.getDate() - 29);
      return [toStr(past), todayStr];
    }

    case 'last_90_days': {
      const past = new Date(now);
      past.setDate(past.getDate() - 89);
      return [toStr(past), todayStr];
    }

    case 'this_year': {
      const start = new Date(now.getFullYear(), 0, 1);
      return [toStr(start), todayStr];
    }

    case 'custom':
      return [customStart || '2000-01-01', customEnd || todayStr];

    case 'all':
    default:
      return ['1970-01-01', '2099-12-31'];
  }
}

export function filterTransactionsByDateRange(
  transactions: Transaction[],
  preset: DateRangePreset,
  customStart?: string,
  customEnd?: string
): Transaction[] {
  if (preset === 'all') return transactions;
  const [start, end] = getDateRangeBounds(preset, customStart, customEnd);
  return transactions.filter((t) => t.date >= start && t.date <= end);
}

export function calculateTotals(transactions: Transaction[]) {
  let income = 0;
  let expense = 0;

  for (const t of transactions) {
    if (t.type === 'income') {
      income += t.amount;
    } else {
      expense += t.amount;
    }
  }

  const net = income - expense;
  const savingsRate = income > 0 ? Math.max(0, ((income - expense) / income) * 100) : 0;

  return { income, expense, net, savingsRate };
}

export function getCategoryBreakdown(
  transactions: Transaction[],
  type: 'expense' | 'income',
  categories: Category[]
): CategorySummary[] {
  const filtered = transactions.filter((t) => t.type === type);
  const totalAmount = filtered.reduce((acc, t) => acc + t.amount, 0);

  const map = new Map<string, { amount: number; count: number }>();

  filtered.forEach((t) => {
    const existing = map.get(t.category) || { amount: 0, count: 0 };
    map.set(t.category, {
      amount: existing.amount + t.amount,
      count: existing.count + 1,
    });
  });

  const categoryMap = new Map<string, Category>(categories.map((c) => [c.name, c]));

  const result: CategorySummary[] = [];

  map.forEach((value, catName) => {
    const catConfig = categoryMap.get(catName);
    result.push({
      category: catName,
      total: value.amount,
      count: value.count,
      percentage: totalAmount > 0 ? (value.amount / totalAmount) * 100 : 0,
      color: catConfig?.color || '#94a3b8',
      budget: catConfig?.budget,
    });
  });

  // Sort descending by amount
  return result.sort((a, b) => b.total - a.total);
}

/**
 * Aggregates daily net cash flows for charting
 */
export function getDailyAggregates(
  transactions: Transaction[],
  daysCount: number = 14
): { date: string; label: string; income: number; expense: number; net: number }[] {
  const now = new Date();
  const map = new Map<string, { income: number; expense: number }>();

  // Initialize the last N days
  const dates: string[] = [];
  for (let i = daysCount - 1; i >= 0; i--) {
    const d = new Date(now);
    d.setDate(d.getDate() - i);
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    const dateStr = `${year}-${month}-${day}`;
    dates.push(dateStr);
    map.set(dateStr, { income: 0, expense: 0 });
  }

  // Populate
  transactions.forEach((t) => {
    if (map.has(t.date)) {
      const cur = map.get(t.date)!;
      if (t.type === 'income') {
        cur.income += t.amount;
      } else {
        cur.expense += t.amount;
      }
    }
  });

  return dates.map((d) => {
    const entry = map.get(d) || { income: 0, expense: 0 };
    return {
      date: d,
      label: formatDateLabel(d),
      income: entry.income,
      expense: entry.expense,
      net: entry.income - entry.expense,
    };
  });
}

/**
 * Exports transactions to standard CSV format
 */
export function exportToCsv(transactions: Transaction[], currency: Currency): string {
  const headers = ['ID', 'Date', 'Time', 'Type', 'Category', 'Description', 'Amount', 'Currency', 'Payment Method', 'Status', 'Tags', 'Notes'];

  const rows = transactions.map((t) => {
    return [
      t.id,
      t.date,
      t.time || '',
      t.type,
      `"${(t.category || '').replace(/"/g, '""')}"`,
      `"${(t.description || '').replace(/"/g, '""')}"`,
      t.amount.toFixed(2),
      currency.code,
      t.paymentMethod,
      t.status,
      `"${(t.tags || []).join(', ')}"`,
      `"${(t.notes || '').replace(/"/g, '""')}"`,
    ].join(',');
  });

  return [headers.join(','), ...rows].join('\r\n');
}

/**
 * Triggers browser download of a CSV or JSON file
 */
export function downloadFile(content: string, filename: string, mimeType: string) {
  void saveBlob(new Blob([content], { type: mimeType }), filename).catch((e) =>
    console.error('Failed to save file', e)
  );
}
