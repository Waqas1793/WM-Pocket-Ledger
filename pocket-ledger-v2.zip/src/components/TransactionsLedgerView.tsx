import React, { useMemo, useState } from 'react';
import { useFinance } from '../context/FinanceContext';
import { DateRangePreset, FilterState, Transaction } from '../types/finance';
import {
  calculateTotals,
  downloadFile,
  exportToCsv,
  filterTransactionsByDateRange,
  formatCurrency,
  formatDateLabel,
} from '../utils/formatters';
import {
  Search,
  Filter,
  Download,
  Trash2,
  Edit2,
  Calendar,
  X,
  ChevronDown,
  ArrowUpDown,
  Plus,
  CheckSquare,
  Square,
  FileSpreadsheet,
} from 'lucide-react';

export const TransactionsLedgerView: React.FC = () => {
  const {
    transactions,
    categories,
    currency,
    enablePaymentMethods,
    paymentMethods,
    deleteTransaction,
    deleteMultipleTransactions,
    openAddModal,
  } = useFinance();

  const [filters, setFilters] = useState<FilterState>({
    search: '',
    type: 'all',
    category: 'all',
    dateRange: 'this_month',
    paymentMethod: 'all',
    status: 'all',
    sortBy: 'date-desc',
    customStartDate: '',
    customEndDate: '',
  });

  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  // Apply filters
  const filteredTransactions = useMemo(() => {
    let result = transactions;

    // Date range
    result = filterTransactionsByDateRange(
      result,
      filters.dateRange,
      filters.customStartDate,
      filters.customEndDate
    );

    // Type
    if (filters.type !== 'all') {
      result = result.filter((t) => t.type === filters.type);
    }

    // Category
    if (filters.category !== 'all') {
      result = result.filter((t) => t.category === filters.category);
    }

    // Payment method
    if (filters.paymentMethod !== 'all') {
      result = result.filter((t) => t.paymentMethod === filters.paymentMethod);
    }

    // Status
    if (filters.status !== 'all') {
      result = result.filter((t) => t.status === filters.status);
    }

    // Search query
    if (filters.search.trim()) {
      const q = filters.search.toLowerCase().trim();
      result = result.filter(
        (t) =>
          t.description.toLowerCase().includes(q) ||
          t.category.toLowerCase().includes(q) ||
          (t.notes && t.notes.toLowerCase().includes(q)) ||
          (t.tags && t.tags.some((tag) => tag.toLowerCase().includes(q)))
      );
    }

    // Sort
    return [...result].sort((a, b) => {
      if (filters.sortBy === 'date-desc') {
        return b.date.localeCompare(a.date) || (b.time || '').localeCompare(a.time || '');
      }
      if (filters.sortBy === 'date-asc') {
        return a.date.localeCompare(b.date) || (a.time || '').localeCompare(b.time || '');
      }
      if (filters.sortBy === 'amount-desc') {
        return b.amount - a.amount;
      }
      if (filters.sortBy === 'amount-asc') {
        return a.amount - b.amount;
      }
      return 0;
    });
  }, [transactions, filters]);

  // Totals for filtered set
  const filteredTotals = useMemo(() => {
    return calculateTotals(filteredTransactions);
  }, [filteredTransactions]);

  // Bulk selection handling
  const allSelected =
    filteredTransactions.length > 0 &&
    filteredTransactions.every((t) => selectedIds.includes(t.id));

  const toggleSelectAll = () => {
    if (allSelected) {
      setSelectedIds([]);
    } else {
      setSelectedIds(filteredTransactions.map((t) => t.id));
    }
  };

  const toggleSelectOne = (id: string) => {
    if (selectedIds.includes(id)) {
      setSelectedIds(selectedIds.filter((item) => item !== id));
    } else {
      setSelectedIds([...selectedIds, id]);
    }
  };

  const handleExportCsv = () => {
    const dataToExport =
      selectedIds.length > 0
        ? transactions.filter((t) => selectedIds.includes(t.id))
        : filteredTransactions;

    const csvData = exportToCsv(dataToExport, currency);
    const dateStamp = new Date().toISOString().split('T')[0];
    downloadFile(csvData, `ledgerpulse_export_${dateStamp}.csv`, 'text/csv;charset=utf-8;');
  };

  const handleDeleteSelected = () => {
    if (selectedIds.length === 0) return;
    if (
      window.confirm(
        `Are you sure you want to permanently delete ${selectedIds.length} transaction(s)?`
      )
    ) {
      deleteMultipleTransactions(selectedIds);
      setSelectedIds([]);
    }
  };

  const hasActiveFilters =
    filters.search !== '' ||
    filters.type !== 'all' ||
    filters.category !== 'all' ||
    filters.dateRange !== 'this_month' ||
    filters.paymentMethod !== 'all' ||
    filters.status !== 'all';

  const resetFilters = () => {
    setFilters({
      search: '',
      type: 'all',
      category: 'all',
      dateRange: 'this_month',
      paymentMethod: 'all',
      status: 'all',
      sortBy: 'date-desc',
      customStartDate: '',
      customEndDate: '',
    });
  };

  return (
    <div className="space-y-4">
      {/* Search and Filters Header */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          {/* Search bar */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search by payee, tag, or description..."
              value={filters.search}
              onChange={(e) => setFilters({ ...filters, search: e.target.value })}
              className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-slate-900"
            />
            {filters.search && (
              <button
                onClick={() => setFilters({ ...filters, search: '' })}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Quick Date Range Preset */}
          <div className="flex items-center gap-2">
            <select
              value={filters.dateRange}
              onChange={(e) =>
                setFilters({ ...filters, dateRange: e.target.value as DateRangePreset })
              }
              className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-medium text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-slate-900"
            >
              <option value="today">Today</option>
              <option value="yesterday">Yesterday</option>
              <option value="this_week">This Week</option>
              <option value="last_week">Last Week</option>
              <option value="this_month">This Month</option>
              <option value="last_month">Last Month</option>
              <option value="last_30_days">Last 30 Days</option>
              <option value="last_90_days">Last 90 Days</option>
              <option value="this_year">This Year</option>
              <option value="all">All Time</option>
              <option value="custom">Custom Range...</option>
            </select>

            {/* Export CSV Button */}
            <button
              onClick={handleExportCsv}
              className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg transition-colors cursor-pointer"
              title="Download CSV spreadsheet"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-slate-600" />
              <span>Export CSV</span>
            </button>
          </div>
        </div>

        {/* Custom date range pickers if selected */}
        {filters.dateRange === 'custom' && (
          <div className="flex items-center gap-3 pt-2 border-t border-slate-100 text-xs">
            <span className="text-slate-500 font-medium">From:</span>
            <input
              type="date"
              value={filters.customStartDate || ''}
              onChange={(e) => setFilters({ ...filters, customStartDate: e.target.value })}
              className="px-2 py-1 bg-slate-50 border border-slate-200 rounded text-xs font-mono"
            />
            <span className="text-slate-500 font-medium">To:</span>
            <input
              type="date"
              value={filters.customEndDate || ''}
              onChange={(e) => setFilters({ ...filters, customEndDate: e.target.value })}
              className="px-2 py-1 bg-slate-50 border border-slate-200 rounded text-xs font-mono"
            />
          </div>
        )}

        {/* Second Row: Detailed Filters Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-100">
          <div className="flex flex-wrap items-center gap-2">
            {/* Type Filter Buttons */}
            <div className="flex bg-slate-100 p-0.5 rounded-lg text-xs">
              <button
                onClick={() => setFilters({ ...filters, type: 'all' })}
                className={`px-3 py-1 font-medium rounded-md transition-colors ${
                  filters.type === 'all'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                All
              </button>
              <button
                onClick={() => setFilters({ ...filters, type: 'income' })}
                className={`px-3 py-1 font-medium rounded-md transition-colors ${
                  filters.type === 'income'
                    ? 'bg-white text-emerald-700 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Income
              </button>
              <button
                onClick={() => setFilters({ ...filters, type: 'expense' })}
                className={`px-3 py-1 font-medium rounded-md transition-colors ${
                  filters.type === 'expense'
                    ? 'bg-white text-rose-700 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Expenses
              </button>
            </div>

            {/* Category dropdown */}
            <select
              value={filters.category}
              onChange={(e) => setFilters({ ...filters, category: e.target.value })}
              className="px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-700 focus:bg-white focus:outline-none"
            >
              <option value="all">All Categories</option>
              {categories.map((c) => (
                <option key={c.id} value={c.name}>
                  {c.name}
                </option>
              ))}
            </select>

            {/* Payment method */}
            {enablePaymentMethods && (
              <select
                value={filters.paymentMethod}
                onChange={(e) => setFilters({ ...filters, paymentMethod: e.target.value })}
                className="px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-700 focus:bg-white focus:outline-none"
              >
                <option value="all">All Methods</option>
                {paymentMethods.map((pm) => (
                  <option key={pm} value={pm}>
                    {pm}
                  </option>
                ))}
              </select>
            )}

            {/* Sort order */}
            <select
              value={filters.sortBy}
              onChange={(e) => setFilters({ ...filters, sortBy: e.target.value as any })}
              className="px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-700 focus:bg-white focus:outline-none"
            >
              <option value="date-desc">Newest Date First</option>
              <option value="date-asc">Oldest Date First</option>
              <option value="amount-desc">Highest Amount</option>
              <option value="amount-asc">Lowest Amount</option>
            </select>

            {hasActiveFilters && (
              <button
                onClick={resetFilters}
                className="text-xs text-slate-500 hover:text-slate-900 font-medium px-2 py-1 rounded hover:bg-slate-100 transition-colors"
              >
                Reset filters
              </button>
            )}
          </div>

          <div className="text-xs text-slate-500">
            Showing <strong className="font-mono text-slate-900">{filteredTransactions.length}</strong> of{' '}
            <strong className="font-mono text-slate-900">{transactions.length}</strong> entries
          </div>
        </div>
      </div>

      {/* Bulk Action Banner (when items selected) */}
      {selectedIds.length > 0 && (
        <div className="bg-slate-900 text-white rounded-lg px-4 py-2.5 flex items-center justify-between text-xs transition-all shadow-md">
          <div className="flex items-center gap-2">
            <span className="font-bold">{selectedIds.length} item(s) selected</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleExportCsv}
              className="px-3 py-1 bg-slate-800 hover:bg-slate-700 rounded font-medium transition-colors"
            >
              Export Selected
            </button>
            <button
              onClick={handleDeleteSelected}
              className="px-3 py-1 bg-rose-600 hover:bg-rose-700 text-white rounded font-medium transition-colors"
            >
              Delete Selected
            </button>
            <button
              onClick={() => setSelectedIds([])}
              className="px-2 py-1 text-slate-400 hover:text-white"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Main High-Density Table */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider">
              <tr>
                <th className="py-3 px-3 w-10 text-center">
                  <input
                    type="checkbox"
                    checked={allSelected}
                    onChange={toggleSelectAll}
                    className="rounded border-slate-300 text-slate-900 focus:ring-slate-900 cursor-pointer"
                  />
                </th>
                <th className="py-3 px-3">Date</th>
                <th className="py-3 px-3">Category</th>
                <th className="py-3 px-4">Description</th>
                {enablePaymentMethods && <th className="py-3 px-3">Method</th>}
                <th className="py-3 px-3">Status</th>
                <th className="py-3 px-4 text-right">Amount</th>
                <th className="py-3 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredTransactions.length === 0 ? (
                <tr>
                  <td colSpan={enablePaymentMethods ? 8 : 7} className="py-12 text-center text-slate-500">
                    <p className="font-medium text-slate-700">No transactions match your current filters.</p>
                    <button
                      onClick={resetFilters}
                      className="mt-2 text-xs text-indigo-600 hover:text-indigo-800 font-medium"
                    >
                      Clear all filters
                    </button>
                  </td>
                </tr>
              ) : (
                filteredTransactions.map((tx) => {
                  const isChecked = selectedIds.includes(tx.id);
                  const catConfig = categories.find((c) => c.name === tx.category);

                  return (
                    <tr
                      key={tx.id}
                      className={`hover:bg-slate-50/80 transition-colors ${
                        isChecked ? 'bg-slate-50/90' : ''
                      }`}
                    >
                      <td className="py-3 px-3 text-center">
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => toggleSelectOne(tx.id)}
                          className="rounded border-slate-300 text-slate-900 focus:ring-slate-900 cursor-pointer"
                        />
                      </td>

                      <td className="py-3 px-3 font-mono whitespace-nowrap text-slate-800">
                        {tx.date}
                        {tx.time && (
                          <span className="text-[10px] text-slate-400 block">{tx.time}</span>
                        )}
                      </td>

                      <td className="py-3 px-3 whitespace-nowrap">
                        <div className="flex items-center gap-1.5">
                          <span
                            className="w-2 h-2 rounded-full shrink-0"
                            style={{ backgroundColor: catConfig?.color || '#94a3b8' }}
                          />
                          <span className="font-medium text-slate-900">{tx.category}</span>
                        </div>
                      </td>

                      <td className="py-3 px-4 max-w-xs">
                        <div className="font-medium text-slate-900 truncate">{tx.description}</div>
                        {tx.tags && tx.tags.length > 0 && (
                          <div className="flex gap-1 mt-0.5">
                            {tx.tags.map((tag) => (
                              <span key={tag} className="text-[10px] text-slate-500 font-mono">
                                #{tag}
                              </span>
                            ))}
                          </div>
                        )}
                      </td>

                      {enablePaymentMethods && (
                        <td className="py-3 px-3 capitalize text-slate-600 whitespace-nowrap">
                          {tx.paymentMethod.replace('_', ' ')}
                        </td>
                      )}

                      <td className="py-3 px-3 whitespace-nowrap">
                        <span
                          className={`inline-block px-2 py-0.5 rounded text-[10px] font-semibold ${
                            tx.status === 'cleared'
                              ? 'bg-emerald-50 text-emerald-700'
                              : 'bg-amber-50 text-amber-700'
                          }`}
                        >
                          {tx.status === 'cleared' ? 'Cleared' : 'Pending'}
                        </span>
                      </td>

                      <td className="py-3 px-4 text-right font-mono font-bold text-sm tabular-nums whitespace-nowrap">
                        <span
                          className={tx.type === 'income' ? 'text-emerald-700' : 'text-slate-900'}
                        >
                          {tx.type === 'income' ? '+' : '-'}
                          {formatCurrency(tx.amount, currency)}
                        </span>
                      </td>

                      <td className="py-3 px-3 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1">
                          <button
                            onClick={() => openAddModal(tx.type, tx)}
                            title="Edit"
                            className="p-1 text-slate-400 hover:text-slate-700 rounded hover:bg-slate-100"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => deleteTransaction(tx.id)}
                            title="Delete"
                            className="p-1 text-slate-400 hover:text-rose-600 rounded hover:bg-rose-50"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Filtered Summary Footer Bar */}
        <div className="bg-slate-50 border-t border-slate-200 px-4 py-3 flex flex-wrap items-center justify-between gap-4 text-xs">
          <div className="text-slate-500 font-medium">
            Totals for filtered dataset ({filteredTransactions.length} items)
          </div>

          <div className="flex items-center gap-6 font-mono tabular-nums">
            <div>
              <span className="text-slate-400 mr-1.5">Inflow:</span>
              <span className="font-bold text-emerald-700">
                +{formatCurrency(filteredTotals.income, currency)}
              </span>
            </div>
            <div>
              <span className="text-slate-400 mr-1.5">Outflow:</span>
              <span className="font-bold text-rose-700">
                -{formatCurrency(filteredTotals.expense, currency)}
              </span>
            </div>
            <div>
              <span className="text-slate-400 mr-1.5">Net:</span>
              <span
                className={`font-bold ${
                  filteredTotals.net >= 0 ? 'text-emerald-700' : 'text-rose-700'
                }`}
              >
                {formatCurrency(filteredTotals.net, currency)}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
