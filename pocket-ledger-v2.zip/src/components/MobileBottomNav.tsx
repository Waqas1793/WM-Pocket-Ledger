import React from 'react';
import { useFinance } from '../context/FinanceContext';
import { Home, Clock, PieChart, Sliders, Plus } from 'lucide-react';

export type MobileTab = 'home' | 'history' | 'reports' | 'settings';

interface MobileBottomNavProps {
  currentTab: MobileTab;
  setCurrentTab: (tab: MobileTab) => void;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  currentTab,
  setCurrentTab,
}) => {
  const { openAddModal } = useFinance();

  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 shadow-lg">
      <div className="max-w-md mx-auto px-4 h-16 flex items-center justify-between relative">
        {/* Tab 1: Home / Today */}
        <button
          onClick={() => setCurrentTab('home')}
          className={`flex flex-col items-center justify-center flex-1 h-full min-h-[44px] min-w-[44px] cursor-pointer transition-colors ${
            currentTab === 'home' ? 'text-slate-900 font-bold' : 'text-slate-400 hover:text-slate-600'
          }`}
        >
          <Home className={`w-5 h-5 ${currentTab === 'home' ? 'stroke-[2.5]' : 'stroke-[1.75]'}`} />
          <span className="text-[10px] tracking-tight mt-1">Today</span>
        </button>

        {/* Tab 2: History */}
        <button
          onClick={() => setCurrentTab('history')}
          className={`flex flex-col items-center justify-center flex-1 h-full min-h-[44px] min-w-[44px] cursor-pointer transition-colors ${
            currentTab === 'history' ? 'text-slate-900 font-bold' : 'text-slate-400 hover:text-slate-600'
          }`}
        >
          <Clock className={`w-5 h-5 ${currentTab === 'history' ? 'stroke-[2.5]' : 'stroke-[1.75]'}`} />
          <span className="text-[10px] tracking-tight mt-1">History</span>
        </button>

        {/* Center Prominent Add (+) Button */}
        <div className="flex-1 flex items-center justify-center -mt-5">
          <button
            onClick={() => openAddModal('expense')}
            aria-label="Add Transaction"
            className="w-13 h-13 rounded-full bg-slate-900 hover:bg-slate-800 active:scale-95 text-white flex items-center justify-center shadow-lg shadow-slate-900/25 transition-transform cursor-pointer"
          >
            <Plus className="w-6 h-6 stroke-[2.5]" />
          </button>
        </div>

        {/* Tab 3: Reports */}
        <button
          onClick={() => setCurrentTab('reports')}
          className={`flex flex-col items-center justify-center flex-1 h-full min-h-[44px] min-w-[44px] cursor-pointer transition-colors ${
            currentTab === 'reports' ? 'text-slate-900 font-bold' : 'text-slate-400 hover:text-slate-600'
          }`}
        >
          <PieChart className={`w-5 h-5 ${currentTab === 'reports' ? 'stroke-[2.5]' : 'stroke-[1.75]'}`} />
          <span className="text-[10px] tracking-tight mt-1">Reports</span>
        </button>

        {/* Tab 4: Settings */}
        <button
          onClick={() => setCurrentTab('settings')}
          className={`flex flex-col items-center justify-center flex-1 h-full min-h-[44px] min-w-[44px] cursor-pointer transition-colors ${
            currentTab === 'settings' ? 'text-slate-900 font-bold' : 'text-slate-400 hover:text-slate-600'
          }`}
        >
          <Sliders className={`w-5 h-5 ${currentTab === 'settings' ? 'stroke-[2.5]' : 'stroke-[1.75]'}`} />
          <span className="text-[10px] tracking-tight mt-1">Settings</span>
        </button>
      </div>
    </div>
  );
};
