import React, { useRef, useState } from 'react';
import { useFinance } from '../context/FinanceContext';
import { Currency, TransactionType } from '../types/finance';
import { downloadFile, formatCurrency } from '../utils/formatters';
import {
  Globe,
  Tag,
  Database,
  Trash2,
  Plus,
  RefreshCw,
  Upload,
  Download,
  Check,
  ShieldCheck,
  AlertCircle,
  CreditCard,
  X,
  User,
} from 'lucide-react';

export const SettingsView: React.FC = () => {
  const {
    currency,
    setCurrency,
    userName,
    setUserName,
    enablePaymentMethods,
    setEnablePaymentMethods,
    paymentMethods,
    addPaymentMethod,
    deletePaymentMethod,
    categories,
    addCategory,
    deleteCategory,
    transactions,
    clearAll,
    importData,
  } = useFinance();

  const fileInputRef = useRef<HTMLInputElement>(null);
  const [userNameInput, setUserNameInput] = useState<string>(userName || 'Alex Morgan');
  const [isNameSaved, setIsNameSaved] = useState<boolean>(false);

  const handleSaveName = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userNameInput.trim()) return;
    setUserName(userNameInput.trim());
    setIsNameSaved(true);
    setTimeout(() => setIsNameSaved(false), 2000);
  };

  const [newMethodInput, setNewMethodInput] = useState<string>('');
  const [methodSuccessMsg, setMethodSuccessMsg] = useState<string | null>(null);

  const handleAddCustomMethod = (e?: React.FormEvent, methodName?: string) => {
    if (e) e.preventDefault();
    const nameToAdd = (methodName || newMethodInput).trim();
    if (!nameToAdd) return;
    addPaymentMethod(nameToAdd);
    setNewMethodInput('');
    setMethodSuccessMsg(`Payment method "${nameToAdd}" added!`);
    setTimeout(() => setMethodSuccessMsg(null), 2500);
  };

  const [customCurrencyInput, setCustomCurrencyInput] = useState<string>(
    currency.symbol.trim() || currency.code || '$'
  );
  const [isSaved, setIsSaved] = useState<boolean>(false);

  const handleSaveCustomCurrency = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = customCurrencyInput.trim();
    if (!clean) return;

    const hasMultipleLetters = /^[A-Za-z]{2,}$/.test(clean);
    const formattedSymbol = hasMultipleLetters ? `${clean} ` : clean;

    setCurrency({
      code: clean.toUpperCase().slice(0, 5) || clean,
      symbol: formattedSymbol,
      name: clean,
      position: 'prefix',
    });

    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2000);
  };

  // New Category State
  const [newCatName, setNewCatName] = useState('');
  const [newCatType, setNewCatType] = useState<TransactionType>('expense');
  const [newCatColor, setNewCatColor] = useState('#6366f1');
  const [newCatBudget, setNewCatBudget] = useState<string>('');
  const [importMessage, setImportMessage] = useState<{ text: string; error?: boolean } | null>(null);

  const handleAddCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatName.trim()) return;

    const budgetVal = parseFloat(newCatBudget);
    addCategory({
      name: newCatName.trim(),
      type: newCatType,
      color: newCatColor,
      budget: !isNaN(budgetVal) && budgetVal > 0 ? budgetVal : undefined,
    });

    setNewCatName('');
    setNewCatBudget('');
  };

  const handleExportFullBackup = () => {
    const backupData = {
      version: '2.0',
      exportedAt: new Date().toISOString(),
      currency,
      enablePaymentMethods,
      paymentMethods,
      categories,
      transactions,
    };
    const jsonStr = JSON.stringify(backupData, null, 2);
    const dateStamp = new Date().toISOString().split('T')[0];
    downloadFile(jsonStr, `ledgerpulse_backup_${dateStamp}.json`, 'application/json');
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (parsed && (parsed.transactions || parsed.categories)) {
          const success = importData(parsed);
          if (success) {
            setImportMessage({ text: 'Backup restored successfully!' });
          } else {
            setImportMessage({ text: 'Failed to import backup data.', error: true });
          }
        } else {
          setImportMessage({ text: 'Invalid backup file structure.', error: true });
        }
      } catch (err) {
        setImportMessage({ text: 'Could not read JSON file.', error: true });
      }
    };
    reader.readAsText(file);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleClearAll = () => {
    if (
      window.confirm(
        'Are you sure you want to delete ALL recorded transactions? This action cannot be undone.'
      )
    ) {
      clearAll();
    }
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* User Name Card */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-3">
        <div className="flex items-center gap-2 mb-1">
          <User className="w-4 h-4 text-slate-700" />
          <h2 className="text-base font-bold text-slate-900">User / Account Name</h2>
        </div>

        <p className="text-xs text-slate-500">
          This name appears on your greeting header and in all generated PDF financial reports.
        </p>

        <form onSubmit={handleSaveName} className="flex items-center gap-2 pt-1 max-w-md">
          <input
            type="text"
            placeholder="e.g. Alex Morgan, Acme Studio"
            value={userNameInput}
            onChange={(e) => {
              setUserNameInput(e.target.value);
              setIsNameSaved(false);
            }}
            className="flex-1 px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-semibold text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-slate-900 transition-all placeholder:text-slate-300"
          />
          <button
            type="submit"
            disabled={!userNameInput.trim()}
            className="h-11 px-5 bg-slate-900 hover:bg-slate-800 disabled:opacity-40 text-white font-bold text-xs rounded-xl transition-all flex items-center justify-center gap-1.5 shadow-xs cursor-pointer shrink-0"
          >
            {isNameSaved ? <Check className="w-4 h-4 text-emerald-400" /> : null}
            <span>{isNameSaved ? 'Saved' : 'Save'}</span>
          </button>
        </form>
      </div>

      {/* Custom Currency Textbox */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-3">
        <div className="flex items-center gap-2 mb-1">
          <Globe className="w-4 h-4 text-slate-700" />
          <h2 className="text-base font-bold text-slate-900">Custom Currency</h2>
        </div>

        <p className="text-xs text-slate-500">
          Enter any custom currency symbol or code (e.g. $, €, ₹, £, USD, Rs, AED, kr, PHP):
        </p>

        <form onSubmit={handleSaveCustomCurrency} className="space-y-3 pt-1 max-w-md">
          <div className="flex items-center gap-2">
            <input
              type="text"
              placeholder="e.g. $, €, ₹, Rs, USD"
              value={customCurrencyInput}
              onChange={(e) => {
                setCustomCurrencyInput(e.target.value);
                setIsSaved(false);
              }}
              className="flex-1 px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-base font-bold font-mono text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-slate-900 transition-all placeholder:text-slate-300"
            />
            <button
              type="submit"
              disabled={!customCurrencyInput.trim()}
              className="h-11 px-5 bg-slate-900 hover:bg-slate-800 disabled:opacity-40 text-white font-bold text-xs rounded-xl transition-all flex items-center justify-center gap-1.5 shadow-xs cursor-pointer shrink-0"
            >
              {isSaved ? <Check className="w-4 h-4 text-emerald-400" /> : null}
              <span>{isSaved ? 'Saved' : 'Save'}</span>
            </button>
          </div>

          <div className="flex items-center justify-between p-3 bg-slate-50 border border-slate-100 rounded-xl text-xs">
            <span className="text-slate-500">Preview:</span>
            <span className="font-mono font-bold text-slate-900 text-sm">
              {formatCurrency(1250.00, {
                code: customCurrencyInput.trim() || '$',
                symbol: /^[A-Za-z]{2,}$/.test(customCurrencyInput.trim())
                  ? `${customCurrencyInput.trim()} `
                  : customCurrencyInput.trim() || '$',
                name: customCurrencyInput.trim() || 'Custom',
                position: 'prefix',
              })}
            </span>
          </div>
        </form>
      </div>

      {/* Payment Method Settings Card */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CreditCard className="w-4 h-4 text-slate-700" />
            <h2 className="text-base font-bold text-slate-900">Payment Methods</h2>
          </div>

          {/* Toggle Switch */}
          <button
            type="button"
            role="switch"
            aria-checked={enablePaymentMethods}
            onClick={() => setEnablePaymentMethods(!enablePaymentMethods)}
            className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors cursor-pointer focus:outline-none focus:ring-2 focus:ring-slate-900 focus:ring-offset-2 ${
              enablePaymentMethods ? 'bg-slate-900' : 'bg-slate-300'
            }`}
          >
            <span
              className={`inline-block h-4 w-4 transform rounded-full bg-white shadow transition-transform ${
                enablePaymentMethods ? 'translate-x-6' : 'translate-x-1'
              }`}
            />
          </button>
        </div>

        <p className="text-xs text-slate-500">
          {enablePaymentMethods
            ? 'Payment method tracking is enabled. Transactions default to Cash unless another method is chosen.'
            : 'Payment method tracking is turned off. All transactions will automatically be logged as Cash.'}
        </p>

        {enablePaymentMethods && (
          <div className="space-y-4 pt-2 border-t border-slate-100 animate-in fade-in duration-150">
            {methodSuccessMsg && (
              <div className="p-2.5 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs flex items-center gap-1.5">
                <Check className="w-4 h-4" />
                <span>{methodSuccessMsg}</span>
              </div>
            )}

            {/* Active Methods Chips */}
            <div>
              <span className="text-xs font-bold text-slate-700 uppercase tracking-wider block mb-2">
                Active Methods ({paymentMethods.length})
              </span>

              <div className="flex flex-wrap gap-2">
                {paymentMethods.map((pm) => {
                  const isCash = pm.toLowerCase() === 'cash';
                  return (
                    <div
                      key={pm}
                      className="inline-flex items-center gap-2 px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold text-slate-800"
                    >
                      <span>{pm}</span>
                      {isCash && (
                        <span className="text-[10px] uppercase px-1.5 py-0.2 bg-emerald-100 text-emerald-800 rounded font-bold">
                          Default
                        </span>
                      )}
                      {paymentMethods.length > 1 && (
                        <button
                          type="button"
                          onClick={() => deletePaymentMethod(pm)}
                          className="text-slate-400 hover:text-rose-600 rounded p-0.5 ml-0.5 cursor-pointer"
                          title={`Remove ${pm}`}
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Add Custom Method Form */}
            <form onSubmit={handleAddCustomMethod} className="p-3.5 bg-slate-50 rounded-lg border border-slate-200 max-w-lg space-y-3">
              <span className="text-xs font-bold text-slate-800 uppercase tracking-wider block">
                Add New Payment Method
              </span>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  placeholder="e.g. Bank Transfer, Card, UPI, PayPal"
                  value={newMethodInput}
                  onChange={(e) => setNewMethodInput(e.target.value)}
                  className="flex-1 px-3 py-1.5 bg-white border border-slate-200 rounded text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-slate-900"
                />
                <button
                  type="submit"
                  disabled={!newMethodInput.trim()}
                  className="px-4 py-1.5 bg-slate-900 hover:bg-slate-800 disabled:opacity-40 text-white font-bold text-xs rounded transition-all cursor-pointer shrink-0"
                >
                  Add Option
                </button>
              </div>

              {/* Quick suggestions */}
              <div className="pt-1">
                <span className="text-[11px] text-slate-500 font-medium block mb-1">
                  Quick suggestions:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {['Bank Transfer', 'Credit Card', 'Debit Card', 'UPI', 'Mobile Wallet', 'Cheque'].map(
                    (suggested) => {
                      const alreadyAdded = paymentMethods.some(
                        (p) => p.toLowerCase() === suggested.toLowerCase()
                      );
                      if (alreadyAdded) return null;
                      return (
                        <button
                          key={suggested}
                          type="button"
                          onClick={() => handleAddCustomMethod(undefined, suggested)}
                          className="px-2.5 py-1 text-xs bg-white border border-slate-200 hover:bg-slate-100 text-slate-700 font-medium rounded transition-colors cursor-pointer"
                        >
                          + {suggested}
                        </button>
                      );
                    }
                  )}
                </div>
              </div>
            </form>
          </div>
        )}
      </div>

      {/* Category Manager */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
        <div className="flex items-center gap-2 mb-2">
          <Tag className="w-4 h-4 text-slate-700" />
          <h2 className="text-base font-bold text-slate-900">Category Management</h2>
        </div>
        <p className="text-xs text-slate-500 mb-4">
          Customize your income and expense categories to fit your household or business workflows.
        </p>

        {/* Add Category Form */}
        <form onSubmit={handleAddCategory} className="p-3.5 bg-slate-50 rounded-lg border border-slate-200 mb-4 space-y-3">
          <span className="text-xs font-bold text-slate-800 uppercase tracking-wider block">
            Add New Category
          </span>
          <div className="grid grid-cols-1 sm:grid-cols-12 gap-2.5">
            <div className="sm:col-span-4">
              <input
                type="text"
                placeholder="Category Name..."
                value={newCatName}
                onChange={(e) => setNewCatName(e.target.value)}
                className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-slate-900"
              />
            </div>
            <div className="sm:col-span-3">
              <select
                value={newCatType}
                onChange={(e) => setNewCatType(e.target.value as TransactionType)}
                className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-slate-900"
              >
                <option value="expense">Expense</option>
                <option value="income">Income</option>
              </select>
            </div>
            <div className="sm:col-span-3">
              <input
                type="number"
                placeholder="Monthly Budget (Optional)"
                value={newCatBudget}
                onChange={(e) => setNewCatBudget(e.target.value)}
                className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-slate-900"
              />
            </div>
            <div className="sm:col-span-2 flex items-center gap-2">
              <input
                type="color"
                value={newCatColor}
                onChange={(e) => setNewCatColor(e.target.value)}
                className="w-8 h-8 rounded border-0 cursor-pointer p-0"
                title="Pick category badge color"
              />
              <button
                type="submit"
                disabled={!newCatName.trim()}
                className="flex-1 py-1.5 px-3 bg-slate-900 text-white text-xs font-semibold rounded hover:bg-slate-800 disabled:opacity-40 transition-colors"
              >
                Add
              </button>
            </div>
          </div>
        </form>

        {/* Existing Categories List */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2 max-h-72 overflow-y-auto p-1">
          {categories.map((c) => (
            <div
              key={c.id}
              className="flex items-center justify-between p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-xs"
            >
              <div className="flex items-center gap-2 min-w-0">
                <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: c.color }} />
                <div className="truncate">
                  <span className="font-semibold text-slate-800 truncate block">{c.name}</span>
                  <span className="text-[10px] text-slate-500 capitalize">
                    {c.type} {c.budget ? `· ${formatCurrency(c.budget, currency)} budget` : ''}
                  </span>
                </div>
              </div>
              <button
                onClick={() => deleteCategory(c.id)}
                title="Delete category"
                className="p-1 text-slate-400 hover:text-rose-600 rounded hover:bg-rose-50 transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Data Management, Backups & Privacy */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-4">
        <div className="flex items-center gap-2">
          <Database className="w-4 h-4 text-slate-700" />
          <h2 className="text-base font-bold text-slate-900">Data Portability & Backups</h2>
        </div>
        <p className="text-xs text-slate-500">
          All financial records are stored securely and privately in your local browser storage. You can create full JSON backups or restore previous data anytime.
        </p>

        {importMessage && (
          <div
            className={`p-3 rounded-lg text-xs flex items-center gap-2 ${
              importMessage.error ? 'bg-rose-50 text-rose-800 border border-rose-200' : 'bg-emerald-50 text-emerald-800 border border-emerald-200'
            }`}
          >
            {importMessage.error ? <AlertCircle className="w-4 h-4" /> : <Check className="w-4 h-4" />}
            <span>{importMessage.text}</span>
          </div>
        )}

        <div className="flex flex-wrap items-center gap-3 pt-2">
          {/* Download JSON Backup */}
          <button
            onClick={handleExportFullBackup}
            className="flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download JSON Backup</span>
          </button>

          {/* Import JSON Backup */}
          <label className="flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer">
            <Upload className="w-3.5 h-3.5" />
            <span>Restore JSON Backup</span>
            <input
              ref={fileInputRef}
              type="file"
              accept=".json"
              onChange={handleFileChange}
              className="hidden"
            />
          </label>

          {/* Clear All Data */}
          <button
            onClick={handleClearAll}
            className="flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-rose-700 bg-rose-50 hover:bg-rose-100 rounded-lg transition-colors cursor-pointer border border-rose-200 ml-auto"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Wipe All Data</span>
          </button>
        </div>
      </div>
    </div>
  );
};
