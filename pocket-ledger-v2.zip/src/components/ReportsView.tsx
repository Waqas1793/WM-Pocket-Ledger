import React, { useMemo, useState } from 'react';
import { useFinance } from '../context/FinanceContext';
import { CategorySummary, DateRangePreset, Transaction } from '../types/finance';
import {
  calculateTotals,
  downloadFile,
  exportToCsv,
  filterTransactionsByDateRange,
  formatCurrency,
  formatDateLabel,
  formatFullDate,
  getCategoryBreakdown,
  getDateRangeBounds,
} from '../utils/formatters';
import {
  BarChart3,
  PieChart,
  TrendingUp,
  TrendingDown,
  Printer,
  Download,
  Calendar,
  Layers,
  CheckCircle2,
  AlertTriangle,
  ArrowUpRight,
  ArrowDownRight,
  ShieldAlert,
  FileText,
  DollarSign,
  Percent,
} from 'lucide-react';

import { generatePdfReport } from '../utils/pdfExport';

export const ReportsView: React.FC = () => {
  const { transactions, categories, currency, userName } = useFinance();

  const [dateRange, setDateRange] = useState<DateRangePreset>('this_month');
  const [customStart, setCustomStart] = useState<string>('');
  const [customEnd, setCustomEnd] = useState<string>('');
  const [reportTab, setReportTab] = useState<'overview' | 'categories' | 'trends' | 'budgets' | 'statement'>('overview');
  const [hoveredSlice, setHoveredSlice] = useState<string | null>(null);

  // Time window bounds
  const [startDateStr, endDateStr] = useMemo(() => {
    return getDateRangeBounds(dateRange, customStart, customEnd);
  }, [dateRange, customStart, customEnd]);

  // Current period transactions
  const periodTransactions = useMemo(() => {
    return transactions.filter((t) => t.date >= startDateStr && t.date <= endDateStr);
  }, [transactions, startDateStr, endDateStr]);

  // Totals for current period
  const { income, expense, net, savingsRate } = useMemo(() => {
    return calculateTotals(periodTransactions);
  }, [periodTransactions]);

  // Day count in period for daily average
  const periodDays = useMemo(() => {
    const start = new Date(startDateStr);
    const end = new Date(endDateStr);
    const diff = Math.max(1, Math.round((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24)) + 1);
    return diff;
  }, [startDateStr, endDateStr]);

  const dailyAvgSpend = periodDays > 0 ? expense / periodDays : 0;
  const dailyAvgIncome = periodDays > 0 ? income / periodDays : 0;

  // Largest expense in period
  const largestExpense = useMemo(() => {
    const expensesOnly = periodTransactions.filter((t) => t.type === 'expense');
    if (expensesOnly.length === 0) return null;
    return [...expensesOnly].sort((a, b) => b.amount - a.amount)[0];
  }, [periodTransactions]);

  // Category Breakdowns
  const expenseBreakdown = useMemo(() => {
    return getCategoryBreakdown(periodTransactions, 'expense', categories);
  }, [periodTransactions, categories]);

  const incomeBreakdown = useMemo(() => {
    return getCategoryBreakdown(periodTransactions, 'income', categories);
  }, [periodTransactions, categories]);

  // Prior Period Calculation for Comparison (e.g. previous N days)
  const priorPeriodTotals = useMemo(() => {
    const currentStart = new Date(startDateStr);
    const durationMs = (new Date(endDateStr).getTime() - currentStart.getTime());
    const priorEnd = new Date(currentStart.getTime() - (1000 * 60 * 60 * 24));
    const priorStart = new Date(priorEnd.getTime() - durationMs);

    const toStr = (d: Date) => d.toISOString().split('T')[0];
    const priorStartStr = toStr(priorStart);
    const priorEndStr = toStr(priorEnd);

    const priorTxs = transactions.filter((t) => t.date >= priorStartStr && t.date <= priorEndStr);
    return calculateTotals(priorTxs);
  }, [transactions, startDateStr, endDateStr]);

  // Percent deltas vs prior period
  const expenseDeltaPercent = priorPeriodTotals.expense > 0
    ? ((expense - priorPeriodTotals.expense) / priorPeriodTotals.expense) * 100
    : 0;

  const incomeDeltaPercent = priorPeriodTotals.income > 0
    ? ((income - priorPeriodTotals.income) / priorPeriodTotals.income) * 100
    : 0;

  // Time-Series Trend Aggregates (Day-by-Day or grouped)
  const trendData = useMemo(() => {
    const map = new Map<string, { income: number; expense: number }>();
    
    // Sort transactions chronologically
    const sorted = [...periodTransactions].sort((a, b) => a.date.localeCompare(b.date));
    sorted.forEach((t) => {
      const cur = map.get(t.date) || { income: 0, expense: 0 };
      if (t.type === 'income') {
        cur.income += t.amount;
      } else {
        cur.expense += t.amount;
      }
      map.set(t.date, cur);
    });

    const entries = Array.from(map.entries()).map(([date, val]) => ({
      date,
      label: formatDateLabel(date),
      income: val.income,
      expense: val.expense,
      net: val.income - val.expense,
    }));

    return entries;
  }, [periodTransactions]);

  const maxTrendVal = useMemo(() => {
    let max = 100;
    trendData.forEach((d) => {
      if (d.income > max) max = d.income;
      if (d.expense > max) max = d.expense;
    });
    return max;
  }, [trendData]);

  // Budget vs Actual evaluation
  const budgetComparisons = useMemo(() => {
    return categories
      .filter((c) => c.type === 'expense' && typeof c.budget === 'number' && c.budget > 0)
      .map((cat) => {
        const spent = expenseBreakdown.find((b) => b.category === cat.name)?.total || 0;
        const budget = cat.budget || 0;
        const percent = budget > 0 ? (spent / budget) * 100 : 0;
        const remaining = budget - spent;
        return {
          category: cat.name,
          color: cat.color,
          budget,
          spent,
          remaining,
          percent,
          isOver: spent > budget,
          isWarning: percent >= 80 && percent <= 100,
        };
      })
      .sort((a, b) => b.percent - a.percent);
  }, [categories, expenseBreakdown]);

  const handleDownloadPdf = () => {
    generatePdfReport({
      userName: userName || 'Account Holder',
      startDateStr,
      endDateStr,
      currency,
      income,
      expense,
      net,
      savingsRate,
      transactions: periodTransactions,
      expenseBreakdown,
    });
  };

  const handlePrint = () => {
    window.print();
  };

  const handleExportReportCsv = () => {
    const csvContent = exportToCsv(periodTransactions, currency);
    downloadFile(csvContent, `financial_report_${startDateStr}_to_${endDateStr}.csv`, 'text/csv;charset=utf-8;');
  };

  return (
    <div className="space-y-6">
      {/* Report Controls & Period Bar (No print) */}
      <div className="no-print bg-white rounded-xl border border-slate-200 p-4 sm:p-5 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-base font-bold text-slate-900">Financial Reports Suite</h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Period: <span className="font-mono font-medium text-slate-800">{startDateStr}</span> to{' '}
              <span className="font-mono font-medium text-slate-800">{endDateStr}</span> ({periodDays} days)
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Date Range Selector */}
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-slate-400" />
              <select
                value={dateRange}
                onChange={(e) => setDateRange(e.target.value as DateRangePreset)}
                className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-slate-900"
              >
                <option value="this_month">This Month</option>
                <option value="last_month">Last Month</option>
                <option value="last_30_days">Last 30 Days</option>
                <option value="last_90_days">Last 90 Days</option>
                <option value="this_year">This Year (YTD)</option>
                <option value="all">All Time</option>
                <option value="custom">Custom Range...</option>
              </select>
            </div>

            {/* Download PDF Button */}
            <button
              onClick={handleDownloadPdf}
              className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors cursor-pointer shadow-xs"
              title="Download PDF document"
            >
              <FileText className="w-3.5 h-3.5 text-emerald-400" />
              <span>Download PDF</span>
            </button>

            {/* Print Button */}
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg transition-colors cursor-pointer"
              title="Print formal statement or save to PDF"
            >
              <Printer className="w-3.5 h-3.5 text-slate-600" />
              <span>Print View</span>
            </button>

            {/* CSV Export */}
            <button
              onClick={handleExportReportCsv}
              className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg transition-colors cursor-pointer shadow-xs"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export CSV</span>
            </button>
          </div>
        </div>

        {/* Custom Range Inputs if selected */}
        {dateRange === 'custom' && (
          <div className="flex items-center gap-3 pt-3 mt-3 border-t border-slate-100 text-xs">
            <span className="text-slate-500 font-medium">Start Date:</span>
            <input
              type="date"
              value={customStart}
              onChange={(e) => setCustomStart(e.target.value)}
              className="px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded text-xs font-mono"
            />
            <span className="text-slate-500 font-medium">End Date:</span>
            <input
              type="date"
              value={customEnd}
              onChange={(e) => setCustomEnd(e.target.value)}
              className="px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded text-xs font-mono"
            />
          </div>
        )}

        {/* Sub-Report Tabs */}
        <div className="flex items-center gap-1 mt-4 pt-3 border-t border-slate-100 overflow-x-auto text-xs">
          <button
            onClick={() => setReportTab('overview')}
            className={`px-3 py-1.5 font-semibold rounded-md transition-colors whitespace-nowrap cursor-pointer ${
              reportTab === 'overview'
                ? 'bg-slate-900 text-white'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            Executive Summary
          </button>
          <button
            onClick={() => setReportTab('categories')}
            className={`px-3 py-1.5 font-semibold rounded-md transition-colors whitespace-nowrap cursor-pointer ${
              reportTab === 'categories'
                ? 'bg-slate-900 text-white'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            Category Distribution
          </button>
          <button
            onClick={() => setReportTab('trends')}
            className={`px-3 py-1.5 font-semibold rounded-md transition-colors whitespace-nowrap cursor-pointer ${
              reportTab === 'trends'
                ? 'bg-slate-900 text-white'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            Cash Flow Trend Chart
          </button>
          <button
            onClick={() => setReportTab('budgets')}
            className={`px-3 py-1.5 font-semibold rounded-md transition-colors whitespace-nowrap cursor-pointer ${
              reportTab === 'budgets'
                ? 'bg-slate-900 text-white'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            Budget vs Actual
          </button>
          <button
            onClick={() => setReportTab('statement')}
            className={`px-3 py-1.5 font-semibold rounded-md transition-colors whitespace-nowrap cursor-pointer ${
              reportTab === 'statement'
                ? 'bg-slate-900 text-white'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            Printable Statement
          </button>
        </div>
      </div>

      {/* KPI METRIC TILES */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Net Savings */}
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-semibold uppercase tracking-wider">Net Cash Flow</span>
            <div className={`p-1 rounded ${net >= 0 ? 'bg-emerald-50 text-emerald-700' : 'bg-rose-50 text-rose-700'}`}>
              <DollarSign className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className={`text-xl sm:text-2xl font-bold font-mono tabular-nums ${net >= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
            {formatCurrency(net, currency)}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            Savings Rate: <strong className="font-mono text-slate-800">{savingsRate.toFixed(1)}%</strong>
          </div>
        </div>

        {/* Total Inflow */}
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-semibold uppercase tracking-wider">Total Inflow</span>
            <div className="p-1 bg-emerald-50 text-emerald-700 rounded">
              <ArrowDownRight className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-bold font-mono text-emerald-700 tabular-nums">
            {formatCurrency(income, currency)}
          </div>
          <div className="text-[11px] text-slate-500 mt-1 flex items-center gap-1">
            <span>vs Prior: </span>
            <span className={`font-mono font-medium ${incomeDeltaPercent >= 0 ? 'text-emerald-700' : 'text-slate-600'}`}>
              {incomeDeltaPercent >= 0 ? '+' : ''}{incomeDeltaPercent.toFixed(1)}%
            </span>
          </div>
        </div>

        {/* Total Outflow */}
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-semibold uppercase tracking-wider">Total Outflow</span>
            <div className="p-1 bg-rose-50 text-rose-700 rounded">
              <ArrowUpRight className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-bold font-mono text-rose-700 tabular-nums">
            {formatCurrency(expense, currency)}
          </div>
          <div className="text-[11px] text-slate-500 mt-1 flex items-center gap-1">
            <span>vs Prior: </span>
            <span className={`font-mono font-medium ${expenseDeltaPercent <= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
              {expenseDeltaPercent >= 0 ? '+' : ''}{expenseDeltaPercent.toFixed(1)}%
            </span>
          </div>
        </div>

        {/* Daily Burn Rate */}
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-semibold uppercase tracking-wider">Avg Daily Spend</span>
            <div className="p-1 bg-slate-100 text-slate-700 rounded">
              <TrendingDown className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-bold font-mono text-slate-900 tabular-nums">
            {formatCurrency(dailyAvgSpend, currency)}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            Daily Income: <span className="font-mono">{formatCurrency(dailyAvgIncome, currency)}</span>
          </div>
        </div>
      </div>

      {/* TAB 1: EXECUTIVE SUMMARY */}
      {reportTab === 'overview' && (
        <div className="space-y-6">
          {/* Key Insights & Callout Strip */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Inflow vs Outflow Ratio Card */}
            <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
              <h3 className="text-sm font-bold text-slate-900 mb-3">Cash Flow Proportions</h3>
              <div className="space-y-3">
                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-slate-600 font-medium">Income Retained (Savings)</span>
                    <span className="font-mono font-bold text-emerald-700">{savingsRate.toFixed(1)}%</span>
                  </div>
                  <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-emerald-500 rounded-full transition-all duration-300"
                      style={{ width: `${Math.min(100, Math.max(0, savingsRate))}%` }}
                    />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-slate-600 font-medium">Expense-to-Income Ratio</span>
                    <span className="font-mono font-bold text-slate-800">
                      {income > 0 ? ((expense / income) * 100).toFixed(1) : '100'}%
                    </span>
                  </div>
                  <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-300 ${
                        expense > income ? 'bg-rose-500' : 'bg-slate-700'
                      }`}
                      style={{ width: `${Math.min(100, income > 0 ? (expense / income) * 100 : 100)}%` }}
                    />
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-100 text-xs text-slate-500 flex justify-between">
                  <span>Transactions in period: <strong className="font-mono text-slate-800">{periodTransactions.length}</strong></span>
                  <span>Days logged: <strong className="font-mono text-slate-800">{periodDays}</strong></span>
                </div>
              </div>
            </div>

            {/* Highlights & Top Outlays */}
            <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
              <h3 className="text-sm font-bold text-slate-900 mb-3">Period Highlights</h3>
              <div className="space-y-3 text-xs">
                {largestExpense ? (
                  <div className="p-3 bg-slate-50 rounded-lg flex items-center justify-between">
                    <div>
                      <span className="text-slate-500 block text-[11px]">Largest Single Expense</span>
                      <strong className="text-slate-900 text-sm">{largestExpense.description}</strong>
                      <span className="text-slate-500 block text-[11px]">{largestExpense.category} · {largestExpense.date}</span>
                    </div>
                    <span className="text-base font-bold font-mono text-rose-700 tabular-nums">
                      -{formatCurrency(largestExpense.amount, currency)}
                    </span>
                  </div>
                ) : (
                  <div className="p-3 bg-slate-50 rounded-lg text-slate-500 text-center">
                    No expense entries in this period.
                  </div>
                )}

                {expenseBreakdown.length > 0 && (
                  <div className="p-3 bg-slate-50 rounded-lg flex items-center justify-between">
                    <div>
                      <span className="text-slate-500 block text-[11px]">Primary Expense Category</span>
                      <strong className="text-slate-900 text-sm">{expenseBreakdown[0].category}</strong>
                      <span className="text-slate-500 block text-[11px]">
                        {expenseBreakdown[0].percentage.toFixed(1)}% of total outlays
                      </span>
                    </div>
                    <span className="text-base font-bold font-mono text-slate-900 tabular-nums">
                      {formatCurrency(expenseBreakdown[0].total, currency)}
                    </span>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Top 5 Categories & Mini Trend Preview */}
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-bold text-slate-900">Top Spending Categories</h3>
              <button
                onClick={() => setReportTab('categories')}
                className="text-xs text-indigo-600 hover:text-indigo-800 font-medium"
              >
                View all categories breakdown →
              </button>
            </div>

            <div className="space-y-3">
              {expenseBreakdown.slice(0, 5).map((cat) => (
                <div key={cat.category} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: cat.color }} />
                      <span className="font-semibold text-slate-800">{cat.category}</span>
                      <span className="text-slate-400">({cat.count} txns)</span>
                    </div>
                    <div className="font-mono tabular-nums text-slate-900">
                      <strong>{formatCurrency(cat.total, currency)}</strong>
                      <span className="text-slate-400 ml-2">({cat.percentage.toFixed(1)}%)</span>
                    </div>
                  </div>
                  <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all"
                      style={{ width: `${cat.percentage}%`, backgroundColor: cat.color }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: CATEGORY DISTRIBUTION (DONUT CHART & DETAIL TABLE) */}
      {reportTab === 'categories' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* SVG Donut Chart */}
            <div className="lg:col-span-5 bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex flex-col items-center justify-center">
              <h3 className="text-sm font-bold text-slate-900 mb-2 w-full text-left">
                Expense Distribution
              </h3>

              {expenseBreakdown.length === 0 ? (
                <div className="py-12 text-center text-slate-400 text-xs">
                  No expense data to render chart.
                </div>
              ) : (
                <div className="relative w-64 h-64 my-4">
                  <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90 transform">
                    {(() => {
                      let accumulatedAngle = 0;
                      return expenseBreakdown.map((slice) => {
                        const sliceAngle = (slice.percentage / 100) * 360;
                        const strokeDasharray = `${(slice.percentage / 100) * 251.2} 251.2`;
                        const strokeDashoffset = -((accumulatedAngle / 360) * 251.2);
                        accumulatedAngle += sliceAngle;

                        const isHovered = hoveredSlice === slice.category;

                        return (
                          <circle
                            key={slice.category}
                            cx="50"
                            cy="50"
                            r="40"
                            fill="transparent"
                            stroke={slice.color}
                            strokeWidth={isHovered ? '16' : '12'}
                            strokeDasharray={strokeDasharray}
                            strokeDashoffset={strokeDashoffset}
                            className="transition-all duration-200 cursor-pointer"
                            onMouseEnter={() => setHoveredSlice(slice.category)}
                            onMouseLeave={() => setHoveredSlice(null)}
                          />
                        );
                      });
                    })()}
                  </svg>

                  {/* Donut Center Display */}
                  <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none text-center">
                    <span className="text-[10px] uppercase font-semibold text-slate-400">
                      {hoveredSlice || 'Total Spend'}
                    </span>
                    <span className="text-lg font-bold font-mono text-slate-900 tabular-nums">
                      {hoveredSlice
                        ? formatCurrency(
                            expenseBreakdown.find((b) => b.category === hoveredSlice)?.total || 0,
                            currency
                          )
                        : formatCurrency(expense, currency)}
                    </span>
                    <span className="text-[10px] text-slate-500 font-mono">
                      {hoveredSlice
                        ? `${(expenseBreakdown.find((b) => b.category === hoveredSlice)?.percentage || 0).toFixed(1)}%`
                        : `${expenseBreakdown.length} Categories`}
                    </span>
                  </div>
                </div>
              )}
            </div>

            {/* Category Ranking Table */}
            <div className="lg:col-span-7 bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
              <h3 className="text-sm font-bold text-slate-900 mb-3">Itemized Expense Rankings</h3>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200">
                    <tr>
                      <th className="py-2.5 px-3">Category</th>
                      <th className="py-2.5 px-2 text-right">Transactions</th>
                      <th className="py-2.5 px-3 text-right">Avg Ticket</th>
                      <th className="py-2.5 px-3 text-right">Total</th>
                      <th className="py-2.5 px-3 text-right">Share</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {expenseBreakdown.map((item) => (
                      <tr
                        key={item.category}
                        onMouseEnter={() => setHoveredSlice(item.category)}
                        onMouseLeave={() => setHoveredSlice(null)}
                        className={`hover:bg-slate-50/80 transition-colors cursor-pointer ${
                          hoveredSlice === item.category ? 'bg-slate-50 font-semibold' : ''
                        }`}
                      >
                        <td className="py-2.5 px-3 whitespace-nowrap">
                          <div className="flex items-center gap-2">
                            <span
                              className="w-2.5 h-2.5 rounded-full shrink-0"
                              style={{ backgroundColor: item.color }}
                            />
                            <span className="font-medium text-slate-900">{item.category}</span>
                          </div>
                        </td>
                        <td className="py-2.5 px-2 text-right font-mono text-slate-600">
                          {item.count}
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono text-slate-600">
                          {formatCurrency(item.total / item.count, currency)}
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono font-bold text-slate-900">
                          {formatCurrency(item.total, currency)}
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono text-slate-600">
                          {item.percentage.toFixed(1)}%
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* Income Sources Table */}
          {incomeBreakdown.length > 0 && (
            <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
              <h3 className="text-sm font-bold text-slate-900 mb-3">Income Source Breakdown</h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {incomeBreakdown.map((src) => (
                  <div key={src.category} className="p-3 bg-emerald-50/50 border border-emerald-100 rounded-lg">
                    <span className="text-xs text-slate-600 block">{src.category}</span>
                    <div className="text-base font-bold font-mono text-emerald-800 tabular-nums mt-0.5">
                      {formatCurrency(src.total, currency)}
                    </div>
                    <span className="text-[11px] text-emerald-700 font-mono mt-1 block">
                      {src.percentage.toFixed(1)}% of total income ({src.count} payments)
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 3: TREND CHART (SVG BAR & NET LINE) */}
      {reportTab === 'trends' && (
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Cash Inflow vs Outflow Over Time</h3>
              <p className="text-xs text-slate-500">
                Visualizing daily cash movement with surplus/deficit
              </p>
            </div>
            <div className="flex items-center gap-4 text-xs">
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-xs bg-emerald-500" />
                <span className="text-slate-600">Inflow</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-xs bg-rose-500" />
                <span className="text-slate-600">Outflow</span>
              </div>
            </div>
          </div>

          {trendData.length === 0 ? (
            <div className="py-16 text-center text-slate-400 text-xs">
              No transactions recorded in this period to graph.
            </div>
          ) : (
            <div className="pt-4 overflow-x-auto">
              <div className="min-w-[600px] h-72 flex items-end gap-2 sm:gap-3 pb-6 border-b border-slate-200 px-2">
                {trendData.map((d) => {
                  const incomeHeight = maxTrendVal > 0 ? (d.income / maxTrendVal) * 200 : 0;
                  const expenseHeight = maxTrendVal > 0 ? (d.expense / maxTrendVal) * 200 : 0;

                  return (
                    <div
                      key={d.date}
                      className="flex-1 flex flex-col items-center justify-end h-full group relative"
                    >
                      {/* Tooltip on hover */}
                      <div className="absolute -top-16 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none bg-slate-900 text-white text-[10px] py-1.5 px-2.5 rounded shadow-lg whitespace-nowrap z-20 font-mono">
                        <div className="font-bold text-slate-200">{d.date}</div>
                        <div className="text-emerald-400">+{formatCurrency(d.income, currency)}</div>
                        <div className="text-rose-400">-{formatCurrency(d.expense, currency)}</div>
                        <div className="border-t border-slate-700 pt-0.5 mt-0.5">
                          Net: {formatCurrency(d.net, currency)}
                        </div>
                      </div>

                      {/* Bar Pair */}
                      <div className="w-full flex items-end justify-center gap-1 h-52">
                        {/* Income Bar */}
                        <div
                          style={{ height: `${Math.max(4, incomeHeight)}px` }}
                          className={`w-1/2 rounded-t transition-all ${
                            d.income > 0 ? 'bg-emerald-500 group-hover:bg-emerald-600' : 'bg-transparent'
                          }`}
                        />
                        {/* Expense Bar */}
                        <div
                          style={{ height: `${Math.max(4, expenseHeight)}px` }}
                          className={`w-1/2 rounded-t transition-all ${
                            d.expense > 0 ? 'bg-rose-500 group-hover:bg-rose-600' : 'bg-transparent'
                          }`}
                        />
                      </div>

                      {/* Date Label */}
                      <span className="text-[10px] text-slate-500 mt-2 font-mono whitespace-nowrap transform -rotate-45 sm:rotate-0 origin-top-left">
                        {d.date.substring(5)}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 4: BUDGET VS ACTUAL */}
      {reportTab === 'budgets' && (
        <div className="space-y-6">
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Budget vs Actual Spend</h3>
                <p className="text-xs text-slate-500">
                  Tracking monthly spending limits against actual charges
                </p>
              </div>
            </div>

            {budgetComparisons.length === 0 ? (
              <div className="py-8 text-center text-slate-400 text-xs">
                No budgets configured yet. Visit the Budgets tab to set monthly limits!
              </div>
            ) : (
              <div className="space-y-5">
                {budgetComparisons.map((item) => (
                  <div key={item.category} className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2">
                        <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: item.color }} />
                        <span className="font-semibold text-slate-900">{item.category}</span>
                        {item.isOver && (
                          <span className="inline-flex items-center gap-1 text-[10px] font-bold text-rose-700 bg-rose-50 px-1.5 py-0.5 rounded">
                            <ShieldAlert className="w-3 h-3" /> Over Budget
                          </span>
                        )}
                        {item.isWarning && (
                          <span className="inline-flex items-center gap-1 text-[10px] font-bold text-amber-700 bg-amber-50 px-1.5 py-0.5 rounded">
                            <AlertTriangle className="w-3 h-3" /> Near Limit
                          </span>
                        )}
                      </div>

                      <div className="font-mono text-xs tabular-nums">
                        <strong className={item.isOver ? 'text-rose-700' : 'text-slate-900'}>
                          {formatCurrency(item.spent, currency)}
                        </strong>
                        <span className="text-slate-400"> of {formatCurrency(item.budget, currency)}</span>
                        <span className="text-slate-500 ml-2 font-bold">({item.percent.toFixed(0)}%)</span>
                      </div>
                    </div>

                    {/* Progress Bar */}
                    <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-300 ${
                          item.isOver
                            ? 'bg-rose-600'
                            : item.isWarning
                            ? 'bg-amber-500'
                            : 'bg-slate-800'
                        }`}
                        style={{ width: `${Math.min(100, item.percent)}%` }}
                      />
                    </div>

                    <div className="flex justify-between text-[11px] text-slate-400 font-mono">
                      <span>
                        {item.remaining >= 0 ? 'Remaining Allowance: ' : 'Exceeded By: '}
                        <strong className={item.remaining >= 0 ? 'text-emerald-700' : 'text-rose-700'}>
                          {formatCurrency(Math.abs(item.remaining), currency)}
                        </strong>
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 5: FORMAL PRINTABLE STATEMENT */}
      {reportTab === 'statement' && (
        <div className="bg-white rounded-xl border border-slate-200 p-8 shadow-xs print:p-0 print:border-0 print:shadow-none font-sans">
          {/* Printable Header */}
          <div className="flex items-start justify-between pb-6 border-b-2 border-slate-900">
            <div className="flex items-center gap-3">
              <img
                src="/logo.png"
                alt="Pocket Ledger"
                className="w-10 h-10 rounded-xl object-cover border border-slate-700 shadow-xs"
              />
              <div>
                <div className="text-2xl font-bold tracking-tight text-slate-900">Pocket Ledger</div>
                <div className="text-xs uppercase tracking-wider text-slate-500 font-semibold mt-0.5">
                  Made by MW Solutions • Financial Statement & Cash Flow Report
                </div>
              </div>
            </div>
            <div className="text-right text-xs text-slate-600 font-mono">
              <div>Statement Date: {new Date().toLocaleDateString()}</div>
              <div>Period: {startDateStr} - {endDateStr}</div>
              <div>Generated: System Audit</div>
            </div>
          </div>

          {/* Statement Summary Table */}
          <div className="my-6">
            <h4 className="text-xs uppercase tracking-wider font-bold text-slate-800 mb-2">
              1. Executive Cash Balance Summary
            </h4>
            <table className="w-full text-xs font-mono border border-slate-300">
              <tbody>
                <tr className="border-b border-slate-200 bg-slate-50">
                  <td className="py-2 px-3 font-semibold text-slate-700">Total Inflow (Income)</td>
                  <td className="py-2 px-3 text-right font-bold text-emerald-700">
                    +{formatCurrency(income, currency)}
                  </td>
                </tr>
                <tr className="border-b border-slate-200">
                  <td className="py-2 px-3 font-semibold text-slate-700">Total Outflow (Expenses)</td>
                  <td className="py-2 px-3 text-right font-bold text-rose-700">
                    -{formatCurrency(expense, currency)}
                  </td>
                </tr>
                <tr className="bg-slate-100 font-bold border-b border-slate-300">
                  <td className="py-2.5 px-3 text-slate-900 text-sm">Net Period Surplus / (Deficit)</td>
                  <td className={`py-2.5 px-3 text-right text-sm ${net >= 0 ? 'text-emerald-800' : 'text-rose-800'}`}>
                    {formatCurrency(net, currency)}
                  </td>
                </tr>
                <tr>
                  <td className="py-2 px-3 text-slate-600">Calculated Savings Rate</td>
                  <td className="py-2 px-3 text-right text-slate-900 font-semibold">
                    {savingsRate.toFixed(2)}%
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Statement Category Breakdown */}
          <div className="my-6">
            <h4 className="text-xs uppercase tracking-wider font-bold text-slate-800 mb-2">
              2. Outlay Category Breakdown
            </h4>
            <table className="w-full text-xs border border-slate-300">
              <thead className="bg-slate-100 font-semibold border-b border-slate-300">
                <tr>
                  <th className="py-2 px-3 text-left">Category Name</th>
                  <th className="py-2 px-3 text-right">Transactions</th>
                  <th className="py-2 px-3 text-right">Amount ({currency.code})</th>
                  <th className="py-2 px-3 text-right">% of Total</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 font-mono">
                {expenseBreakdown.map((row) => (
                  <tr key={row.category}>
                    <td className="py-2 px-3 font-sans font-medium text-slate-900">{row.category}</td>
                    <td className="py-2 px-3 text-right text-slate-600">{row.count}</td>
                    <td className="py-2 px-3 text-right font-bold">{formatCurrency(row.total, currency)}</td>
                    <td className="py-2 px-3 text-right text-slate-600">{row.percentage.toFixed(1)}%</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Statement Transaction Ledger */}
          <div className="my-6">
            <h4 className="text-xs uppercase tracking-wider font-bold text-slate-800 mb-2">
              3. Itemized Transaction Ledger ({periodTransactions.length} records)
            </h4>
            <table className="w-full text-[11px] border border-slate-300">
              <thead className="bg-slate-100 font-semibold border-b border-slate-300">
                <tr>
                  <th className="py-1.5 px-2 text-left">Date</th>
                  <th className="py-1.5 px-2 text-left">Type</th>
                  <th className="py-1.5 px-2 text-left">Category</th>
                  <th className="py-1.5 px-2 text-left">Description</th>
                  <th className="py-1.5 px-2 text-right">Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 font-mono">
                {periodTransactions.slice(0, 40).map((t) => (
                  <tr key={t.id}>
                    <td className="py-1.5 px-2 whitespace-nowrap">{t.date}</td>
                    <td className="py-1.5 px-2 capitalize">{t.type}</td>
                    <td className="py-1.5 px-2 font-sans">{t.category}</td>
                    <td className="py-1.5 px-2 font-sans truncate max-w-xs">{t.description}</td>
                    <td className={`py-1.5 px-2 text-right font-bold ${t.type === 'income' ? 'text-emerald-700' : 'text-slate-900'}`}>
                      {t.type === 'income' ? '+' : '-'}{formatCurrency(t.amount, currency)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {periodTransactions.length > 40 && (
              <p className="text-[10px] text-slate-400 mt-1 italic">
                * Truncated for print readability. Total records in period: {periodTransactions.length}.
              </p>
            )}
          </div>

          {/* Statement Sign-off */}
          <div className="pt-8 mt-8 border-t border-slate-200 flex justify-between text-xs text-slate-500">
            <div>Verified Personal & Business Financial Ledger</div>
            <div>Pocket Ledger • Made by MW Solutions</div>
          </div>
        </div>
      )}
    </div>
  );
};
