import React from 'react';
import { useFinance } from '../context/FinanceContext';
import { Plus, ArrowDownRight, ArrowUpRight, Wallet, SlidersHorizontal, RefreshCw } from 'lucide-react';

interface NavbarProps {
  currentTab: 'daily' | 'transactions' | 'reports' | 'budgets' | 'settings';
  setCurrentTab: (tab: 'daily' | 'transactions' | 'reports' | 'budgets' | 'settings') => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentTab, setCurrentTab }) => {
  const { openAddModal, currency, setCurrency } = useFinance();

  return (
    <header className="border-b border-slate-200 bg-white sticky top-0 z-30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8 h-16">
          {/* Zone 1: Single text element wordmark */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setCurrentTab('daily')}
              className="text-left group cursor-pointer"
            >
              <div className="flex items-center gap-2.5">
                <img
                  src="/logo.png"
                  alt="Pocket Ledger"
                  className="w-8 h-8 rounded-lg object-cover shadow-xs border border-slate-700/20"
                />
                <div className="flex flex-col text-left">
                  <span className="text-base font-bold tracking-tight text-slate-900 whitespace-nowrap leading-tight">
                    Pocket Ledger
                  </span>
                  <span className="text-[10px] text-slate-500 font-medium leading-tight">
                    by MW Solutions
                  </span>
                </div>
              </div>
            </button>
          </div>

          {/* Zone 2: 4-5 single-line clean text navigation links */}
          <nav className="hidden md:flex items-center gap-1 sm:gap-2">
            <button
              onClick={() => setCurrentTab('daily')}
              className={`px-3 py-2 text-sm font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                currentTab === 'daily'
                  ? 'bg-slate-100 text-slate-900 font-semibold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              Daily Ledger
            </button>
            <button
              onClick={() => setCurrentTab('transactions')}
              className={`px-3 py-2 text-sm font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                currentTab === 'transactions'
                  ? 'bg-slate-100 text-slate-900 font-semibold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              All Transactions
            </button>
            <button
              onClick={() => setCurrentTab('reports')}
              className={`px-3 py-2 text-sm font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                currentTab === 'reports'
                  ? 'bg-slate-100 text-slate-900 font-semibold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              Reports & Analytics
            </button>
            <button
              onClick={() => setCurrentTab('budgets')}
              className={`px-3 py-2 text-sm font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                currentTab === 'budgets'
                  ? 'bg-slate-100 text-slate-900 font-semibold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              Budgets
            </button>
            <button
              onClick={() => setCurrentTab('settings')}
              className={`px-3 py-2 text-sm font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                currentTab === 'settings'
                  ? 'bg-slate-100 text-slate-900 font-semibold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              Settings
            </button>
          </nav>

          {/* Zone 3: Primary Action & Quick Tools */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">

            {/* Quick Income Button */}
            <button
              onClick={() => openAddModal('income')}
              className="hidden sm:inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200/80 rounded-lg transition-colors whitespace-nowrap"
            >
              <ArrowDownRight className="w-3.5 h-3.5" />
              <span>+ Income</span>
            </button>

            {/* Primary Action Button: Add Entry */}
            <button
              onClick={() => openAddModal('expense')}
              className="inline-flex items-center gap-2 px-3.5 py-2 text-xs sm:text-sm font-semibold text-white bg-slate-900 hover:bg-slate-800 active:bg-slate-950 rounded-lg transition-colors shadow-sm whitespace-nowrap cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Add Entry</span>
            </button>
          </div>
        </div>

        {/* Mobile Navigation bar */}
        <div className="md:hidden flex items-center justify-around border-t border-slate-100 py-2 overflow-x-auto text-xs">
          <button
            onClick={() => setCurrentTab('daily')}
            className={`px-2.5 py-1.5 rounded font-medium whitespace-nowrap ${
              currentTab === 'daily' ? 'bg-slate-900 text-white' : 'text-slate-600'
            }`}
          >
            Daily
          </button>
          <button
            onClick={() => setCurrentTab('transactions')}
            className={`px-2.5 py-1.5 rounded font-medium whitespace-nowrap ${
              currentTab === 'transactions' ? 'bg-slate-900 text-white' : 'text-slate-600'
            }`}
          >
            Transactions
          </button>
          <button
            onClick={() => setCurrentTab('reports')}
            className={`px-2.5 py-1.5 rounded font-medium whitespace-nowrap ${
              currentTab === 'reports' ? 'bg-slate-900 text-white' : 'text-slate-600'
            }`}
          >
            Reports
          </button>
          <button
            onClick={() => setCurrentTab('budgets')}
            className={`px-2.5 py-1.5 rounded font-medium whitespace-nowrap ${
              currentTab === 'budgets' ? 'bg-slate-900 text-white' : 'text-slate-600'
            }`}
          >
            Budgets
          </button>
          <button
            onClick={() => setCurrentTab('settings')}
            className={`px-2.5 py-1.5 rounded font-medium whitespace-nowrap ${
              currentTab === 'settings' ? 'bg-slate-900 text-white' : 'text-slate-600'
            }`}
          >
            Settings
          </button>
        </div>
      </div>
    </header>
  );
};
