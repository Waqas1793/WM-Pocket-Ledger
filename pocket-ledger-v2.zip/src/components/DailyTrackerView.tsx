import React, { useState } from 'react';
import { useFinance } from '../context/FinanceContext';
import { PaymentMethod, TransactionType } from '../types/finance';
import {
  calculateTotals,
  formatCurrency,
  formatDateLabel,
  formatFullDate,
  getCurrentTimeString,
  getDailyAggregates,
  getTodayDateString,
} from '../utils/formatters';
import {
  ChevronLeft,
  ChevronRight,
  Plus,
  ArrowDownRight,
  ArrowUpRight,
  Calendar,
  Trash2,
  Edit2,
  Clock,
  Sparkles,
  CreditCard,
  DollarSign,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';

export const DailyTrackerView: React.FC = () => {
  const {
    transactions,
    currency,
    categories,
    enablePaymentMethods,
    paymentMethods,
    addCategory,
    addTransaction,
    deleteTransaction,
    openAddModal,
  } = useFinance();

  const [selectedDate, setSelectedDate] = useState<string>(getTodayDateString());

  // Inline Quick Add state
  const [quickType, setQuickType] = useState<TransactionType>('expense');
  const [quickAmount, setQuickAmount] = useState<string>('');
  const [quickCategory, setQuickCategory] = useState<string>('');
  const [quickDescription, setQuickDescription] = useState<string>('');
  const [quickMethod, setQuickMethod] = useState<PaymentMethod>(() => paymentMethods[0] || 'Cash');

  // Filter transactions for the selected date
  const dayTransactions = transactions.filter((t) => t.date === selectedDate);
  const { income: dayIncome, expense: dayExpense, net: dayNet } = calculateTotals(dayTransactions);

  // Month-to-date totals for broader context
  const currentMonthPrefix = selectedDate.substring(0, 7); // 'YYYY-MM'
  const monthTransactions = transactions.filter((t) => t.date.startsWith(currentMonthPrefix));
  const { income: monthIncome, expense: monthExpense, net: monthNet, savingsRate: monthSavingsRate } = calculateTotals(monthTransactions);

  // Last 7 days overview
  const recentDays = getDailyAggregates(transactions, 7);

  // Navigate dates
  const handleDateShift = (daysDelta: number) => {
    const [year, month, day] = selectedDate.split('-').map(Number);
    const d = new Date(year, month - 1, day);
    d.setDate(d.getDate() + daysDelta);
    const newY = d.getFullYear();
    const newM = String(d.getMonth() + 1).padStart(2, '0');
    const newD = String(d.getDate()).padStart(2, '0');
    setSelectedDate(`${newY}-${newM}-${newD}`);
  };

  const handleQuickAdd = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(quickAmount);
    if (isNaN(amount) || amount <= 0 || !quickDescription.trim()) return;

    // Pick suitable category if not chosen
    let catToUse = quickCategory;
    if (!catToUse) {
      const candidates = categories.filter((c) => c.type === quickType || c.type === 'both');
      if (candidates.length > 0) {
        catToUse = candidates[0].name;
      } else {
        catToUse = quickType === 'expense' ? 'Expenses' : 'Income';
        addCategory({
          name: catToUse,
          type: quickType,
          color: quickType === 'expense' ? '#ef4444' : '#10b981',
          iconName: 'Tag',
        });
      }
    }

    const methodToSave = enablePaymentMethods ? (quickMethod || paymentMethods[0] || 'Cash') : 'Cash';

    addTransaction({
      type: quickType,
      amount,
      category: catToUse,
      date: selectedDate,
      time: getCurrentTimeString(),
      description: quickDescription.trim(),
      paymentMethod: methodToSave,
      status: 'cleared',
    });

    setQuickAmount('');
    setQuickDescription('');
  };

  const availableCategories = categories.filter(
    (c) => c.type === quickType || c.type === 'both'
  );

  return (
    <div className="space-y-6">
      {/* Date Navigation & Context Banner */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 sm:p-5 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <button
              onClick={() => handleDateShift(-1)}
              className="p-2 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
              title="Previous Day"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-slate-400" />
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="font-mono text-sm sm:text-base font-semibold text-slate-900 bg-transparent border-0 focus:ring-0 cursor-pointer"
              />
              <span className="text-xs font-medium text-slate-500 bg-slate-100 px-2.5 py-0.5 rounded-md">
                {formatDateLabel(selectedDate)}
              </span>
            </div>

            <button
              onClick={() => handleDateShift(1)}
              className="p-2 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
              title="Next Day"
            >
              <ChevronRight className="w-5 h-5" />
            </button>

            {selectedDate !== getTodayDateString() && (
              <button
                onClick={() => setSelectedDate(getTodayDateString())}
                className="text-xs text-indigo-600 hover:text-indigo-800 font-medium px-2 py-1 bg-indigo-50 hover:bg-indigo-100 rounded transition-colors ml-2"
              >
                Jump to Today
              </button>
            )}
          </div>

          <div className="flex items-center gap-4 text-xs text-slate-500 border-t sm:border-t-0 pt-2 sm:pt-0">
            <div>
              <span>Month Inflow: </span>
              <span className="font-mono font-medium text-slate-800 tabular-nums">
                {formatCurrency(monthIncome, currency)}
              </span>
            </div>
            <span aria-hidden="true">·</span>
            <div>
              <span>Month Outflow: </span>
              <span className="font-mono font-medium text-slate-800 tabular-nums">
                {formatCurrency(monthExpense, currency)}
              </span>
            </div>
            <span aria-hidden="true">·</span>
            <div>
              <span>Net: </span>
              <span
                className={`font-mono font-semibold tabular-nums ${
                  monthNet >= 0 ? 'text-emerald-700' : 'text-rose-700'
                }`}
              >
                {formatCurrency(monthNet, currency)}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Daily Snapshot Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {/* Income Card */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Day Income</span>
            <div className="p-1.5 bg-emerald-50 text-emerald-700 rounded-lg">
              <ArrowDownRight className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-bold font-mono text-emerald-700 tabular-nums">
            {formatCurrency(dayIncome, currency)}
          </div>
          <div className="text-xs text-slate-500 mt-2 flex items-center gap-1.5">
            <span>
              {dayTransactions.filter((t) => t.type === 'income').length} receipt(s)
            </span>
          </div>
        </div>

        {/* Expense Card */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Day Expense</span>
            <div className="p-1.5 bg-rose-50 text-rose-700 rounded-lg">
              <ArrowUpRight className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-bold font-mono text-rose-700 tabular-nums">
            {formatCurrency(dayExpense, currency)}
          </div>
          <div className="text-xs text-slate-500 mt-2 flex items-center gap-1.5">
            <span>
              {dayTransactions.filter((t) => t.type === 'expense').length} expense(s)
            </span>
          </div>
        </div>

        {/* Net Flow Card */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Net Cash Flow</span>
            <div
              className={`p-1.5 rounded-lg ${
                dayNet >= 0 ? 'bg-emerald-50 text-emerald-700' : 'bg-rose-50 text-rose-700'
              }`}
            >
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div
            className={`text-2xl sm:text-3xl font-bold font-mono tabular-nums ${
              dayNet >= 0 ? 'text-emerald-700' : 'text-rose-700'
            }`}
          >
            {formatCurrency(dayNet, currency)}
          </div>
          <div className="text-xs text-slate-500 mt-2">
            {dayNet > 0 ? (
              <span className="text-emerald-700 font-medium">Daily Surplus</span>
            ) : dayNet < 0 ? (
              <span className="text-rose-700 font-medium">Daily Deficit</span>
            ) : (
              <span>Break-even</span>
            )}
          </div>
        </div>
      </div>

      {/* Quick In-Line Add Toolbar (Sub-5-second entry) */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
        <div className="flex items-center justify-between mb-3">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
            Quick Entry for {formatDateLabel(selectedDate)}
          </span>
          <button
            onClick={() => openAddModal(quickType)}
            className="text-xs text-slate-500 hover:text-slate-900 font-medium transition-colors"
          >
            Open detailed form →
          </button>
        </div>

        <form onSubmit={handleQuickAdd} className="grid grid-cols-1 sm:grid-cols-12 gap-2.5">
          {/* Type Toggle */}
          <div className="sm:col-span-2 flex bg-slate-100 p-1 rounded-lg">
            <button
              type="button"
              onClick={() => setQuickType('expense')}
              className={`flex-1 py-1.5 text-xs font-semibold rounded transition-colors ${
                quickType === 'expense'
                  ? 'bg-white text-rose-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              - Expense
            </button>
            <button
              type="button"
              onClick={() => setQuickType('income')}
              className={`flex-1 py-1.5 text-xs font-semibold rounded transition-colors ${
                quickType === 'income'
                  ? 'bg-white text-emerald-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              + Income
            </button>
          </div>

          {/* Amount */}
          <div className="sm:col-span-2 relative">
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 font-mono text-sm">
              {currency.symbol}
            </span>
            <input
              type="number"
              step="0.01"
              min="0"
              placeholder="0.00"
              value={quickAmount}
              onChange={(e) => setQuickAmount(e.target.value)}
              className="w-full pl-7 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm font-bold font-mono text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-slate-900"
            />
          </div>

          {/* Description */}
          <div className={enablePaymentMethods ? 'sm:col-span-3' : 'sm:col-span-4'}>
            <input
              type="text"
              placeholder={quickType === 'expense' ? 'What did you spend on?' : 'Where did income come from?'}
              value={quickDescription}
              onChange={(e) => setQuickDescription(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-slate-900"
            />
          </div>

          {/* Category */}
          <div className={enablePaymentMethods ? 'sm:col-span-2' : 'sm:col-span-2'}>
            <select
              value={quickCategory}
              onChange={(e) => setQuickCategory(e.target.value)}
              className="w-full px-2.5 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-slate-900"
            >
              <option value="">Category...</option>
              {availableCategories.map((c) => (
                <option key={c.id} value={c.name}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          {/* Payment Method (if enabled) */}
          {enablePaymentMethods && (
            <div className="sm:col-span-2">
              <select
                value={quickMethod}
                onChange={(e) => setQuickMethod(e.target.value)}
                className="w-full px-2.5 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-slate-900"
              >
                {paymentMethods.map((pm) => (
                  <option key={pm} value={pm}>
                    {pm}
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* Submit */}
          <div className={enablePaymentMethods ? 'sm:col-span-1' : 'sm:col-span-2'}>
            <button
              type="submit"
              disabled={!quickAmount || !quickDescription}
              className="w-full py-2 px-3 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 disabled:opacity-40 disabled:cursor-not-allowed rounded-lg transition-colors flex items-center justify-center gap-1.5 shadow-xs cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Log</span>
            </button>
          </div>
        </form>
      </div>

      {/* Main Content Split: Today's Itemized Entries & 7-Day Activity Glance */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Today's Transactions List */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
          <div className="flex items-center justify-between pb-4 border-b border-slate-100">
            <div>
              <h3 className="text-base font-bold text-slate-900">
                Ledger Entries ({dayTransactions.length})
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                {formatFullDate(selectedDate)}
              </p>
            </div>

            <button
              onClick={() => openAddModal('expense')}
              className="flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>New Entry</span>
            </button>
          </div>

          {dayTransactions.length === 0 ? (
            <div className="py-12 text-center">
              <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-400 mx-auto flex items-center justify-center mb-3">
                <Clock className="w-6 h-6" />
              </div>
              <h4 className="text-sm font-semibold text-slate-900">No entries recorded for this date</h4>
              <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1 mb-4">
                Use the quick entry bar above or click below to record your daily income or expense.
              </p>
              <div className="flex items-center justify-center gap-2">
                <button
                  onClick={() => openAddModal('expense')}
                  className="px-3.5 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors"
                >
                  Log First Expense
                </button>
                <button
                  onClick={() => openAddModal('income')}
                  className="px-3.5 py-2 text-xs font-semibold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 rounded-lg transition-colors border border-emerald-200"
                >
                  Log First Income
                </button>
              </div>
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {dayTransactions.map((tx) => {
                const categoryConfig = categories.find((c) => c.name === tx.category);
                return (
                  <div
                    key={tx.id}
                    className="py-3.5 flex items-center justify-between gap-4 hover:bg-slate-50/60 transition-colors px-2 rounded-lg"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div
                        className="w-2.5 h-2.5 rounded-full shrink-0"
                        style={{ backgroundColor: categoryConfig?.color || '#94a3b8' }}
                      />
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-semibold text-slate-900 truncate">
                            {tx.description}
                          </span>
                          {tx.status === 'pending' && (
                            <span className="text-[10px] font-medium text-amber-700 bg-amber-50 px-1.5 py-0.5 rounded">
                              Pending
                            </span>
                          )}
                        </div>
                        <div className="flex items-center gap-2 text-xs text-slate-500 mt-0.5">
                          <span>{tx.category}</span>
                          {enablePaymentMethods && (
                            <>
                              <span aria-hidden="true">·</span>
                              <span className="capitalize">{tx.paymentMethod.replace('_', ' ')}</span>
                            </>
                          )}
                          {tx.time && (
                            <>
                              <span aria-hidden="true">·</span>
                              <span className="font-mono">{tx.time}</span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 shrink-0">
                      <div className="text-right">
                        <div
                          className={`text-sm sm:text-base font-bold font-mono tabular-nums ${
                            tx.type === 'income' ? 'text-emerald-700' : 'text-slate-900'
                          }`}
                        >
                          {tx.type === 'income' ? '+' : '-'}
                          {formatCurrency(tx.amount, currency)}
                        </div>
                      </div>

                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => openAddModal(tx.type, tx)}
                          title="Edit transaction"
                          className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded transition-colors"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => deleteTransaction(tx.id)}
                          title="Delete transaction"
                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition-colors"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Right 1 Col: 7-Day Activity & Category Glance */}
        <div className="space-y-6">
          {/* Mini 7-Day Bar Sparkline */}
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
            <h3 className="text-sm font-bold text-slate-900 mb-3">
              7-Day Activity Glance
            </h3>
            <div className="space-y-3">
              {recentDays.map((day) => {
                const isSelected = day.date === selectedDate;
                const maxVal = Math.max(
                  ...recentDays.map((d) => Math.max(d.income, d.expense)),
                  100
                );
                const expensePercent = Math.min(100, (day.expense / maxVal) * 100);
                const incomePercent = Math.min(100, (day.income / maxVal) * 100);

                return (
                  <div
                    key={day.date}
                    onClick={() => setSelectedDate(day.date)}
                    className={`p-2 rounded-lg cursor-pointer transition-colors ${
                      isSelected ? 'bg-slate-100' : 'hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center justify-between text-xs mb-1">
                      <span className={`font-medium ${isSelected ? 'font-bold text-slate-900' : 'text-slate-600'}`}>
                        {day.label}
                      </span>
                      <div className="font-mono text-[11px] tabular-nums">
                        {day.income > 0 && (
                          <span className="text-emerald-700 mr-2">
                            +{formatCurrency(day.income, currency)}
                          </span>
                        )}
                        <span className="text-slate-700">
                          -{formatCurrency(day.expense, currency)}
                        </span>
                      </div>
                    </div>
                    {/* Visual bar */}
                    <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden flex gap-0.5">
                      {day.income > 0 && (
                        <div
                          className="h-full bg-emerald-500 rounded-full"
                          style={{ width: `${incomePercent}%` }}
                        />
                      )}
                      {day.expense > 0 && (
                        <div
                          className="h-full bg-rose-500 rounded-full"
                          style={{ width: `${expensePercent}%` }}
                        />
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Quick tips & savings note */}
          <div className="bg-indigo-50/60 rounded-xl border border-indigo-100 p-4">
            <div className="flex items-start gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
              <div className="text-xs text-indigo-950">
                <span className="font-bold block mb-1">Monthly Savings Rate</span>
                <span>
                  You have saved <strong className="font-mono">{monthSavingsRate.toFixed(1)}%</strong> of your income this month. Keep logging daily to maintain accurate spending forecasts and tax preparation.
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
