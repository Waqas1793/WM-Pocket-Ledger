import React from 'react';
import { useFinance } from '../context/FinanceContext';

interface MobileHeaderProps {
  title?: string;
}

export const MobileHeader: React.FC<MobileHeaderProps> = ({ title }) => {
  const { currency } = useFinance();

  return (
    <header className="sticky top-0 z-30 bg-white/90 backdrop-blur-md border-b border-slate-100">
      <div className="max-w-md mx-auto px-4 h-14 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <img
            src="/logo.png"
            alt="Pocket Ledger"
            className="w-8 h-8 rounded-lg object-cover shadow-xs border border-slate-700/20"
          />
          <div className="flex flex-col">
            <span className="font-bold text-sm tracking-tight text-slate-900 leading-tight">
              {title === 'LedgerPulse' || !title ? 'Pocket Ledger' : title}
            </span>
            <span className="text-[10px] text-slate-400 font-medium leading-tight">
              by MW Solutions
            </span>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <span className="px-2.5 py-1 bg-slate-100 text-slate-700 font-mono text-xs font-semibold rounded-lg border border-slate-200/60">
            {currency.symbol.trim() || currency.code}
          </span>
        </div>
      </div>
    </header>
  );
};
