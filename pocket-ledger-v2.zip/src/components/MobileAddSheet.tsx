import React, { useEffect, useState } from 'react';
import { useFinance } from '../context/FinanceContext';
import { PaymentMethod, TransactionType } from '../types/finance';
import { getCurrentTimeString, getTodayDateString } from '../utils/formatters';
import { getCategoryIcon } from '../utils/categoryIcons';
import { X, ArrowDownRight, ArrowUpRight, Check, Calendar } from 'lucide-react';

export const MobileAddSheet: React.FC = () => {
  const {
    isAddModalOpen,
    closeModal,
    addTransaction,
    updateTransaction,
    editingTransaction,
    defaultModalType,
    categories,
    addCategory,
    currency,
    enablePaymentMethods,
    paymentMethods,
  } = useFinance();

  const [type, setType] = useState<TransactionType>(defaultModalType);
  const [amountStr, setAmountStr] = useState<string>('');
  const [category, setCategory] = useState<string>('');
  const [date, setDate] = useState<string>(getTodayDateString());
  const [description, setDescription] = useState<string>('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>(() => paymentMethods[0] || 'Cash');
  const [errorMsg, setErrorMsg] = useState<string>('');

  // Inline Category Creator
  const [isAddingCategoryInline, setIsAddingCategoryInline] = useState<boolean>(false);
  const [inlineCatName, setInlineCatName] = useState<string>('');

  useEffect(() => {
    const defaultMethod = paymentMethods[0] || 'Cash';
    if (editingTransaction) {
      setType(editingTransaction.type);
      setAmountStr(editingTransaction.amount.toString());
      setCategory(editingTransaction.category);
      setDate(editingTransaction.date);
      setDescription(editingTransaction.description);
      setPaymentMethod(editingTransaction.paymentMethod || defaultMethod);
    } else {
      setType(defaultModalType);
      setAmountStr('');
      setDate(getTodayDateString());
      setDescription('');
      setPaymentMethod(defaultMethod);

      const suitable = categories.filter((c) => c.type === defaultModalType || c.type === 'both');
      if (suitable.length > 0) {
        setCategory(suitable[0].name);
      } else {
        setCategory('');
      }
    }
    setErrorMsg('');
    setIsAddingCategoryInline(false);
    setInlineCatName('');
  }, [editingTransaction, defaultModalType, isAddModalOpen, categories, paymentMethods]);

  const handleTypeToggle = (newType: TransactionType) => {
    setType(newType);
    const suitable = categories.filter((c) => c.type === newType || c.type === 'both');
    if (suitable.length > 0 && !suitable.some((c) => c.name === category)) {
      setCategory(suitable[0].name);
    } else if (suitable.length === 0) {
      setCategory('');
    }
  };

  const handleQuickAddCategory = () => {
    const clean = inlineCatName.trim();
    if (!clean) return;

    const colors = ['#10b981', '#f59e0b', '#6366f1', '#ec4899', '#0ea5e9', '#8b5cf6'];
    const randomColor = colors[Math.floor(Math.random() * colors.length)];

    addCategory({
      name: clean,
      type: type,
      color: randomColor,
    });

    setCategory(clean);
    setInlineCatName('');
    setIsAddingCategoryInline(false);
  };

  const handleSave = () => {
    const val = parseFloat(amountStr);
    if (isNaN(val) || val <= 0) {
      setErrorMsg('Please enter an amount');
      return;
    }
    if (!description.trim()) {
      setErrorMsg('Please enter a short note or merchant');
      return;
    }

    let finalCategory = category;
    if (!finalCategory) {
      if (inlineCatName.trim()) {
        finalCategory = inlineCatName.trim();
        addCategory({
          name: finalCategory,
          type,
          color: '#6366f1',
        });
      } else {
        const suitable = categories.filter((c) => c.type === type || c.type === 'both');
        if (suitable.length > 0) {
          finalCategory = suitable[0].name;
        } else {
          setErrorMsg('Please enter or select a category below');
          setIsAddingCategoryInline(true);
          return;
        }
      }
    }

    const methodToSave = enablePaymentMethods ? (paymentMethod || paymentMethods[0] || 'Cash') : 'Cash';

    if (editingTransaction) {
      updateTransaction(editingTransaction.id, {
        type,
        amount: val,
        category: finalCategory,
        date,
        description: description.trim(),
        paymentMethod: methodToSave,
      });
    } else {
      addTransaction({
        type,
        amount: val,
        category: finalCategory,
        date,
        time: getCurrentTimeString(),
        description: description.trim(),
        paymentMethod: methodToSave,
        status: 'cleared',
      });
    }

    closeModal();
  };

  if (!isAddModalOpen) return null;

  const suitableCategories = categories.filter(
    (c) => c.type === type || c.type === 'both'
  );

  return (
    <div
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-200"
      onClick={closeModal}
    >
      <div
        className="bg-white w-full max-w-md rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh] animate-in slide-in-from-bottom duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Grab Handle */}
        <div className="pt-3 pb-1">
          <div className="w-10 h-1.5 bg-slate-200 rounded-full mx-auto" />
        </div>

        {/* Header */}
        <div className="px-5 py-2 flex items-center justify-between border-b border-slate-100">
          <h2 className="text-base font-bold text-slate-900">
            {editingTransaction ? 'Edit Entry' : 'Add Transaction'}
          </h2>
          <button
            onClick={closeModal}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Form Content */}
        <div className="p-5 space-y-4 overflow-y-auto">
          {/* Expense / Income Switch */}
          <div className="grid grid-cols-2 gap-1.5 p-1 bg-slate-100 rounded-2xl">
            <button
              type="button"
              onClick={() => handleTypeToggle('expense')}
              className={`py-2 text-xs font-bold rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                type === 'expense'
                  ? 'bg-white text-rose-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <ArrowUpRight className="w-4 h-4 text-rose-600" />
              <span>Expense</span>
            </button>
            <button
              type="button"
              onClick={() => handleTypeToggle('income')}
              className={`py-2 text-xs font-bold rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                type === 'income'
                  ? 'bg-white text-emerald-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <ArrowDownRight className="w-4 h-4 text-emerald-600" />
              <span>Income</span>
            </button>
          </div>

          {/* Large Amount Field */}
          <div className="text-center py-2">
            <label className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block mb-1">
              Amount ({currency.code})
            </label>
            <div className="inline-flex items-center justify-center">
              <span className="text-3xl font-bold font-mono text-slate-400 mr-1">
                {currency.symbol}
              </span>
              <input
                type="number"
                step="0.01"
                min="0"
                placeholder="0.00"
                autoFocus
                value={amountStr}
                onChange={(e) => setAmountStr(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleSave();
                }}
                className="w-48 text-center text-3xl sm:text-4xl font-extrabold font-mono text-slate-900 bg-transparent border-0 focus:ring-0 focus:outline-none placeholder:text-slate-300"
              />
            </div>

            {/* Quick Denominations */}
            <div className="flex items-center justify-center gap-1.5 mt-2 overflow-x-auto pb-1">
              {[5, 10, 20, 50, 100].map((val) => (
                <button
                  key={val}
                  type="button"
                  onClick={() => {
                    const cur = parseFloat(amountStr) || 0;
                    setAmountStr((cur + val).toFixed(2));
                  }}
                  className="px-2.5 py-1 text-xs font-mono font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg transition-colors cursor-pointer"
                >
                  +{currency.symbol}{val}
                </button>
              ))}
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block mb-1">
              Note / Payee
            </label>
            <input
              type="text"
              placeholder={type === 'expense' ? 'e.g. Supermarket, Coffee, Uber' : 'e.g. Salary, Client payment'}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-slate-900"
            />
          </div>

          {/* Category Quick Grid & Creator */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                Select Category
              </label>
              <button
                type="button"
                onClick={() => setIsAddingCategoryInline(!isAddingCategoryInline)}
                className="text-[11px] font-bold text-indigo-600 hover:text-indigo-800 cursor-pointer"
              >
                {isAddingCategoryInline ? 'Cancel' : '+ New Category'}
              </button>
            </div>

            {/* Inline Quick Add Form if triggered or if categories are empty */}
            {(isAddingCategoryInline || suitableCategories.length === 0) && (
              <div className="mb-2 p-2 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
                <span className="text-[10px] text-slate-500 font-semibold block">
                  Add new {type} category:
                </span>
                <div className="flex items-center gap-1.5">
                  <input
                    type="text"
                    placeholder="e.g. Groceries, Rent, Fuel..."
                    value={inlineCatName}
                    onChange={(e) => setInlineCatName(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleQuickAddCategory();
                      }
                    }}
                    className="flex-1 px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs font-medium text-slate-800 focus:outline-none focus:ring-1 focus:ring-slate-900"
                  />
                  <button
                    type="button"
                    onClick={handleQuickAddCategory}
                    disabled={!inlineCatName.trim()}
                    className="px-3 py-1.5 bg-slate-900 text-white rounded-lg text-xs font-bold disabled:opacity-40 cursor-pointer"
                  >
                    Save
                  </button>
                </div>
              </div>
            )}

            {suitableCategories.length === 0 ? (
              <div className="p-3 bg-slate-50 border border-dashed border-slate-200 rounded-xl text-center text-xs text-slate-400">
                No {type} categories yet. Type a name above to create your category.
              </div>
            ) : (
              <div className="grid grid-cols-3 sm:grid-cols-4 gap-2 max-h-36 overflow-y-auto p-1">
                {suitableCategories.map((c) => {
                  const isSelected = category === c.name;
                  return (
                    <button
                      key={c.id}
                      type="button"
                      onClick={() => setCategory(c.name)}
                      className={`p-2 rounded-xl flex flex-col items-center justify-center text-center transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-slate-900 text-white font-bold shadow-xs'
                          : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200/60'
                      }`}
                    >
                      <div
                        className={`w-7 h-7 rounded-lg flex items-center justify-center mb-1 text-white ${
                          isSelected ? 'ring-2 ring-white/50' : ''
                        }`}
                        style={{ backgroundColor: c.color }}
                      >
                        {getCategoryIcon(c.name, 'w-3.5 h-3.5')}
                      </div>
                      <span className="text-[10px] truncate w-full leading-tight">{c.name}</span>
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* Date & Payment Method */}
          <div className={enablePaymentMethods ? 'grid grid-cols-2 gap-2 pt-1' : 'pt-1'}>
            <div>
              <label className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block mb-1">
                Date
              </label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono text-slate-900 focus:bg-white focus:outline-none"
              />
            </div>

            {enablePaymentMethods && (
              <div>
                <label className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block mb-1">
                  Method
                </label>
                <select
                  value={paymentMethod}
                  onChange={(e) => setPaymentMethod(e.target.value)}
                  className="w-full px-2.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:bg-white focus:outline-none"
                >
                  {paymentMethods.map((pm) => (
                    <option key={pm} value={pm}>
                      {pm}
                    </option>
                  ))}
                  {/* If editing transaction has a method not in active list, show it too */}
                  {!paymentMethods.includes(paymentMethod) && (
                    <option value={paymentMethod}>
                      {paymentMethod.replace('_', ' ')}
                    </option>
                  )}
                </select>
              </div>
            )}
          </div>

          {errorMsg && (
            <div className="p-2.5 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-xl">
              {errorMsg}
            </div>
          )}
        </div>

        {/* Sticky Bottom Full-Width CTA (Thumb-friendly) */}
        <div className="p-4 bg-slate-50 border-t border-slate-200">
          <button
            type="button"
            onClick={handleSave}
            className="w-full h-12 rounded-2xl bg-slate-900 hover:bg-slate-800 active:scale-[0.98] text-white font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-slate-900/10 transition-transform cursor-pointer"
          >
            <Check className="w-4 h-4 stroke-[2.5]" />
            <span>{editingTransaction ? 'Save Changes' : 'Record Transaction'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
