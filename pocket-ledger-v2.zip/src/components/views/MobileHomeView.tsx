import React, { useState } from 'react';
import { useFinance } from '../../context/FinanceContext';
import { calculateTotals, formatCurrency, formatDateLabel, getTodayDateString } from '../../utils/formatters';
import { getCategoryIcon } from '../../utils/categoryIcons';
import { ArrowDownRight, ArrowUpRight, Plus, Calendar, Trash2, Edit2, ChevronRight, Check } from 'lucide-react';
import { Transaction } from '../../types/finance';

export const MobileHomeView: React.FC = () => {
  const {
    transactions,
    currency,
    categories,
    userName,
    enablePaymentMethods,
    openAddModal,
    deleteTransaction,
  } = useFinance();
  const [selectedDate, setSelectedDate] = useState<string>(getTodayDateString());

  // Current Month calculation for the top Balance Card
  const currentMonthPrefix = getTodayDateString().substring(0, 7);
  const monthTransactions = transactions.filter((t) => t.date.startsWith(currentMonthPrefix));
  const { income: monthIncome, expense: monthExpense, net: monthNet, savingsRate } = calculateTotals(monthTransactions);

  // Selected Day transactions
  const dayTransactions = transactions.filter((t) => t.date === selectedDate);
  const { income: dayIncome, expense: dayExpense, net: dayNet } = calculateTotals(dayTransactions);

  // Generate 7-day strip around today
  const generateWeekDays = () => {
    const today = new Date();
    const days = [];
    for (let i = -4; i <= 2; i++) {
      const d = new Date(today);
      d.setDate(d.getDate() + i);
      const str = d.toISOString().split('T')[0];
      const dayName = d.toLocaleDateString('en-US', { weekday: 'short' });
      const dayNum = d.getDate();
      const isToday = str === getTodayDateString();
      const hasTx = transactions.some((t) => t.date === str);
      days.push({ str, dayName, dayNum, isToday, hasTx });
    }
    return days;
  };

  const weekDays = generateWeekDays();

  return (
    <div className="space-y-4 pb-20">
      {/* Balance & Month Flow Card */}
      <div className="bg-slate-900 text-white rounded-3xl p-5 shadow-sm relative overflow-hidden">
        <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
          <span className="font-medium text-slate-200">
            {userName ? `Hi, ${userName} 👋` : 'Net Cash Flow this Month'}
          </span>
          <span className="font-mono bg-slate-800 text-slate-300 px-2 py-0.5 rounded-full text-[10px]">
            {savingsRate.toFixed(0)}% Saved
          </span>
        </div>

        <div className="text-3xl font-extrabold font-mono tracking-tight tabular-nums mb-4">
          {monthNet >= 0 ? '+' : ''}
          {formatCurrency(monthNet, currency)}
        </div>

        {/* 2-Column Split: Inflow & Outflow */}
        <div className="grid grid-cols-2 gap-2 pt-3 border-t border-slate-800">
          <div className="bg-slate-800/60 rounded-xl p-2.5">
            <div className="flex items-center gap-1 text-[11px] text-slate-400 mb-0.5">
              <ArrowDownRight className="w-3.5 h-3.5 text-emerald-400" />
              <span>Income</span>
            </div>
            <div className="font-mono font-bold text-sm text-emerald-400 tabular-nums">
              +{formatCurrency(monthIncome, currency)}
            </div>
          </div>

          <div className="bg-slate-800/60 rounded-xl p-2.5">
            <div className="flex items-center gap-1 text-[11px] text-slate-400 mb-0.5">
              <ArrowUpRight className="w-3.5 h-3.5 text-rose-400" />
              <span>Expense</span>
            </div>
            <div className="font-mono font-bold text-sm text-rose-400 tabular-nums">
              -{formatCurrency(monthExpense, currency)}
            </div>
          </div>
        </div>
      </div>

      {/* Horizontal Date Scroller */}
      <div className="bg-white rounded-2xl p-2 border border-slate-200/80 shadow-xs">
        <div className="flex items-center justify-between gap-1 overflow-x-auto py-1">
          {weekDays.map((d) => {
            const isSelected = d.str === selectedDate;
            return (
              <button
                key={d.str}
                onClick={() => setSelectedDate(d.str)}
                className={`flex flex-col items-center justify-center flex-1 py-2 px-1 rounded-xl min-w-[42px] cursor-pointer transition-all ${
                  isSelected
                    ? 'bg-slate-900 text-white font-bold shadow-xs'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <span className="text-[10px] uppercase font-medium">{d.dayName}</span>
                <span className="text-sm font-bold font-mono mt-0.5">{d.dayNum}</span>
                <span
                  className={`w-1 h-1 rounded-full mt-1 ${
                    d.hasTx
                      ? isSelected
                        ? 'bg-emerald-400'
                        : 'bg-indigo-500'
                      : 'bg-transparent'
                  }`}
                />
              </button>
            );
          })}
        </div>
      </div>

      {/* Day Overview Strip */}
      <div className="flex items-center justify-between px-1 text-xs">
        <div className="flex items-center gap-1.5 font-bold text-slate-800">
          <span>{formatDateLabel(selectedDate)}</span>
          <span className="text-slate-400 font-normal">({dayTransactions.length} items)</span>
        </div>

        <div className="flex items-center gap-2 font-mono tabular-nums text-xs">
          {dayIncome > 0 && (
            <span className="text-emerald-700 font-bold">
              +{formatCurrency(dayIncome, currency)}
            </span>
          )}
          {dayExpense > 0 && (
            <span className="text-rose-700 font-bold">
              -{formatCurrency(dayExpense, currency)}
            </span>
          )}
        </div>
      </div>

      {/* Day Transactions List */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        {dayTransactions.length === 0 ? (
          <div className="py-12 px-4 text-center">
            <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-400 mx-auto flex items-center justify-center mb-3">
              <Calendar className="w-6 h-6" />
            </div>
            <h4 className="text-sm font-bold text-slate-800">No activity on this date</h4>
            <p className="text-xs text-slate-500 mt-1 mb-4">
              Tap the button below to quickly record an income or expense.
            </p>
            <button
              onClick={() => openAddModal('expense')}
              className="inline-flex items-center gap-2 px-4 py-2.5 bg-slate-900 text-white text-xs font-semibold rounded-xl shadow-xs active:scale-95 transition-transform cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Add Transaction</span>
            </button>
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {dayTransactions.map((tx) => {
              const catConfig = categories.find((c) => c.name === tx.category);
              const isIncome = tx.type === 'income';

              return (
                <div
                  key={tx.id}
                  className="p-3.5 flex items-center justify-between gap-3 hover:bg-slate-50/80 transition-colors"
                >
                  {/* Category Icon Badge */}
                  <div className="flex items-center gap-3 min-w-0">
                    <div
                      className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0 text-white shadow-xs"
                      style={{ backgroundColor: catConfig?.color || '#64748b' }}
                    >
                      {getCategoryIcon(tx.category, 'w-5 h-5')}
                    </div>

                    <div className="min-w-0">
                      <div className="font-semibold text-sm text-slate-900 truncate">
                        {tx.description}
                      </div>
                      <div className="text-[11px] text-slate-500 flex items-center gap-1.5 mt-0.5">
                        <span className="truncate">{tx.category}</span>
                        {enablePaymentMethods && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span className="capitalize">{tx.paymentMethod.replace('_', ' ')}</span>
                          </>
                        )}
                        {tx.time && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span className="font-mono">{tx.time}</span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Amount & Actions */}
                  <div className="flex items-center gap-2 shrink-0">
                    <span
                      className={`font-mono font-bold text-sm tabular-nums ${
                        isIncome ? 'text-emerald-700' : 'text-slate-900'
                      }`}
                    >
                      {isIncome ? '+' : '-'}
                      {formatCurrency(tx.amount, currency)}
                    </span>

                    <button
                      onClick={() => openAddModal(tx.type, tx)}
                      className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 min-h-[36px] min-w-[36px] flex items-center justify-center cursor-pointer"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>

                    <button
                      onClick={() => deleteTransaction(tx.id)}
                      className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 min-h-[36px] min-w-[36px] flex items-center justify-center cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Floating Fast Add Shortcuts Bar */}
      <div className="grid grid-cols-2 gap-2 pt-1">
        <button
          onClick={() => openAddModal('expense')}
          className="py-3 px-4 bg-rose-50 hover:bg-rose-100 text-rose-800 border border-rose-200/80 rounded-2xl text-xs font-bold flex items-center justify-center gap-2 active:scale-98 transition-transform cursor-pointer"
        >
          <ArrowUpRight className="w-4 h-4 text-rose-600" />
          <span>- Log Expense</span>
        </button>

        <button
          onClick={() => openAddModal('income')}
          className="py-3 px-4 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200/80 rounded-2xl text-xs font-bold flex items-center justify-center gap-2 active:scale-98 transition-transform cursor-pointer"
        >
          <ArrowDownRight className="w-4 h-4 text-emerald-600" />
          <span>+ Log Income</span>
        </button>
      </div>
    </div>
  );
};
