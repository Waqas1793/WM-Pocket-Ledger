import React, { useRef, useState } from 'react';
import { useFinance } from '../../context/FinanceContext';
import { downloadFile, formatCurrency } from '../../utils/formatters';
import {
  Globe,
  Tag,
  Database,
  Trash2,
  Upload,
  Download,
  Check,
  ShieldCheck,
  User,
  CreditCard,
  Plus,
  X,
  Building2,
  Lock,
  Key,
} from 'lucide-react';
import { PasswordConfirmModal } from '../PasswordConfirmModal';

export const MobileSettingsView: React.FC = () => {
  const {
    currency,
    setCurrency,
    userName,
    setUserName,
    companyName,
    setCompanyName,
    securityPin,
    setSecurityPin,
    enablePaymentMethods,
    setEnablePaymentMethods,
    paymentMethods,
    addPaymentMethod,
    deletePaymentMethod,
    categories,
    addCategory,
    deleteCategory,
    clearAll,
    importData,
    transactions,
  } = useFinance();

  const fileInputRef = useRef<HTMLInputElement>(null);
  const [importStatus, setImportStatus] = useState<string | null>(null);

  // Payment Method State
  const [newMethodInput, setNewMethodInput] = useState<string>('');
  const [methodSuccessMsg, setMethodSuccessMsg] = useState<string | null>(null);

  const handleAddCustomMethod = (e?: React.FormEvent, methodName?: string) => {
    if (e) e.preventDefault();
    const nameToAdd = (methodName || newMethodInput).trim();
    if (!nameToAdd) return;
    addPaymentMethod(nameToAdd);
    setNewMethodInput('');
    setMethodSuccessMsg(`Payment method "${nameToAdd}" added!`);
    setTimeout(() => setMethodSuccessMsg(null), 2500);
  };

  // New Category State
  const [newCatName, setNewCatName] = useState<string>('');
  const [newCatType, setNewCatType] = useState<'expense' | 'income'>('expense');
  const [newCatColor, setNewCatColor] = useState<string>('#6366f1');
  const [catSuccessMsg, setCatSuccessMsg] = useState<string | null>(null);

  const handleCreateCategory = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = newCatName.trim();
    if (!clean) return;

    addCategory({
      name: clean,
      type: newCatType,
      color: newCatColor,
    });

    setNewCatName('');
    setCatSuccessMsg(`Category "${clean}" added!`);
    setTimeout(() => setCatSuccessMsg(null), 2500);
  };

  // User Name State
  const [userNameInput, setUserNameInput] = useState<string>(userName || 'Alex Morgan');
  const [isNameSaved, setIsNameSaved] = useState<boolean>(false);

  const handleSaveName = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userNameInput.trim()) return;
    setUserName(userNameInput.trim());
    setIsNameSaved(true);
    setTimeout(() => setIsNameSaved(false), 2000);
  };

  // Company / Developer Name State (Default: MW Solutions)
  const [companyNameInput, setCompanyNameInput] = useState<string>(companyName || 'MW Solutions');
  const [isCompanySaved, setIsCompanySaved] = useState<boolean>(false);

  const handleSaveCompany = (e: React.FormEvent) => {
    e.preventDefault();
    if (!companyNameInput.trim()) return;
    setCompanyName(companyNameInput.trim());
    setIsCompanySaved(true);
    setTimeout(() => setIsCompanySaved(false), 2000);
  };

  const [customCurrencyInput, setCustomCurrencyInput] = useState<string>(
    currency.symbol.trim() || currency.code || '$'
  );
  const [isSaved, setIsSaved] = useState<boolean>(false);

  const handleSaveCustomCurrency = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = customCurrencyInput.trim();
    if (!clean) return;

    // If it's a word like 'USD', 'EUR', 'AED', 'Rs' with multiple letters, add trailing space for clean spacing
    const hasMultipleLetters = /^[A-Za-z]{2,}$/.test(clean);
    const formattedSymbol = hasMultipleLetters ? `${clean} ` : clean;

    setCurrency({
      code: clean.toUpperCase().slice(0, 5) || clean,
      symbol: formattedSymbol,
      name: clean,
      position: 'prefix',
    });

    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2000);
  };

  const handleExportBackup = () => {
    const backup = {
      version: '2.0',
      exportedAt: new Date().toISOString(),
      currency,
      enablePaymentMethods,
      paymentMethods,
      categories,
      transactions,
    };
    downloadFile(
      JSON.stringify(backup, null, 2),
      `ledgerpulse_backup_${new Date().toISOString().split('T')[0]}.json`,
      'application/json'
    );
  };

  // Passcode & Security Protection State
  const [isClearModalOpen, setIsClearModalOpen] = useState<boolean>(false);
  const [isRestoreModalOpen, setIsRestoreModalOpen] = useState<boolean>(false);
  const [pendingRestoreData, setPendingRestoreData] = useState<any>(null);
  const [isChangePinOpen, setIsChangePinOpen] = useState<boolean>(false);
  const [newPinInput, setNewPinInput] = useState<string>('');
  const [pinChangeMsg, setPinChangeMsg] = useState<string | null>(null);

  const handleSaveNewPin = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = newPinInput.trim();
    if (!clean || clean.length < 3) {
      setPinChangeMsg('Passcode must be at least 3 characters');
      return;
    }
    setSecurityPin(clean);
    setNewPinInput('');
    setIsChangePinOpen(false);
    setPinChangeMsg('Passcode updated successfully!');
    setTimeout(() => setPinChangeMsg(null), 3000);
  };

  const handleClear = () => {
    setIsClearModalOpen(true);
  };

  const executeClearAll = () => {
    clearAll();
    setImportStatus('All ledger transactions deleted.');
    setTimeout(() => setImportStatus(null), 4000);
  };

  const handleFileImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (parsed && (parsed.transactions || parsed.categories)) {
          if (transactions.length > 0) {
            setPendingRestoreData(parsed);
            setIsRestoreModalOpen(true);
          } else {
            importData(parsed);
            setImportStatus('Backup restored successfully!');
          }
        } else {
          setImportStatus('Invalid file format.');
        }
      } catch {
        setImportStatus('Failed to read file.');
      }
    };
    reader.readAsText(file);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const executeRestoreBackup = () => {
    if (pendingRestoreData) {
      importData(pendingRestoreData);
      setPendingRestoreData(null);
      setImportStatus('Backup restored successfully!');
      setTimeout(() => setImportStatus(null), 4000);
    }
  };

  return (
    <div className="space-y-4 pb-20">
      {/* User Name Card */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200/80 shadow-xs space-y-3">
        <div className="flex items-center gap-2">
          <User className="w-4 h-4 text-slate-700" />
          <h3 className="font-bold text-sm text-slate-900">User / Account Name</h3>
        </div>

        <p className="text-xs text-slate-500">
          This name will appear on your home greeting and on all generated PDF financial reports.
        </p>

        <form onSubmit={handleSaveName} className="flex items-center gap-2 pt-1">
          <input
            type="text"
            placeholder="e.g. Alex Morgan, Acme Studio"
            value={userNameInput}
            onChange={(e) => {
              setUserNameInput(e.target.value);
              setIsNameSaved(false);
            }}
            className="flex-1 px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-semibold text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-slate-900 transition-all placeholder:text-slate-300"
          />
          <button
            type="submit"
            disabled={!userNameInput.trim()}
            className="h-11 px-5 bg-slate-900 hover:bg-slate-800 disabled:opacity-40 text-white font-bold text-xs rounded-2xl transition-all flex items-center justify-center gap-1.5 shadow-xs cursor-pointer shrink-0"
          >
            {isNameSaved ? <Check className="w-4 h-4 text-emerald-400" /> : null}
            <span>{isNameSaved ? 'Saved' : 'Save'}</span>
          </button>
        </form>
      </div>

      {/* Company Name / Made by MW Solutions Card */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200/80 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Building2 className="w-4 h-4 text-slate-700" />
            <h3 className="font-bold text-sm text-slate-900">Company / Organization</h3>
          </div>
          <span className="text-[10px] font-bold uppercase tracking-wider bg-amber-500/10 text-amber-600 border border-amber-500/20 px-2 py-0.5 rounded-full">
            MW Solutions
          </span>
        </div>

        {/* Brand Banner showing Logo & MW Solutions */}
        <div className="p-3 bg-gradient-to-r from-slate-900 to-slate-800 text-white rounded-2xl flex items-center justify-between shadow-xs">
          <div className="flex items-center gap-3">
            <img
              src="/logo.png"
              alt="Pocket Ledger"
              className="w-10 h-10 rounded-xl object-cover border border-slate-700 shadow-xs"
            />
            <div>
              <p className="font-bold text-sm text-white">Pocket Ledger</p>
              <p className="text-xs text-amber-400 font-medium">Made by MW Solutions</p>
            </div>
          </div>
          <span className="text-[10px] font-mono bg-slate-800 text-slate-300 px-2 py-1 rounded-lg border border-slate-700">
            v1.2.0
          </span>
        </div>

        <p className="text-xs text-slate-500">
          Company name printed on your generated PDF reports, balance summaries, and statements:
        </p>

        <form onSubmit={handleSaveCompany} className="flex items-center gap-2 pt-1">
          <input
            type="text"
            placeholder="e.g. MW Solutions"
            value={companyNameInput}
            onChange={(e) => {
              setCompanyNameInput(e.target.value);
              setIsCompanySaved(false);
            }}
            className="flex-1 px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-semibold text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-slate-900 transition-all placeholder:text-slate-300"
          />
          <button
            type="submit"
            disabled={!companyNameInput.trim()}
            className="h-11 px-5 bg-slate-900 hover:bg-slate-800 disabled:opacity-40 text-white font-bold text-xs rounded-2xl transition-all flex items-center justify-center gap-1.5 shadow-xs cursor-pointer shrink-0"
          >
            {isCompanySaved ? <Check className="w-4 h-4 text-emerald-400" /> : null}
            <span>{isCompanySaved ? 'Saved' : 'Save'}</span>
          </button>
        </form>
      </div>

      {/* Custom Currency Textbox */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200/80 shadow-xs space-y-3">
        <div className="flex items-center gap-2">
          <Globe className="w-4 h-4 text-slate-700" />
          <h3 className="font-bold text-sm text-slate-900">Currency</h3>
        </div>

        <p className="text-xs text-slate-500">
          Enter your preferred currency symbol or code (e.g. $, €, ₹, £, USD, Rs, AED, kr):
        </p>

        <form onSubmit={handleSaveCustomCurrency} className="space-y-3 pt-1">
          <div className="flex items-center gap-2">
            <div className="relative flex-1">
              <input
                type="text"
                placeholder="e.g. $, €, ₹, Rs, USD"
                value={customCurrencyInput}
                onChange={(e) => {
                  setCustomCurrencyInput(e.target.value);
                  setIsSaved(false);
                }}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-base font-bold font-mono text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-slate-900 transition-all placeholder:text-slate-300"
              />
            </div>

            <button
              type="submit"
              disabled={!customCurrencyInput.trim()}
              className="h-11 px-5 bg-slate-900 hover:bg-slate-800 disabled:opacity-40 text-white font-bold text-xs rounded-2xl transition-all flex items-center justify-center gap-1.5 shadow-xs cursor-pointer shrink-0"
            >
              {isSaved ? <Check className="w-4 h-4 text-emerald-400" /> : null}
              <span>{isSaved ? 'Saved' : 'Save'}</span>
            </button>
          </div>

          {/* Live Preview */}
          <div className="flex items-center justify-between p-3 bg-slate-50 border border-slate-100 rounded-2xl text-xs">
            <span className="text-slate-500">Live Format Preview:</span>
            <span className="font-mono font-bold text-slate-900 text-sm">
              {formatCurrency(1250.00, {
                code: customCurrencyInput.trim() || '$',
                symbol: /^[A-Za-z]{2,}$/.test(customCurrencyInput.trim())
                  ? `${customCurrencyInput.trim()} `
                  : customCurrencyInput.trim() || '$',
                name: customCurrencyInput.trim() || 'Custom',
                position: 'prefix',
              })}
            </span>
          </div>
        </form>
      </div>

      {/* Payment Method Settings Card */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200/80 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CreditCard className="w-4 h-4 text-slate-700" />
            <h3 className="font-bold text-sm text-slate-900">Payment Methods</h3>
          </div>

          {/* Toggle Switch */}
          <button
            type="button"
            role="switch"
            aria-checked={enablePaymentMethods}
            onClick={() => setEnablePaymentMethods(!enablePaymentMethods)}
            className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors cursor-pointer focus:outline-none focus:ring-2 focus:ring-slate-900 focus:ring-offset-2 ${
              enablePaymentMethods ? 'bg-slate-900' : 'bg-slate-300'
            }`}
          >
            <span
              className={`inline-block h-4 w-4 transform rounded-full bg-white shadow transition-transform ${
                enablePaymentMethods ? 'translate-x-6' : 'translate-x-1'
              }`}
            />
          </button>
        </div>

        <p className="text-xs text-slate-500">
          {enablePaymentMethods
            ? 'Payment method tracking is enabled. Transactions default to Cash unless another method is chosen.'
            : 'Payment method tracking is turned off. All transactions will automatically be logged as Cash.'}
        </p>

        {enablePaymentMethods && (
          <div className="space-y-3 pt-1 border-t border-slate-100 animate-in fade-in duration-150">
            {methodSuccessMsg && (
              <div className="p-2.5 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs flex items-center gap-1.5">
                <Check className="w-4 h-4" />
                <span>{methodSuccessMsg}</span>
              </div>
            )}

            {/* Active Methods Chips */}
            <div>
              <label className="text-[11px] uppercase font-bold text-slate-400 tracking-wider block mb-2">
                Active Methods ({paymentMethods.length})
              </label>

              <div className="flex flex-wrap gap-1.5">
                {paymentMethods.map((pm) => {
                  const isCash = pm.toLowerCase() === 'cash';
                  return (
                    <div
                      key={pm}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 shadow-2xs"
                    >
                      <span>{pm}</span>
                      {isCash && (
                        <span className="text-[9px] uppercase px-1 py-0.2 bg-emerald-100 text-emerald-800 rounded font-bold">
                          Default
                        </span>
                      )}
                      {paymentMethods.length > 1 && (
                        <button
                          type="button"
                          onClick={() => deletePaymentMethod(pm)}
                          className="text-slate-400 hover:text-rose-600 rounded p-0.5 ml-0.5 cursor-pointer"
                          title={`Remove ${pm}`}
                        >
                          <X className="w-3 h-3" />
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Add Custom Method Form */}
            <form onSubmit={handleAddCustomMethod} className="space-y-2 pt-1">
              <label className="text-[11px] uppercase font-bold text-slate-400 tracking-wider block">
                Add Custom Option
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  placeholder="e.g. Bank Transfer, Card, UPI, PayPal"
                  value={newMethodInput}
                  onChange={(e) => setNewMethodInput(e.target.value)}
                  className="flex-1 px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-2xl text-xs sm:text-sm font-semibold text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-slate-900 placeholder:text-slate-300"
                />
                <button
                  type="submit"
                  disabled={!newMethodInput.trim()}
                  className="h-10 px-4 bg-slate-900 hover:bg-slate-800 disabled:opacity-40 text-white font-bold text-xs rounded-2xl transition-all flex items-center justify-center gap-1 cursor-pointer shrink-0 shadow-xs"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add</span>
                </button>
              </div>

              {/* Quick Preset Suggestions */}
              <div className="pt-1">
                <span className="text-[10px] text-slate-400 font-medium block mb-1">
                  Quick tap to add:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {['Bank Transfer', 'Credit Card', 'Debit Card', 'UPI', 'Mobile Wallet', 'Cheque'].map(
                    (suggested) => {
                      const alreadyAdded = paymentMethods.some(
                        (p) => p.toLowerCase() === suggested.toLowerCase()
                      );
                      if (alreadyAdded) return null;
                      return (
                        <button
                          key={suggested}
                          type="button"
                          onClick={() => handleAddCustomMethod(undefined, suggested)}
                          className="px-2.5 py-1 text-[11px] bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium rounded-lg transition-colors cursor-pointer"
                        >
                          + {suggested}
                        </button>
                      );
                    }
                  )}
                </div>
              </div>
            </form>
          </div>
        )}
      </div>

      {/* Category Manager */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200/80 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Tag className="w-4 h-4 text-slate-700" />
            <h3 className="font-bold text-sm text-slate-900">Custom Categories</h3>
          </div>
          <span className="text-xs text-slate-500 font-mono">
            {categories.length} {categories.length === 1 ? 'category' : 'categories'}
          </span>
        </div>

        <p className="text-xs text-slate-500">
          Create categories tailored to your personal or business needs:
        </p>

        {catSuccessMsg && (
          <div className="p-2.5 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs flex items-center gap-1.5">
            <Check className="w-4 h-4" />
            <span>{catSuccessMsg}</span>
          </div>
        )}

        {/* Add Category Form */}
        <form onSubmit={handleCreateCategory} className="p-3 bg-slate-50 rounded-2xl border border-slate-200/70 space-y-3">
          <div className="flex items-center gap-2">
            <input
              type="text"
              placeholder="e.g. Food, Transport, Rent, Salary"
              value={newCatName}
              onChange={(e) => setNewCatName(e.target.value)}
              className="flex-1 px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900"
            />
            <button
              type="submit"
              disabled={!newCatName.trim()}
              className="h-9 px-4 bg-slate-900 hover:bg-slate-800 disabled:opacity-40 text-white font-bold text-xs rounded-xl transition-all cursor-pointer shrink-0"
            >
              + Add
            </button>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-2 pt-1 text-xs">
            {/* Type selector */}
            <div className="flex bg-slate-200/70 p-0.5 rounded-lg">
              <button
                type="button"
                onClick={() => setNewCatType('expense')}
                className={`px-3 py-1 font-semibold rounded-md transition-colors cursor-pointer ${
                  newCatType === 'expense'
                    ? 'bg-white text-rose-700 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Expense
              </button>
              <button
                type="button"
                onClick={() => setNewCatType('income')}
                className={`px-3 py-1 font-semibold rounded-md transition-colors cursor-pointer ${
                  newCatType === 'income'
                    ? 'bg-white text-emerald-700 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Income
              </button>
            </div>

            {/* Quick Color Dots */}
            <div className="flex items-center gap-1.5">
              {['#10b981', '#f59e0b', '#6366f1', '#ec4899', '#0ea5e9', '#8b5cf6', '#f43f5e', '#64748b'].map((color) => (
                <button
                  key={color}
                  type="button"
                  onClick={() => setNewCatColor(color)}
                  className={`w-5 h-5 rounded-full transition-transform cursor-pointer ${
                    newCatColor === color ? 'scale-125 ring-2 ring-slate-900 ring-offset-1' : 'opacity-80 hover:opacity-100'
                  }`}
                  style={{ backgroundColor: color }}
                />
              ))}
              <input
                type="color"
                value={newCatColor}
                onChange={(e) => setNewCatColor(e.target.value)}
                className="w-5 h-5 rounded cursor-pointer border-0 p-0 ml-1"
                title="Custom color"
              />
            </div>
          </div>
        </form>

        {/* Existing Categories List */}
        {categories.length === 0 ? (
          <div className="p-4 bg-slate-50 border border-dashed border-slate-200 rounded-2xl text-center text-xs text-slate-500">
            No categories yet. Enter a name above to create your first category.
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-56 overflow-y-auto p-0.5">
            {categories.map((c) => (
              <div
                key={c.id}
                className="p-2.5 bg-slate-50 border border-slate-200/70 rounded-xl text-xs flex items-center justify-between gap-2"
              >
                <div className="flex items-center gap-2 truncate">
                  <span
                    className="w-3 h-3 rounded-full shrink-0"
                    style={{ backgroundColor: c.color }}
                  />
                  <span className="font-semibold text-slate-900 truncate">{c.name}</span>
                  <span
                    className={`text-[9px] font-bold px-1.5 py-0.2 rounded uppercase ${
                      c.type === 'income' ? 'text-emerald-700 bg-emerald-50' : 'text-slate-600 bg-slate-200/60'
                    }`}
                  >
                    {c.type}
                  </span>
                </div>

                <button
                  type="button"
                  onClick={() => deleteCategory(c.id)}
                  title={`Delete ${c.name}`}
                  className="p-1 text-slate-400 hover:text-rose-600 rounded hover:bg-rose-50 transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Data Management & Backup */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200/80 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Database className="w-4 h-4 text-slate-700" />
            <h3 className="font-bold text-sm text-slate-900">Data & Privacy</h3>
          </div>
          <span className="inline-flex items-center gap-1 text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200 px-2 py-0.5 rounded-full">
            <Lock className="w-2.5 h-2.5" />
            <span>Passcode Protected</span>
          </span>
        </div>

        <p className="text-xs text-slate-500">
          Your data is stored 100% locally in your browser. All destructive deletion operations are locked behind your security passcode to prevent accidents.
        </p>

        {/* Passcode Security & Protection Box */}
        <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl space-y-2.5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-7 h-7 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-600 flex items-center justify-center shrink-0">
                <Lock className="w-3.5 h-3.5" />
              </div>
              <div>
                <p className="text-xs font-bold text-slate-900">Security Passcode</p>
                <p className="text-[10px] text-slate-500">Default PIN: 1234 • Required for clearing data</p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setIsChangePinOpen(!isChangePinOpen)}
              className="text-xs font-semibold text-amber-600 hover:text-amber-700 bg-white border border-slate-200 px-2.5 py-1 rounded-lg transition-colors cursor-pointer shadow-2xs"
            >
              {isChangePinOpen ? 'Cancel' : 'Change PIN'}
            </button>
          </div>

          {pinChangeMsg && (
            <div className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2.5 py-1.5 rounded-lg flex items-center gap-1.5">
              <Check className="w-3.5 h-3.5 text-emerald-600" />
              <span>{pinChangeMsg}</span>
            </div>
          )}

          {isChangePinOpen && (
            <form onSubmit={handleSaveNewPin} className="pt-1 flex items-center gap-2">
              <input
                type="password"
                placeholder="Enter new PIN / password..."
                value={newPinInput}
                onChange={(e) => setNewPinInput(e.target.value)}
                className="flex-1 px-3 py-1.5 bg-white border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900 placeholder:text-slate-400"
              />
              <button
                type="submit"
                disabled={!newPinInput.trim()}
                className="px-3.5 py-1.5 bg-slate-900 hover:bg-slate-800 disabled:opacity-40 text-white font-bold text-xs rounded-xl shadow-xs transition cursor-pointer shrink-0"
              >
                Save PIN
              </button>
            </form>
          )}
        </div>

        {importStatus && (
          <div className="p-2.5 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-xl text-xs flex items-center gap-2">
            <Check className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{importStatus}</span>
          </div>
        )}

        <div className="space-y-2 pt-1">
          <button
            onClick={handleExportBackup}
            className="w-full py-2.5 px-3 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>Download Backup (JSON)</span>
          </button>

          <label className="w-full py-2.5 px-3 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer block text-center">
            <Upload className="w-4 h-4 inline mr-1" />
            <span>Restore Backup</span>
            <input
              ref={fileInputRef}
              type="file"
              accept=".json"
              onChange={handleFileImport}
              className="hidden"
            />
          </label>

          <button
            onClick={handleClear}
            className="w-full py-2.5 px-3 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200/60 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer"
          >
            <Lock className="w-3.5 h-3.5 text-rose-500" />
            <span>Clear All Transactions (Protected)</span>
          </button>
        </div>
      </div>

      {/* Password Protection Confirmation Modals */}
      <PasswordConfirmModal
        isOpen={isClearModalOpen}
        onClose={() => setIsClearModalOpen(false)}
        onConfirm={executeClearAll}
        currentPin={securityPin}
        title="Clear All Transactions"
        description="This will permanently delete all recorded income and expense transactions. To prevent accidental data loss, please enter your security passcode."
        confirmButtonText="Delete Everything"
      />

      <PasswordConfirmModal
        isOpen={isRestoreModalOpen}
        onClose={() => {
          setIsRestoreModalOpen(false);
          setPendingRestoreData(null);
        }}
        onConfirm={executeRestoreBackup}
        currentPin={securityPin}
        title="Restore Backup"
        description="Restoring this backup file will replace your current ledger records. Please enter your security passcode to confirm."
        confirmButtonText="Restore & Replace"
      />

      {/* App Branding Footer */}
      <div className="pt-3 pb-4 text-center space-y-1.5">
        <div className="flex items-center justify-center gap-2">
          <img
            src="/logo.png"
            alt="Pocket Ledger"
            className="w-5 h-5 rounded-md object-cover border border-slate-300"
          />
          <span className="font-bold text-xs text-slate-800">Pocket Ledger</span>
        </div>
        <p className="text-[11px] font-medium text-slate-500">
          Made by <span className="font-bold text-slate-800">MW Solutions</span>
        </p>
        <p className="text-[10px] text-slate-400">
          Personal & Business Financial Ledger • Mobile Edition
        </p>
      </div>
    </div>
  );
};
