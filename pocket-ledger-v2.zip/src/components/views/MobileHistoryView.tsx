import React, { useMemo, useState } from 'react';
import { useFinance } from '../../context/FinanceContext';
import { Transaction } from '../../types/finance';
import { formatCurrency, formatDateLabel, exportToCsv, downloadFile } from '../../utils/formatters';
import { getCategoryIcon } from '../../utils/categoryIcons';
import { Search, Download, Trash2, Edit2, X, Filter } from 'lucide-react';

export const MobileHistoryView: React.FC = () => {
  const {
    transactions,
    currency,
    categories,
    enablePaymentMethods,
    openAddModal,
    deleteTransaction,
  } = useFinance();

  const [search, setSearch] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'expense' | 'income'>('all');

  // Filtered transactions
  const filtered = useMemo(() => {
    let result = transactions;

    if (filterType !== 'all') {
      result = result.filter((t) => t.type === filterType);
    }

    if (search.trim()) {
      const q = search.toLowerCase().trim();
      result = result.filter(
        (t) =>
          t.description.toLowerCase().includes(q) ||
          t.category.toLowerCase().includes(q) ||
          (t.notes && t.notes.toLowerCase().includes(q))
      );
    }

    return [...result].sort((a, b) => b.date.localeCompare(a.date));
  }, [transactions, filterType, search]);

  // Group by date
  const grouped = useMemo(() => {
    const map = new Map<string, Transaction[]>();
    filtered.forEach((t) => {
      const list = map.get(t.date) || [];
      list.push(t);
      map.set(t.date, list);
    });
    return Array.from(map.entries());
  }, [filtered]);

  const handleExportCsv = () => {
    const csv = exportToCsv(filtered, currency);
    downloadFile(csv, `transactions_${new Date().toISOString().split('T')[0]}.csv`, 'text/csv');
  };

  return (
    <div className="space-y-4 pb-20">
      {/* Search and Filters Header */}
      <div className="space-y-2">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search all transactions..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-8 py-2.5 bg-white border border-slate-200 rounded-2xl text-xs sm:text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900 shadow-xs"
          />
          {search && (
            <button
              onClick={() => setSearch('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-1"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Filter Segmented Control & Export */}
        <div className="flex items-center justify-between gap-2">
          <div className="flex bg-slate-200/70 p-1 rounded-xl text-xs flex-1 max-w-xs">
            <button
              onClick={() => setFilterType('all')}
              className={`flex-1 py-1.5 font-semibold rounded-lg transition-colors cursor-pointer ${
                filterType === 'all'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All
            </button>
            <button
              onClick={() => setFilterType('expense')}
              className={`flex-1 py-1.5 font-semibold rounded-lg transition-colors cursor-pointer ${
                filterType === 'expense'
                  ? 'bg-white text-rose-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Expense
            </button>
            <button
              onClick={() => setFilterType('income')}
              className={`flex-1 py-1.5 font-semibold rounded-lg transition-colors cursor-pointer ${
                filterType === 'income'
                  ? 'bg-white text-emerald-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Income
            </button>
          </div>

          <button
            onClick={handleExportCsv}
            className="flex items-center gap-1.5 px-3 py-2 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-xl text-xs font-semibold shadow-xs cursor-pointer"
            title="Download CSV"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Export</span>
          </button>
        </div>
      </div>

      {/* Grouped Transactions List */}
      {grouped.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center text-xs text-slate-500 shadow-xs">
          No transactions found matching your criteria.
        </div>
      ) : (
        <div className="space-y-4">
          {grouped.map(([dateStr, items]) => {
            const daySum = items.reduce(
              (acc, t) => acc + (t.type === 'income' ? t.amount : -t.amount),
              0
            );

            return (
              <div key={dateStr} className="space-y-1.5">
                {/* Date Header */}
                <div className="flex items-center justify-between px-2 text-xs">
                  <span className="font-bold text-slate-800">{formatDateLabel(dateStr)}</span>
                  <span
                    className={`font-mono text-[11px] font-semibold tabular-nums ${
                      daySum >= 0 ? 'text-emerald-700' : 'text-slate-500'
                    }`}
                  >
                    {daySum >= 0 ? '+' : ''}
                    {formatCurrency(daySum, currency)}
                  </span>
                </div>

                {/* Day Items Card */}
                <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden divide-y divide-slate-100">
                  {items.map((tx) => {
                    const catConfig = categories.find((c) => c.name === tx.category);
                    const isIncome = tx.type === 'income';

                    return (
                      <div
                        key={tx.id}
                        className="p-3 flex items-center justify-between gap-3 hover:bg-slate-50 transition-colors"
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <div
                            className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0 text-white shadow-xs"
                            style={{ backgroundColor: catConfig?.color || '#64748b' }}
                          >
                            {getCategoryIcon(tx.category, 'w-4 h-4')}
                          </div>

                          <div className="min-w-0">
                            <div className="font-semibold text-xs sm:text-sm text-slate-900 truncate">
                              {tx.description}
                            </div>
                            <div className="text-[11px] text-slate-500 flex items-center gap-1.5">
                              <span className="truncate">{tx.category}</span>
                              {enablePaymentMethods && (
                                <>
                                  <span aria-hidden="true">·</span>
                                  <span className="capitalize">{tx.paymentMethod.replace('_', ' ')}</span>
                                </>
                              )}
                              {tx.time && (
                                <>
                                  <span aria-hidden="true">·</span>
                                  <span className="font-mono">{tx.time}</span>
                                </>
                              )}
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          <span
                            className={`font-mono font-bold text-xs sm:text-sm tabular-nums ${
                              isIncome ? 'text-emerald-700' : 'text-slate-900'
                            }`}
                          >
                            {isIncome ? '+' : '-'}
                            {formatCurrency(tx.amount, currency)}
                          </span>

                          <button
                            onClick={() => openAddModal(tx.type, tx)}
                            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 min-h-[36px] min-w-[36px] flex items-center justify-center cursor-pointer"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>

                          <button
                            onClick={() => deleteTransaction(tx.id)}
                            className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 min-h-[36px] min-w-[36px] flex items-center justify-center cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
