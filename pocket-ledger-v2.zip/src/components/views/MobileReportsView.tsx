import React, { useMemo, useState } from 'react';
import { useFinance } from '../../context/FinanceContext';
import { DateRangePreset, Transaction } from '../../types/finance';
import {
  calculateTotals,
  downloadFile,
  exportToCsv,
  formatCurrency,
  formatDateLabel,
  getCategoryBreakdown,
  getDateRangeBounds,
  getTodayDateString,
} from '../../utils/formatters';
import { getCategoryIcon } from '../../utils/categoryIcons';
import { generatePdfReport } from '../../utils/pdfExport';
import {
  Printer,
  Download,
  Calendar,
  ArrowDownRight,
  ArrowUpRight,
  FileText,
  Filter,
  Layers,
  ChevronDown,
} from 'lucide-react';

export const MobileReportsView: React.FC = () => {
  const { transactions, categories, currency, userName } = useFinance();
  const [dateRange, setDateRange] = useState<DateRangePreset>('this_month');
  const [hoveredCategory, setHoveredCategory] = useState<string | null>(null);

  // Custom Date Range State
  const [customStart, setCustomStart] = useState<string>(() => {
    const d = new Date();
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    return `${y}-${m}-01`;
  });
  const [customEnd, setCustomEnd] = useState<string>(() => getTodayDateString());

  // Category & Grouping View State
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState<string>('all');
  const [breakdownMode, setBreakdownMode] = useState<'by_date' | 'by_category'>('by_date');

  const [startDateStr, endDateStr] = useMemo(() => {
    return getDateRangeBounds(dateRange, customStart, customEnd);
  }, [dateRange, customStart, customEnd]);

  const periodTransactions = useMemo(() => {
    return transactions.filter((t) => t.date >= startDateStr && t.date <= endDateStr);
  }, [transactions, startDateStr, endDateStr]);

  const { income, expense, net, savingsRate } = useMemo(() => {
    return calculateTotals(periodTransactions);
  }, [periodTransactions]);

  const expenseBreakdown = useMemo(() => {
    return getCategoryBreakdown(periodTransactions, 'expense', categories);
  }, [periodTransactions, categories]);

  const incomeBreakdown = useMemo(() => {
    return getCategoryBreakdown(periodTransactions, 'income', categories);
  }, [periodTransactions, categories]);

  // Category by Date: Grouped by Date
  const dateCategoryBreakdown = useMemo(() => {
    const map = new Map<string, Map<string, { total: number; transactions: Transaction[] }>>();

    const filtered =
      selectedCategoryFilter === 'all'
        ? periodTransactions
        : periodTransactions.filter((t) => t.category === selectedCategoryFilter);

    filtered.forEach((t) => {
      if (!map.has(t.date)) {
        map.set(t.date, new Map());
      }
      const dayMap = map.get(t.date)!;
      const catEntry = dayMap.get(t.category) || { total: 0, transactions: [] };
      catEntry.total += t.type === 'income' ? t.amount : -t.amount;
      catEntry.transactions.push(t);
      dayMap.set(t.category, catEntry);
    });

    return Array.from(map.entries())
      .sort((a, b) => b[0].localeCompare(a[0]))
      .map(([date, categoriesMap]) => ({
        date,
        dayTotal: Array.from(categoriesMap.values()).reduce((sum, c) => sum + c.total, 0),
        categoriesList: Array.from(categoriesMap.entries()).map(([catName, data]) => ({
          category: catName,
          total: data.total,
          transactions: data.transactions,
        })),
      }));
  }, [periodTransactions, selectedCategoryFilter]);

  // Category by Date: Grouped by Category with dates list
  const categoryDateBreakdown = useMemo(() => {
    const map = new Map<string, Map<string, { income: number; expense: number; count: number }>>();

    const filtered =
      selectedCategoryFilter === 'all'
        ? periodTransactions
        : periodTransactions.filter((t) => t.category === selectedCategoryFilter);

    filtered.forEach((t) => {
      if (!map.has(t.category)) {
        map.set(t.category, new Map());
      }
      const catMap = map.get(t.category)!;
      const cur = catMap.get(t.date) || { income: 0, expense: 0, count: 0 };
      if (t.type === 'income') cur.income += t.amount;
      else cur.expense += t.amount;
      cur.count += 1;
      catMap.set(t.date, cur);
    });

    return Array.from(map.entries())
      .map(([catName, datesMap]) => {
        const datesList = Array.from(datesMap.entries())
          .sort((a, b) => b[0].localeCompare(a[0]))
          .map(([date, val]) => ({ date, ...val }));

        const totalSpent = datesList.reduce((acc, d) => acc + d.expense, 0);
        const totalIncome = datesList.reduce((acc, d) => acc + d.income, 0);

        return {
          category: catName,
          totalSpent,
          totalIncome,
          dates: datesList,
        };
      })
      .sort((a, b) => (b.totalSpent + b.totalIncome) - (a.totalSpent + a.totalIncome));
  }, [periodTransactions, selectedCategoryFilter]);

  const handleDownloadPdf = () => {
    generatePdfReport({
      userName: userName || 'Account Holder',
      startDateStr,
      endDateStr,
      currency,
      income,
      expense,
      net,
      savingsRate,
      transactions: periodTransactions,
      expenseBreakdown,
    });
  };

  const handlePrint = () => {
    window.print();
  };

  const handleExportCsv = () => {
    const csv = exportToCsv(periodTransactions, currency);
    downloadFile(csv, `report_${startDateStr}_to_${endDateStr}.csv`, 'text/csv');
  };

  return (
    <div className="space-y-4 pb-20">
      {/* Period Selector Tabs (Including Custom Date) */}
      <div className="no-print space-y-2">
        <div className="flex items-center justify-between gap-1 bg-slate-200/70 p-1 rounded-2xl text-xs overflow-x-auto">
          <button
            onClick={() => setDateRange('this_month')}
            className={`flex-1 py-1.5 px-2 font-semibold rounded-xl transition-all whitespace-nowrap cursor-pointer ${
              dateRange === 'this_month' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
            }`}
          >
            This Month
          </button>
          <button
            onClick={() => setDateRange('last_month')}
            className={`flex-1 py-1.5 px-2 font-semibold rounded-xl transition-all whitespace-nowrap cursor-pointer ${
              dateRange === 'last_month' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
            }`}
          >
            Last Month
          </button>
          <button
            onClick={() => setDateRange('last_30_days')}
            className={`flex-1 py-1.5 px-2 font-semibold rounded-xl transition-all whitespace-nowrap cursor-pointer ${
              dateRange === 'last_30_days' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
            }`}
          >
            30 Days
          </button>
          <button
            onClick={() => setDateRange('this_year')}
            className={`flex-1 py-1.5 px-2 font-semibold rounded-xl transition-all whitespace-nowrap cursor-pointer ${
              dateRange === 'this_year' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
            }`}
          >
            This Year
          </button>
          <button
            onClick={() => setDateRange('custom')}
            className={`flex-1 py-1.5 px-2 font-semibold rounded-xl transition-all whitespace-nowrap cursor-pointer ${
              dateRange === 'custom' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
            }`}
          >
            Custom
          </button>
        </div>

        {/* Custom Date Range Picker Card */}
        {dateRange === 'custom' && (
          <div className="bg-white rounded-2xl p-3.5 border border-slate-200 shadow-xs space-y-2.5 animate-in fade-in duration-150">
            <div className="flex items-center gap-1.5 text-xs font-bold text-slate-800">
              <Calendar className="w-3.5 h-3.5 text-slate-500" />
              <span>Select Custom Date Range</span>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <div>
                <label className="text-[10px] uppercase font-semibold text-slate-400 block mb-1">
                  Start Date
                </label>
                <input
                  type="date"
                  value={customStart}
                  onChange={(e) => setCustomStart(e.target.value)}
                  className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono font-medium text-slate-800 focus:bg-white focus:outline-none"
                />
              </div>

              <div>
                <label className="text-[10px] uppercase font-semibold text-slate-400 block mb-1">
                  End Date
                </label>
                <input
                  type="date"
                  value={customEnd}
                  onChange={(e) => setCustomEnd(e.target.value)}
                  className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono font-medium text-slate-800 focus:bg-white focus:outline-none"
                />
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Cash Flow Summary Card */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200/80 shadow-xs space-y-4">
        <div className="flex items-center justify-between text-xs text-slate-500">
          <span className="font-semibold uppercase tracking-wider">Summary</span>
          <span className="font-mono text-[11px]">{startDateStr} - {endDateStr}</span>
        </div>

        {/* Net Flow */}
        <div>
          <span className="text-xs text-slate-500 block">Net Savings</span>
          <div
            className={`text-2xl sm:text-3xl font-extrabold font-mono tracking-tight tabular-nums ${
              net >= 0 ? 'text-emerald-700' : 'text-rose-700'
            }`}
          >
            {net >= 0 ? '+' : ''}
            {formatCurrency(net, currency)}
          </div>
          <div className="text-xs text-slate-500 mt-1">
            Savings Rate: <strong className="font-mono text-slate-900">{savingsRate.toFixed(1)}%</strong>
          </div>
        </div>

        {/* Inflow vs Outflow Mini Bars */}
        <div className="grid grid-cols-2 gap-3 pt-3 border-t border-slate-100">
          <div className="p-3 bg-emerald-50 rounded-2xl">
            <span className="text-[11px] text-emerald-800 font-semibold block">Total Inflow</span>
            <span className="text-base font-bold font-mono text-emerald-800 tabular-nums">
              +{formatCurrency(income, currency)}
            </span>
          </div>

          <div className="p-3 bg-rose-50 rounded-2xl">
            <span className="text-[11px] text-rose-800 font-semibold block">Total Outflow</span>
            <span className="text-base font-bold font-mono text-rose-800 tabular-nums">
              -{formatCurrency(expense, currency)}
            </span>
          </div>
        </div>
      </div>

      {/* Category Spending Donut & Distribution */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200/80 shadow-xs space-y-4">
        <h3 className="font-bold text-sm text-slate-900">Category Distribution</h3>

        {expenseBreakdown.length === 0 ? (
          <div className="py-8 text-center text-xs text-slate-400">
            No expenses recorded for this time period.
          </div>
        ) : (
          <div>
            {/* Visual Donut */}
            <div className="relative w-48 h-48 mx-auto my-2">
              <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90 transform">
                {(() => {
                  let accumulatedAngle = 0;
                  return expenseBreakdown.map((slice) => {
                    const sliceAngle = (slice.percentage / 100) * 360;
                    const strokeDasharray = `${(slice.percentage / 100) * 251.2} 251.2`;
                    const strokeDashoffset = -((accumulatedAngle / 360) * 251.2);
                    accumulatedAngle += sliceAngle;
                    const isHovered = hoveredCategory === slice.category;

                    return (
                      <circle
                        key={slice.category}
                        cx="50"
                        cy="50"
                        r="40"
                        fill="transparent"
                        stroke={slice.color}
                        strokeWidth={isHovered ? '16' : '13'}
                        strokeDasharray={strokeDasharray}
                        strokeDashoffset={strokeDashoffset}
                        className="transition-all duration-200 cursor-pointer"
                        onMouseEnter={() => setHoveredCategory(slice.category)}
                        onMouseLeave={() => setHoveredCategory(null)}
                      />
                    );
                  });
                })()}
              </svg>

              <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none text-center">
                <span className="text-[10px] font-semibold text-slate-400 uppercase">
                  {hoveredCategory || 'Total Outlay'}
                </span>
                <span className="text-base font-bold font-mono text-slate-900 tabular-nums">
                  {hoveredCategory
                    ? formatCurrency(
                        expenseBreakdown.find((b) => b.category === hoveredCategory)?.total || 0,
                        currency
                      )
                    : formatCurrency(expense, currency)}
                </span>
                <span className="text-[10px] text-slate-500 font-mono">
                  {hoveredCategory
                    ? `${(expenseBreakdown.find((b) => b.category === hoveredCategory)?.percentage || 0).toFixed(1)}%`
                    : `${expenseBreakdown.length} Categories`}
                </span>
              </div>
            </div>

            {/* Itemized Categories List */}
            <div className="space-y-3 pt-3 border-t border-slate-100">
              {expenseBreakdown.map((item) => (
                <div
                  key={item.category}
                  className="space-y-1 cursor-pointer"
                  onMouseEnter={() => setHoveredCategory(item.category)}
                  onMouseLeave={() => setHoveredCategory(null)}
                  onClick={() =>
                    setSelectedCategoryFilter(
                      selectedCategoryFilter === item.category ? 'all' : item.category
                    )
                  }
                >
                  <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <div
                        className="w-6 h-6 rounded-lg flex items-center justify-center text-white shrink-0"
                        style={{ backgroundColor: item.color }}
                      >
                        {getCategoryIcon(item.category, 'w-3.5 h-3.5')}
                      </div>
                      <span className="font-semibold text-slate-800">{item.category}</span>
                    </div>

                    <div className="font-mono text-xs tabular-nums text-right">
                      <strong className="text-slate-900">{formatCurrency(item.total, currency)}</strong>
                      <span className="text-slate-400 ml-1.5">({item.percentage.toFixed(0)}%)</span>
                    </div>
                  </div>

                  {/* Progress Bar */}
                  <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all"
                      style={{ width: `${item.percentage}%`, backgroundColor: item.color }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* NEW SECTION: CATEGORY REPORTING BY DATE */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200/80 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
          <div>
            <h3 className="font-bold text-sm text-slate-900">Category Reporting by Date</h3>
            <p className="text-xs text-slate-500">Track which categories were active on each date</p>
          </div>

          {/* Grouping Mode Pill Toggle */}
          <div className="flex bg-slate-100 p-0.5 rounded-xl text-xs">
            <button
              onClick={() => setBreakdownMode('by_date')}
              className={`px-3 py-1 font-semibold rounded-lg transition-colors cursor-pointer ${
                breakdownMode === 'by_date' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
              }`}
            >
              By Date
            </button>
            <button
              onClick={() => setBreakdownMode('by_category')}
              className={`px-3 py-1 font-semibold rounded-lg transition-colors cursor-pointer ${
                breakdownMode === 'by_category' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
              }`}
            >
              By Category
            </button>
          </div>
        </div>

        {/* Filter by Category Selector */}
        <div className="flex items-center gap-2">
          <Filter className="w-3.5 h-3.5 text-slate-400 shrink-0" />
          <select
            value={selectedCategoryFilter}
            onChange={(e) => setSelectedCategoryFilter(e.target.value)}
            className="flex-1 px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:bg-white focus:outline-none"
          >
            <option value="all">All Categories ({periodTransactions.length} records)</option>
            {categories.map((c) => (
              <option key={c.id} value={c.name}>
                {c.name}
              </option>
            ))}
          </select>
          {selectedCategoryFilter !== 'all' && (
            <button
              onClick={() => setSelectedCategoryFilter('all')}
              className="text-xs text-indigo-600 hover:text-indigo-800 font-semibold px-2 py-1"
            >
              Clear
            </button>
          )}
        </div>

        {/* View Mode 1: Grouped by Date (Timeline) */}
        {breakdownMode === 'by_date' && (
          <div className="space-y-3 pt-1">
            {dateCategoryBreakdown.length === 0 ? (
              <div className="py-8 text-center text-xs text-slate-400">
                No transactions match this category in the selected date range.
              </div>
            ) : (
              dateCategoryBreakdown.map((day) => (
                <div
                  key={day.date}
                  className="p-3 bg-slate-50 border border-slate-200/70 rounded-2xl space-y-2"
                >
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-slate-900">{formatDateLabel(day.date)}</span>
                    <span
                      className={`font-mono font-bold tabular-nums ${
                        day.dayTotal >= 0 ? 'text-emerald-700' : 'text-slate-800'
                      }`}
                    >
                      {day.dayTotal >= 0 ? '+' : ''}
                      {formatCurrency(day.dayTotal, currency)}
                    </span>
                  </div>

                  <div className="space-y-1.5 divide-y divide-slate-200/40">
                    {day.categoriesList.map((c) => {
                      const catConfig = categories.find((cat) => cat.name === c.category);
                      const isIncome = c.total >= 0;

                      return (
                        <div key={c.category} className="pt-1.5 flex items-center justify-between text-xs">
                          <div className="flex items-center gap-2 min-w-0">
                            <div
                              className="w-5 h-5 rounded-md flex items-center justify-center text-white shrink-0 text-[10px]"
                              style={{ backgroundColor: catConfig?.color || '#64748b' }}
                            >
                              {getCategoryIcon(c.category, 'w-3 h-3')}
                            </div>
                            <span className="font-medium text-slate-800 truncate">{c.category}</span>
                            <span className="text-[10px] text-slate-400">
                              ({c.transactions.length})
                            </span>
                          </div>

                          <span
                            className={`font-mono font-semibold tabular-nums ${
                              isIncome ? 'text-emerald-700' : 'text-slate-800'
                            }`}
                          >
                            {isIncome ? '+' : '-'}
                            {formatCurrency(Math.abs(c.total), currency)}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {/* View Mode 2: Grouped by Category with Dates */}
        {breakdownMode === 'by_category' && (
          <div className="space-y-3 pt-1">
            {categoryDateBreakdown.length === 0 ? (
              <div className="py-8 text-center text-xs text-slate-400">
                No activity found for this category in the selected dates.
              </div>
            ) : (
              categoryDateBreakdown.map((cat) => {
                const catConfig = categories.find((c) => c.name === cat.category);

                return (
                  <div
                    key={cat.category}
                    className="p-3.5 bg-slate-50 border border-slate-200/70 rounded-2xl space-y-2.5"
                  >
                    <div className="flex items-center justify-between text-xs pb-1.5 border-b border-slate-200/60">
                      <div className="flex items-center gap-2">
                        <div
                          className="w-6 h-6 rounded-lg flex items-center justify-center text-white shrink-0"
                          style={{ backgroundColor: catConfig?.color || '#64748b' }}
                        >
                          {getCategoryIcon(cat.category, 'w-3.5 h-3.5')}
                        </div>
                        <span className="font-bold text-slate-900">{cat.category}</span>
                      </div>

                      <div className="font-mono text-xs tabular-nums text-right">
                        {cat.totalSpent > 0 && (
                          <span className="text-rose-700 font-bold mr-2">
                            -{formatCurrency(cat.totalSpent, currency)}
                          </span>
                        )}
                        {cat.totalIncome > 0 && (
                          <span className="text-emerald-700 font-bold">
                            +{formatCurrency(cat.totalIncome, currency)}
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Dates list for this category */}
                    <div className="space-y-1">
                      {cat.dates.map((d) => (
                        <div
                          key={d.date}
                          className="flex items-center justify-between text-[11px] text-slate-600 font-mono py-0.5"
                        >
                          <span>{formatDateLabel(d.date)}</span>
                          <span className="font-semibold text-slate-800">
                            {d.expense > 0 ? `-${formatCurrency(d.expense, currency)}` : `+${formatCurrency(d.income, currency)}`}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        )}
      </div>

      {/* Income Sources Summary */}
      {incomeBreakdown.length > 0 && (
        <div className="bg-white rounded-3xl p-5 border border-slate-200/80 shadow-xs space-y-3">
          <h3 className="font-bold text-sm text-slate-900">Income Inflow Sources</h3>
          <div className="divide-y divide-slate-100">
            {incomeBreakdown.map((src) => (
              <div key={src.category} className="py-2 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-lg bg-emerald-600 text-white flex items-center justify-center shrink-0">
                    {getCategoryIcon(src.category, 'w-3.5 h-3.5')}
                  </div>
                  <span className="font-semibold text-slate-800">{src.category}</span>
                </div>
                <div className="font-mono text-emerald-700 font-bold tabular-nums">
                  +{formatCurrency(src.total, currency)}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Actions: Download PDF, Print, CSV Export */}
      <div className="no-print space-y-2 pt-1">
        {/* Primary PDF Download Button */}
        <button
          onClick={handleDownloadPdf}
          className="w-full py-3.5 px-4 bg-slate-900 hover:bg-slate-800 text-white rounded-2xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 shadow-md shadow-slate-900/15 active:scale-[0.98] transition-transform cursor-pointer"
        >
          <FileText className="w-4 h-4 text-emerald-400" />
          <span>Download PDF Report</span>
        </button>

        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={handlePrint}
            className="py-2.5 px-3 bg-white border border-slate-200 hover:bg-slate-50 text-slate-800 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 shadow-xs active:scale-98 transition-transform cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5 text-slate-600" />
            <span>Print View</span>
          </button>

          <button
            onClick={handleExportCsv}
            className="py-2.5 px-3 bg-white border border-slate-200 hover:bg-slate-50 text-slate-800 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 shadow-xs active:scale-98 transition-transform cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* Printable Report View (Visible only when printing) */}
      <div className="hidden print:block font-sans text-black p-4">
        <div className="border-b-2 border-black pb-4 mb-4">
          <h1 className="text-xl font-bold">Pocket Ledger Financial Report</h1>
          <p className="text-xs text-gray-500 font-medium">Made by MW Solutions</p>
          <p className="text-xs text-gray-800 font-semibold mt-0.5">
            Account Holder: {userName || 'Account Holder'}
          </p>
          <p className="text-xs text-gray-600">
            Period: {startDateStr} to {endDateStr}
          </p>
        </div>

        <div className="mb-4">
          <h2 className="text-sm font-bold uppercase mb-1">Cash Flow Summary</h2>
          <table className="w-full text-xs border border-gray-300">
            <tbody>
              <tr className="border-b border-gray-300">
                <td className="p-2 font-medium">Total Inflow</td>
                <td className="p-2 text-right font-bold">+{formatCurrency(income, currency)}</td>
              </tr>
              <tr className="border-b border-gray-300">
                <td className="p-2 font-medium">Total Outflow</td>
                <td className="p-2 text-right font-bold">-{formatCurrency(expense, currency)}</td>
              </tr>
              <tr className="border-b border-gray-300 bg-gray-100">
                <td className="p-2 font-bold">Net Period Surplus</td>
                <td className="p-2 text-right font-bold">{formatCurrency(net, currency)}</td>
              </tr>
              <tr>
                <td className="p-2 font-medium">Savings Rate</td>
                <td className="p-2 text-right">{savingsRate.toFixed(1)}%</td>
              </tr>
            </tbody>
          </table>
        </div>

        <div>
          <h2 className="text-sm font-bold uppercase mb-1">Category Breakdown</h2>
          <table className="w-full text-xs border border-gray-300">
            <thead className="bg-gray-100 border-b border-gray-300">
              <tr>
                <th className="p-2 text-left">Category</th>
                <th className="p-2 text-right">Count</th>
                <th className="p-2 text-right">Amount</th>
              </tr>
            </thead>
            <tbody>
              {expenseBreakdown.map((row) => (
                <tr key={row.category} className="border-b border-gray-200">
                  <td className="p-2">{row.category}</td>
                  <td className="p-2 text-right">{row.count}</td>
                  <td className="p-2 text-right font-mono">{formatCurrency(row.total, currency)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
