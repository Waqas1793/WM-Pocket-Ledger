import React, { useEffect, useState } from 'react';
import { useFinance } from '../context/FinanceContext';
import { PaymentMethod, TransactionType } from '../types/finance';
import { getCurrentTimeString, getTodayDateString } from '../utils/formatters';
import { X, Check, ArrowDownRight, ArrowUpRight, Calendar, Clock, Tag, FileText, Repeat } from 'lucide-react';

export const TransactionModal: React.FC = () => {
  const {
    isAddModalOpen,
    closeModal,
    addTransaction,
    updateTransaction,
    editingTransaction,
    defaultModalType,
    categories,
    addCategory,
    currency,
    enablePaymentMethods,
    paymentMethods,
  } = useFinance();

  const [type, setType] = useState<TransactionType>(defaultModalType);
  const [amountStr, setAmountStr] = useState<string>('');
  const [category, setCategory] = useState<string>('');
  const [date, setDate] = useState<string>(getTodayDateString());
  const [time, setTime] = useState<string>(getCurrentTimeString());
  const [description, setDescription] = useState<string>('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>(() => paymentMethods[0] || 'Cash');
  const [status, setStatus] = useState<'cleared' | 'pending'>('cleared');
  const [tagInput, setTagInput] = useState<string>('');
  const [tags, setTags] = useState<string[]>([]);
  const [notes, setNotes] = useState<string>('');
  const [recurring, setRecurring] = useState<'none' | 'daily' | 'weekly' | 'monthly' | 'yearly'>('none');
  const [inlineCategoryInput, setInlineCategoryInput] = useState<string>('');
  const [showInlineCat, setShowInlineCat] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string>('');

  // Sync state when editing or opening
  useEffect(() => {
    const defaultMethod = paymentMethods[0] || 'Cash';
    if (editingTransaction) {
      setType(editingTransaction.type);
      setAmountStr(editingTransaction.amount.toString());
      setCategory(editingTransaction.category);
      setDate(editingTransaction.date);
      setTime(editingTransaction.time || getCurrentTimeString());
      setDescription(editingTransaction.description);
      setPaymentMethod(editingTransaction.paymentMethod || defaultMethod);
      setStatus(editingTransaction.status);
      setTags(editingTransaction.tags || []);
      setNotes(editingTransaction.notes || '');
      setRecurring(editingTransaction.recurring || 'none');
    } else {
      setType(defaultModalType);
      setAmountStr('');
      setDate(getTodayDateString());
      setTime(getCurrentTimeString());
      setDescription('');
      setPaymentMethod(defaultMethod);
      setStatus('cleared');
      setTags([]);
      setNotes('');
      setRecurring('none');

      // Set default category for the type
      const suitableCategories = categories.filter(
        (c) => c.type === defaultModalType || c.type === 'both'
      );
      if (suitableCategories.length > 0) {
        setCategory(suitableCategories[0].name);
      }
    }
    setErrorMessage('');
  }, [editingTransaction, defaultModalType, isAddModalOpen, categories, paymentMethods]);

  // Adjust default category when type toggles
  const handleTypeChange = (newType: TransactionType) => {
    setType(newType);
    const suitable = categories.filter((c) => c.type === newType || c.type === 'both');
    if (suitable.length > 0 && !suitable.some((c) => c.name === category)) {
      setCategory(suitable[0].name);
    }
    if (newType === 'income' && paymentMethod === 'credit_card') {
      setPaymentMethod('bank_transfer');
    }
  };

  const handleAddTag = () => {
    const cleanTag = tagInput.trim().replace(/^#/, '').toLowerCase();
    if (cleanTag && !tags.includes(cleanTag)) {
      setTags([...tags, cleanTag]);
      setTagInput('');
    }
  };

  const handleRemoveTag = (tagToRemove: string) => {
    setTags(tags.filter((t) => t !== tagToRemove));
  };

  const handleQuickAddAmount = (addValue: number) => {
    const current = parseFloat(amountStr) || 0;
    setAmountStr((current + addValue).toFixed(2));
  };

  const handleCreateInlineCategory = () => {
    const trimmed = inlineCategoryInput.trim();
    if (!trimmed) return;
    const colors = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#06b6d4', '#64748b'];
    const randomColor = colors[Math.floor(Math.random() * colors.length)];
    addCategory({
      name: trimmed,
      type: type,
      color: randomColor,
      iconName: 'Tag',
    });
    setCategory(trimmed);
    setInlineCategoryInput('');
    setShowInlineCat(false);
  };

  const handleSave = (addAnother: boolean = false) => {
    const parsedAmount = parseFloat(amountStr);
    if (isNaN(parsedAmount) || parsedAmount <= 0) {
      setErrorMessage('Please enter a valid amount greater than 0');
      return;
    }
    if (!description.trim()) {
      setErrorMessage('Please provide a short description or merchant name');
      return;
    }

    let finalCategory = category;
    if (!finalCategory && inlineCategoryInput.trim()) {
      finalCategory = inlineCategoryInput.trim();
      const colors = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#06b6d4', '#64748b'];
      const randomColor = colors[Math.floor(Math.random() * colors.length)];
      addCategory({
        name: finalCategory,
        type: type,
        color: randomColor,
        iconName: 'Tag',
      });
      setCategory(finalCategory);
      setInlineCategoryInput('');
    }

    if (!finalCategory) {
      setErrorMessage('Please select or enter a category');
      return;
    }

    const methodToSave = enablePaymentMethods ? (paymentMethod || paymentMethods[0] || 'Cash') : 'Cash';

    if (editingTransaction) {
      updateTransaction(editingTransaction.id, {
        type,
        amount: parsedAmount,
        category: finalCategory,
        date,
        time,
        description: description.trim(),
        paymentMethod: methodToSave,
        status,
        tags,
        notes: notes.trim(),
        recurring,
      });
      closeModal();
    } else {
      addTransaction({
        type,
        amount: parsedAmount,
        category: finalCategory,
        date,
        time,
        description: description.trim(),
        paymentMethod: methodToSave,
        status,
        tags,
        notes: notes.trim(),
        recurring,
      });

      if (addAnother) {
        setAmountStr('');
        setDescription('');
        setNotes('');
        setTags([]);
        setErrorMessage('');
      } else {
        closeModal();
      }
    }
  };

  if (!isAddModalOpen) return null;

  const filteredCategories = categories.filter(
    (c) => c.type === type || c.type === 'both'
  );

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div
        className="bg-white rounded-xl shadow-xl border border-slate-200 w-full max-w-lg overflow-hidden transition-all animate-in fade-in zoom-in-95 duration-150"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <h2 className="text-base font-bold text-slate-900">
              {editingTransaction ? 'Edit Transaction' : 'Record Transaction'}
            </h2>
          </div>
          <button
            onClick={closeModal}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5 max-h-[80vh] overflow-y-auto">
          {/* Type Switcher */}
          <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 rounded-lg">
            <button
              type="button"
              onClick={() => handleTypeChange('expense')}
              className={`flex items-center justify-center gap-2 py-2 text-xs sm:text-sm font-semibold rounded-md transition-colors cursor-pointer ${
                type === 'expense'
                  ? 'bg-white text-rose-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <ArrowDownRight className="w-4 h-4 text-rose-600" />
              <span>Expense</span>
            </button>
            <button
              type="button"
              onClick={() => handleTypeChange('income')}
              className={`flex items-center justify-center gap-2 py-2 text-xs sm:text-sm font-semibold rounded-md transition-colors cursor-pointer ${
                type === 'income'
                  ? 'bg-white text-emerald-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <ArrowUpRight className="w-4 h-4 text-emerald-600" />
              <span>Income</span>
            </button>
          </div>

          {/* Amount Input */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5 uppercase tracking-wider">
              Amount ({currency.code})
            </label>
            <div className="relative rounded-lg">
              <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 font-mono text-xl font-medium">
                {currency.symbol}
              </span>
              <input
                type="number"
                step="0.01"
                min="0"
                placeholder="0.00"
                autoFocus
                value={amountStr}
                onChange={(e) => setAmountStr(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleSave(false);
                }}
                className="w-full pl-9 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-lg text-2xl font-bold font-mono text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900 focus:bg-white transition-all tabular-nums"
              />
            </div>

            {/* Quick Denomination Chips */}
            <div className="flex items-center gap-1.5 mt-2 overflow-x-auto pb-1">
              <span className="text-[11px] text-slate-400 mr-1">Quick add:</span>
              {[5, 10, 25, 50, 100].map((val) => (
                <button
                  key={val}
                  type="button"
                  onClick={() => handleQuickAddAmount(val)}
                  className="px-2 py-1 text-xs font-mono font-medium bg-slate-100 hover:bg-slate-200 text-slate-700 rounded transition-colors whitespace-nowrap cursor-pointer"
                >
                  +{currency.symbol}{val}
                </button>
              ))}
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5 uppercase tracking-wider">
              Description / Payee
            </label>
            <input
              type="text"
              placeholder={type === 'expense' ? 'e.g. Grocery Store, Coffee, Office Rent' : 'e.g. Monthly Salary, Freelance Client, Dividend'}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-white border border-slate-200 rounded-lg text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900 transition-all placeholder:text-slate-400"
            />
          </div>

          {/* Category */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-semibold text-slate-700 uppercase tracking-wider">
                Category
              </label>
              <button
                type="button"
                onClick={() => setShowInlineCat(!showInlineCat)}
                className="text-xs text-indigo-600 hover:text-indigo-800 font-medium cursor-pointer"
              >
                {showInlineCat ? 'Cancel' : '+ New category'}
              </button>
            </div>

            {/* Inline Category Creation Input */}
            {(showInlineCat || filteredCategories.length === 0) && (
              <div className="mb-2 p-2.5 bg-indigo-50/60 border border-indigo-200/80 rounded-lg">
                <p className="text-[11px] font-medium text-indigo-900 mb-1.5">
                  {filteredCategories.length === 0
                    ? 'No categories yet. Create your first category:'
                    : 'Create new category:'}
                </p>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={inlineCategoryInput}
                    onChange={(e) => setInlineCategoryInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleCreateInlineCategory();
                      }
                    }}
                    placeholder={type === 'expense' ? 'e.g. Groceries, Rent, Fuel' : 'e.g. Salary, Client Pay, Bonus'}
                    className="flex-1 px-3 py-1.5 bg-white border border-slate-300 rounded-md text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                  <button
                    type="button"
                    onClick={handleCreateInlineCategory}
                    disabled={!inlineCategoryInput.trim()}
                    className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white text-xs font-semibold rounded-md transition-colors cursor-pointer"
                  >
                    Add
                  </button>
                </div>
              </div>
            )}

            {filteredCategories.length > 0 && (
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5 max-h-36 overflow-y-auto p-1 border border-slate-200 rounded-lg bg-slate-50/50">
                {filteredCategories.map((cat) => {
                  const isSelected = category === cat.name;
                  return (
                    <button
                      key={cat.id}
                      type="button"
                      onClick={() => setCategory(cat.name)}
                      className={`flex items-center gap-2 px-2.5 py-2 text-xs rounded-md text-left transition-all cursor-pointer truncate ${
                        isSelected
                          ? 'bg-slate-900 text-white font-medium shadow-xs'
                          : 'bg-white text-slate-700 border border-slate-200/60 hover:border-slate-300'
                      }`}
                    >
                      <span
                        className="w-2.5 h-2.5 rounded-full shrink-0"
                        style={{ backgroundColor: cat.color }}
                      />
                      <span className="truncate">{cat.name}</span>
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* Date & Payment Method */}
          <div className={enablePaymentMethods ? 'grid grid-cols-1 sm:grid-cols-2 gap-3' : ''}>
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-semibold text-slate-700 uppercase tracking-wider">
                  Date
                </label>
                <div className="flex gap-1 text-[11px]">
                  <button
                    type="button"
                    onClick={() => setDate(getTodayDateString())}
                    className="text-slate-500 hover:text-slate-900 underline cursor-pointer"
                  >
                    Today
                  </button>
                  <span className="text-slate-300">·</span>
                  <button
                    type="button"
                    onClick={() => {
                      const d = new Date();
                      d.setDate(d.getDate() - 1);
                      setDate(d.toISOString().split('T')[0]);
                    }}
                    className="text-slate-500 hover:text-slate-900 underline cursor-pointer"
                  >
                    Yesterday
                  </button>
                </div>
              </div>
              <div className="relative">
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-xs sm:text-sm font-mono text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900"
                />
              </div>
            </div>

            {enablePaymentMethods && (
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5 uppercase tracking-wider">
                  Payment Method
                </label>
                <select
                  value={paymentMethod}
                  onChange={(e) => setPaymentMethod(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-xs sm:text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-slate-900"
                >
                  {paymentMethods.map((pm) => (
                    <option key={pm} value={pm}>
                      {pm}
                    </option>
                  ))}
                  {!paymentMethods.includes(paymentMethod) && (
                    <option value={paymentMethod}>
                      {paymentMethod.replace('_', ' ')}
                    </option>
                  )}
                </select>
              </div>
            )}
          </div>

          {/* Status & Recurring */}
          <div className="grid grid-cols-2 gap-3 pt-1">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5 uppercase tracking-wider">
                Status
              </label>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setStatus('cleared')}
                  className={`flex-1 py-1.5 text-xs font-medium rounded border text-center transition-colors ${
                    status === 'cleared'
                      ? 'border-emerald-500 bg-emerald-50 text-emerald-800 font-semibold'
                      : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  Cleared
                </button>
                <button
                  type="button"
                  onClick={() => setStatus('pending')}
                  className={`flex-1 py-1.5 text-xs font-medium rounded border text-center transition-colors ${
                    status === 'pending'
                      ? 'border-amber-500 bg-amber-50 text-amber-800 font-semibold'
                      : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  Pending
                </button>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5 uppercase tracking-wider">
                Recurring
              </label>
              <select
                value={recurring}
                onChange={(e) => setRecurring(e.target.value as any)}
                className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-slate-900"
              >
                <option value="none">One-time (None)</option>
                <option value="daily">Daily</option>
                <option value="weekly">Weekly</option>
                <option value="monthly">Monthly</option>
                <option value="yearly">Yearly</option>
              </select>
            </div>
          </div>

          {/* Tags */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5 uppercase tracking-wider">
              Tags
            </label>
            <div className="flex items-center gap-2">
              <input
                type="text"
                placeholder="e.g. tax, work, groceries (press Add)"
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddTag();
                  }
                }}
                className="flex-1 px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-slate-900"
              />
              <button
                type="button"
                onClick={handleAddTag}
                className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-medium rounded-lg transition-colors"
              >
                Add
              </button>
            </div>

            {tags.length > 0 && (
              <div className="flex flex-wrap gap-1.5 mt-2">
                {tags.map((t) => (
                  <span
                    key={t}
                    className="inline-flex items-center gap-1 px-2 py-0.5 bg-slate-100 text-slate-700 rounded text-xs"
                  >
                    #{t}
                    <button
                      type="button"
                      onClick={() => handleRemoveTag(t)}
                      className="text-slate-400 hover:text-slate-700 text-xs ml-0.5"
                    >
                      ×
                    </button>
                  </span>
                ))}
              </div>
            )}
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5 uppercase tracking-wider">
              Notes (Optional)
            </label>
            <textarea
              rows={2}
              placeholder="Additional memo, invoice number, or details..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-slate-900"
            />
          </div>

          {/* Error Message */}
          {errorMessage && (
            <div className="p-2.5 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-lg">
              {errorMessage}
            </div>
          )}
        </div>

        {/* Footer actions */}
        <div className="flex items-center justify-between px-6 py-4 bg-slate-50 border-t border-slate-200">
          <button
            type="button"
            onClick={closeModal}
            className="px-4 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 hover:bg-slate-200/50 rounded-lg transition-colors"
          >
            Cancel
          </button>

          <div className="flex items-center gap-2">
            {!editingTransaction && (
              <button
                type="button"
                onClick={() => handleSave(true)}
                className="px-3 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 hover:bg-slate-100 rounded-lg transition-colors"
              >
                Save & Add Another
              </button>
            )}
            <button
              type="button"
              onClick={() => handleSave(false)}
              className="px-4 py-2 text-xs sm:text-sm font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors shadow-xs"
            >
              {editingTransaction ? 'Update Entry' : 'Save Entry'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
