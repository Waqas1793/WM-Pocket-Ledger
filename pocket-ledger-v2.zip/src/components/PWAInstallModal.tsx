import React, { useState } from 'react';
import { Smartphone, Download, Share2, PlusSquare, CheckCircle2, Copy, Check, Terminal, ExternalLink, X } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface PWAInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PWAInstallModal: React.FC<PWAInstallModalProps> = ({ isOpen, onClose }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [activeTab, setActiveTab] = useState<'pwa' | 'apk'>('pwa');
  const [copiedCmd, setCopiedCmd] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCmd(id);
    setTimeout(() => setCopiedCmd(null), 2000);
  };

  const apkBuildCommands = [
    { title: '1. Install Capacitor Native Runtime', cmd: 'npm install @capacitor/core @capacitor/cli @capacitor/android' },
    { title: '2. Initialize Capacitor Project', cmd: 'npx cap init "Pocket Ledger" com.mwsolutions.pocketledger --web-dir dist' },
    { title: '3. Build Web Bundle', cmd: 'npm run build' },
    { title: '4. Add Android Platform & Open Android Studio', cmd: 'npx cap add android && npx cap open android' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-150">
      <div 
        className="w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-slate-900 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img
              src="/logo.png"
              alt="Pocket Ledger"
              className="w-10 h-10 rounded-xl object-cover border border-slate-700/60 shadow-xs"
            />
            <div>
              <h3 className="font-bold text-base text-white">Install Pocket Ledger</h3>
              <p className="text-xs text-amber-400 font-medium">Made by MW Solutions</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switch: Direct Install (PWA) vs Native APK Guide */}
        <div className="flex border-b border-slate-200 bg-slate-50 px-4 pt-2">
          <button
            onClick={() => setActiveTab('pwa')}
            className={`pb-2.5 px-4 text-xs font-bold border-b-2 transition-colors flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'pwa'
                ? 'border-amber-500 text-amber-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Download className="w-3.5 h-3.5" />
            <span>Instant Install (Android & iOS)</span>
          </button>
          <button
            onClick={() => setActiveTab('apk')}
            className={`pb-2.5 px-4 text-xs font-bold border-b-2 transition-colors flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'apk'
                ? 'border-amber-500 text-amber-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>Build Native APK</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto space-y-4">
          {activeTab === 'pwa' ? (
            <>
              {/* If already installed */}
              {isInstalled ? (
                <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                  <div className="text-xs">
                    <p className="font-bold">App Already Installed</p>
                    <p className="text-emerald-700 mt-0.5">You are already running Pocket Ledger in standalone mobile mode.</p>
                  </div>
                </div>
              ) : isInstallable ? (
                /* Native browser prompt is ready (Android Chrome / Edge / Desktop) */
                <div className="p-4 rounded-xl bg-amber-50 border border-amber-200 text-slate-900 space-y-3">
                  <div className="flex items-start gap-3">
                    <div className="p-2 bg-amber-500 text-white rounded-lg shrink-0">
                      <Download className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-slate-900">Direct 1-Click Install Ready</h4>
                      <p className="text-xs text-slate-600 mt-1">
                        Tap the button below to add Pocket Ledger directly to your phone screen with native splash screen & full offline support.
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={async () => {
                      await install();
                      onClose();
                    }}
                    className="w-full py-2.5 px-4 bg-amber-500 hover:bg-amber-600 active:bg-amber-700 text-slate-950 font-bold rounded-xl text-xs flex items-center justify-center gap-2 shadow-sm transition cursor-pointer"
                  >
                    <Download className="w-4 h-4" />
                    <span>Install App on this Device</span>
                  </button>
                </div>
              ) : null}

              {/* Instructions for Android Chrome */}
              <div className="border border-slate-200 rounded-xl p-4 bg-white space-y-2.5">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-900">
                  <span className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center text-[11px]">A</span>
                  <span>Android (Chrome / Samsung Internet / Brave)</span>
                </div>
                <ol className="text-xs text-slate-600 space-y-1.5 list-decimal list-inside pl-1">
                  <li>Open this page in <strong>Google Chrome</strong> or your mobile browser.</li>
                  <li>Tap the <strong>three dots menu (⋮)</strong> in the top-right corner.</li>
                  <li>Tap <strong>"Install app"</strong> or <strong>"Add to Home screen"</strong>.</li>
                  <li>The app will install as a native icon on your launcher and app drawer.</li>
                </ol>
              </div>

              {/* Instructions for iPhone / iPad */}
              <div className="border border-slate-200 rounded-xl p-4 bg-white space-y-2.5">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-900">
                  <span className="w-5 h-5 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center text-[11px]">iOS</span>
                  <span>iPhone / iPad (Apple Safari)</span>
                </div>
                <ol className="text-xs text-slate-600 space-y-1.5 list-decimal list-inside pl-1">
                  <li>
                    Open this app in <strong>Safari</strong> and tap the <Share2 className="w-3.5 h-3.5 inline mx-1 text-blue-600" /> <strong>Share</strong> button at the bottom toolbar.
                  </li>
                  <li>
                    Scroll down and tap <PlusSquare className="w-3.5 h-3.5 inline mx-1 text-slate-700" /> <strong>Add to Home Screen</strong>.
                  </li>
                  <li>Tap <strong>Add</strong> in the top-right corner.</li>
                </ol>
              </div>

              {/* Features summary */}
              <div className="grid grid-cols-2 gap-2 pt-1 text-[11px] text-slate-600">
                <div className="p-2.5 bg-slate-50 rounded-lg flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-emerald-500" />
                  <span>Works 100% Offline</span>
                </div>
                <div className="p-2.5 bg-slate-50 rounded-lg flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-emerald-500" />
                  <span>No App Store needed</span>
                </div>
                <div className="p-2.5 bg-slate-50 rounded-lg flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-emerald-500" />
                  <span>Full Screen standalone</span>
                </div>
                <div className="p-2.5 bg-slate-50 rounded-lg flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-emerald-500" />
                  <span>All data stays on device</span>
                </div>
              </div>
            </>
          ) : (
            /* Build Native APK Guide */
            <div className="space-y-4 text-xs">
              <a
                href="/pocket-ledger-source.zip"
                download="pocket-ledger-source.zip"
                className="w-full py-2.5 px-4 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl text-xs flex items-center justify-center gap-2 shadow-xs transition cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>Download Complete Project Code (.ZIP)</span>
              </a>

              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-700">
                <p className="font-semibold text-slate-900">How to export to Android APK (.apk):</p>
                <p className="mt-1 text-slate-500">
                  This application includes a ready-to-use Capacitor configuration (`capacitor.config.json`). Run these standard commands to generate an installable Android APK file:
                </p>
              </div>

              <div className="space-y-3">
                {apkBuildCommands.map((item, idx) => (
                  <div key={idx} className="bg-slate-900 text-slate-200 p-3 rounded-xl space-y-1.5">
                    <div className="flex items-center justify-between text-[11px] text-slate-400 font-medium">
                      <span>{item.title}</span>
                      <button
                        onClick={() => handleCopy(item.cmd, `cmd-${idx}`)}
                        className="flex items-center gap-1 text-amber-400 hover:text-amber-300 font-mono transition"
                      >
                        {copiedCmd === `cmd-${idx}` ? (
                          <>
                            <Check className="w-3 h-3 text-emerald-400" />
                            <span className="text-emerald-400">Copied</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3 h-3" />
                            <span>Copy</span>
                          </>
                        )}
                      </button>
                    </div>
                    <code className="block font-mono text-[11px] text-emerald-300 break-all select-all">
                      $ {item.cmd}
                    </code>
                  </div>
                ))}
              </div>

              <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-amber-900 text-[11px] space-y-1">
                <p className="font-bold">Output APK Location in Android Studio:</p>
                <p className="font-mono text-slate-700">android/app/build/outputs/apk/debug/app-debug.apk</p>
                <p className="text-slate-500">You can transfer this `.apk` file directly to any Android smartphone via USB, WhatsApp, or Google Drive and tap to install!</p>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs rounded-xl transition cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
