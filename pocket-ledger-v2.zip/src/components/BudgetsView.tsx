import React, { useState } from 'react';
import { useFinance } from '../context/FinanceContext';
import { formatCurrency, getTodayDateString } from '../utils/formatters';
import {
  ShieldAlert,
  AlertTriangle,
  CheckCircle2,
  DollarSign,
  Plus,
  Edit2,
  Check,
  TrendingUp,
} from 'lucide-react';

export const BudgetsView: React.FC = () => {
  const { categories, transactions, currency, updateCategoryBudget } = useFinance();

  const [editingCatId, setEditingCatId] = useState<string | null>(null);
  const [budgetInput, setBudgetInput] = useState<string>('');

  // Current month string prefix
  const currentMonth = getTodayDateString().substring(0, 7); // 'YYYY-MM'
  const currentMonthTransactions = transactions.filter(
    (t) => t.type === 'expense' && t.date.startsWith(currentMonth)
  );

  // Calculate actual spend per category for this month
  const categorySpendMap = new Map<string, number>();
  currentMonthTransactions.forEach((t) => {
    categorySpendMap.set(t.category, (categorySpendMap.get(t.category) || 0) + t.amount);
  });

  // Expense categories
  const expenseCategories = categories.filter((c) => c.type === 'expense');

  // Overall totals
  let totalBudget = 0;
  let totalSpentInBudgeted = 0;

  expenseCategories.forEach((cat) => {
    if (typeof cat.budget === 'number' && cat.budget > 0) {
      totalBudget += cat.budget;
      totalSpentInBudgeted += categorySpendMap.get(cat.name) || 0;
    }
  });

  const overallPercent = totalBudget > 0 ? (totalSpentInBudgeted / totalBudget) * 100 : 0;

  const handleStartEdit = (catId: string, currentBudget?: number) => {
    setEditingCatId(catId);
    setBudgetInput(currentBudget ? currentBudget.toString() : '');
  };

  const handleSaveBudget = (catId: string) => {
    const val = parseFloat(budgetInput);
    if (!isNaN(val) && val >= 0) {
      updateCategoryBudget(catId, val);
    } else {
      updateCategoryBudget(catId, undefined);
    }
    setEditingCatId(null);
  };

  return (
    <div className="space-y-6">
      {/* Overview Banner */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <h2 className="text-base font-bold text-slate-900">Monthly Budget Caps</h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Set spending limits per category to prevent overspending and track monthly targets
            </p>
          </div>
          <div className="text-right">
            <span className="text-xs text-slate-500 block">Total Monthly Budget Pool</span>
            <span className="text-xl sm:text-2xl font-bold font-mono text-slate-900 tabular-nums">
              {formatCurrency(totalBudget, currency)}
            </span>
          </div>
        </div>

        {/* Aggregate Progress Bar */}
        <div className="pt-4 space-y-2">
          <div className="flex justify-between text-xs">
            <span className="text-slate-600 font-medium">
              Overall Budget Used:{' '}
              <strong className="font-mono text-slate-900">{formatCurrency(totalSpentInBudgeted, currency)}</strong>
            </span>
            <span className="font-mono font-bold text-slate-800">
              {overallPercent.toFixed(1)}%
            </span>
          </div>
          <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-300 ${
                overallPercent > 100
                  ? 'bg-rose-600'
                  : overallPercent >= 80
                  ? 'bg-amber-500'
                  : 'bg-emerald-600'
              }`}
              style={{ width: `${Math.min(100, overallPercent)}%` }}
            />
          </div>
          <div className="flex justify-between text-[11px] text-slate-500 font-mono">
            <span>
              Remaining in pool:{' '}
              <strong className={totalBudget - totalSpentInBudgeted >= 0 ? 'text-emerald-700' : 'text-rose-700'}>
                {formatCurrency(totalBudget - totalSpentInBudgeted, currency)}
              </strong>
            </span>
          </div>
        </div>
      </div>

      {/* Category Budgets Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {expenseCategories.map((cat) => {
          const spent = categorySpendMap.get(cat.name) || 0;
          const budget = cat.budget || 0;
          const hasBudget = typeof cat.budget === 'number' && cat.budget > 0;
          const percent = hasBudget ? (spent / budget) * 100 : 0;
          const remaining = budget - spent;
          const isOver = hasBudget && spent > budget;
          const isWarning = hasBudget && percent >= 80 && percent <= 100;
          const isEditing = editingCatId === cat.id;

          return (
            <div
              key={cat.id}
              className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <span
                      className="w-3 h-3 rounded-full shrink-0"
                      style={{ backgroundColor: cat.color }}
                    />
                    <h3 className="text-sm font-bold text-slate-900">{cat.name}</h3>
                  </div>

                  {isEditing ? (
                    <div className="flex items-center gap-1">
                      <div className="relative w-24">
                        <span className="absolute left-2 top-1/2 -translate-y-1/2 text-slate-400 font-mono text-xs">
                          {currency.symbol}
                        </span>
                        <input
                          type="number"
                          placeholder="0"
                          value={budgetInput}
                          autoFocus
                          onChange={(e) => setBudgetInput(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') handleSaveBudget(cat.id);
                          }}
                          className="w-full pl-5 pr-2 py-1 bg-slate-50 border border-slate-300 rounded text-xs font-mono font-bold focus:bg-white focus:outline-none"
                        />
                      </div>
                      <button
                        onClick={() => handleSaveBudget(cat.id)}
                        className="p-1 bg-slate-900 text-white rounded hover:bg-slate-800"
                      >
                        <Check className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={() => handleStartEdit(cat.id, cat.budget)}
                      className="flex items-center gap-1 text-xs text-slate-500 hover:text-slate-900 hover:bg-slate-100 px-2 py-1 rounded transition-colors"
                    >
                      <Edit2 className="w-3 h-3" />
                      <span>{hasBudget ? 'Edit Limit' : 'Set Limit'}</span>
                    </button>
                  )}
                </div>

                {hasBudget ? (
                  <div className="space-y-2 mt-4">
                    <div className="flex items-center justify-between text-xs font-mono">
                      <div>
                        <span className="text-slate-500">Spent: </span>
                        <strong className={isOver ? 'text-rose-700' : 'text-slate-900'}>
                          {formatCurrency(spent, currency)}
                        </strong>
                      </div>
                      <div>
                        <span className="text-slate-500">Cap: </span>
                        <strong className="text-slate-900">{formatCurrency(budget, currency)}</strong>
                      </div>
                    </div>

                    {/* Bar */}
                    <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-300 ${
                          isOver ? 'bg-rose-600' : isWarning ? 'bg-amber-500' : 'bg-slate-800'
                        }`}
                        style={{ width: `${Math.min(100, percent)}%` }}
                      />
                    </div>

                    <div className="flex items-center justify-between text-[11px] font-mono pt-1">
                      <span className={isOver ? 'text-rose-700 font-bold' : isWarning ? 'text-amber-700 font-semibold' : 'text-slate-500'}>
                        {isOver
                          ? `Exceeded by ${formatCurrency(Math.abs(remaining), currency)}`
                          : `${formatCurrency(remaining, currency)} remaining`}
                      </span>
                      <span className="text-slate-400 font-bold">{percent.toFixed(0)}% used</span>
                    </div>
                  </div>
                ) : (
                  <div className="py-4 text-center border border-dashed border-slate-200 rounded-lg my-2 text-xs text-slate-500">
                    <span>No budget set for this category. </span>
                    <button
                      onClick={() => handleStartEdit(cat.id)}
                      className="text-indigo-600 hover:underline font-semibold"
                    >
                      Set limit
                    </button>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
