import React, { useEffect, useState } from 'react';
import { FinanceProvider, useFinance } from './context/FinanceContext';
import { MobileHeader } from './components/MobileHeader';
import { MobileBottomNav, MobileTab } from './components/MobileBottomNav';
import { MobileHomeView } from './components/views/MobileHomeView';
import { MobileHistoryView } from './components/views/MobileHistoryView';
import { MobileReportsView } from './components/views/MobileReportsView';
import { MobileSettingsView } from './components/views/MobileSettingsView';
import { MobileAddSheet } from './components/MobileAddSheet';
import { OfflineIndicator } from './components/OfflineIndicator';

function MobileAppContent() {
  const [currentTab, setCurrentTab] = useState<MobileTab>('home');
  const { openAddModal, isAddModalOpen } = useFinance();

  // Keyboard shortcut: Press 'N' to open Add drawer
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      if (
        target.tagName === 'INPUT' ||
        target.tagName === 'TEXTAREA' ||
        target.tagName === 'SELECT'
      ) {
        return;
      }

      if ((e.key === 'n' || e.key === 'N') && !isAddModalOpen) {
        e.preventDefault();
        openAddModal('expense');
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isAddModalOpen, openAddModal]);

  const getPageTitle = () => {
    switch (currentTab) {
      case 'home':
        return 'Today';
      case 'history':
        return 'History';
      case 'reports':
        return 'Reports';
      case 'settings':
        return 'Settings';
      default:
        return 'Pocket Ledger';
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 flex items-center justify-center font-sans selection:bg-slate-900 selection:text-white">
      {/* Mobile App Canvas Container */}
      <div className="w-full sm:max-w-md min-h-screen sm:min-h-[844px] bg-slate-50 flex flex-col sm:shadow-2xl sm:rounded-3xl relative overflow-hidden sm:my-4 border border-slate-200/80">
        {/* Mobile Top Header */}
        <div className="no-print">
          <MobileHeader title={getPageTitle()} />
        </div>

        {/* Scrollable Main Content */}
        <main className="flex-1 px-4 py-4 overflow-y-auto">
          {currentTab === 'home' && <MobileHomeView />}
          {currentTab === 'history' && <MobileHistoryView />}
          {currentTab === 'reports' && <MobileReportsView />}
          {currentTab === 'settings' && <MobileSettingsView />}
        </main>

        {/* Fixed Mobile Bottom Tab Bar */}
        <div className="no-print">
          <MobileBottomNav currentTab={currentTab} setCurrentTab={setCurrentTab} />
        </div>

        {/* Bottom Sheet Drawer for Fast Adding */}
        <MobileAddSheet />

        {/* Offline indicator toast */}
        <OfflineIndicator />
      </div>
    </div>
  );
}

export default function App() {
  return (
    <FinanceProvider>
      <MobileAppContent />
    </FinanceProvider>
  );
}
